# -*- coding: utf-8 -*-
'''
Created on Apr 14, 2017

@author: thanhtran
'''

import xmltodict

class STBValidation(object):
	"""docstring for STBVerificationResult"""

	def __init__(self, json_object=None, output_msg=None):
		super(STBValidation, self).__init__()
		self.json_object = json_object
		self.output_msg = output_msg

	def __str__(self):
		return self.output_msg

	def setJsonObject(self, json_object):
		self.json_object = json_object
	
	def setOutputMessage(self, output_msg):
		self.output_msg = output_msg

	def getJsonObject(self):
		return self.json_object

	def getOutputMessage(self):
		return self.output_msg

	def verifyInLiveMode(self):
		if "Currently watching (live) TV!!!" not in self.output_msg: 
			return False
		else:
			return True
		
def verifyMenuScreenIsDisplayed(screenXMLFile, fieldFocus="default"):
	#Screen title is Menu
	#Left menu - first item "What's On Now should be selected
	#First Poster of the row "What's On Now" is selected 
	try:
		with open(screenXMLFile) as fd:
			xmldoc = xmltodict.parse(fd.read())
	except Exception as e:
		print e
		xmldoc = {}
	
		
	if fieldFocus == "default":
		print "Test default Menu screen"
		#print xmldoc['Screen']['ScreenHeader']['title']
		assert(str(xmldoc['Screen']['ScreenHeader']['title']) == "Menu")
		#print str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0])
		#print str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0]['#text'])
		assert(str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0]['#text']) == "What's On Now")
		#print str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0]['@isSelected'])
		assert(str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0]['@isSelected']) == "true")
	
	if fieldFocus == "Recordings":
		print "Test Menu screen - Recordings widget is selected"
		#print xmldoc['Screen']['ScreenHeader']['title']
		assert(str(xmldoc['Screen']['ScreenHeader']['title']) == "Menu")
		#print str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0])
		#print str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0]['#text'])
		assert(str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][1]['#text']) == "Recordings")
		#print str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0]['@isSelected'])
		assert(str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][1]['@isSelected']) == "true")
		
	if fieldFocus == "default-Poster2Selected":
		print "Test Menu screen - Menu widget is selected - Poster 2 is selected"
		#print xmldoc['Screen']['ScreenHeader']['title']
		assert(str(xmldoc['Screen']['ScreenHeader']['title']) == "Menu")
		#print str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0])
		#print str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0]['#text'])
		assert(str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0]['#text']) == "What's On Now")
		#print str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0]['@isSelected'])
		assert(str(xmldoc['Screen']['LeftMenu']['MenuItems']['Item'][0]['@isSelected']) == "true")
		assert(str(xmldoc['Screen']['Widget'][1]['Posters']['Poster'][1]['@isSelected']) == "true")
		
		