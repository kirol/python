'''
Created on Apr 11, 2017

@author: thanhtran
'''
import unittest
import os.path
from Utils.SpreadSheetHelper import SpreadSheetHelper
from Utils import TestUtils
from Controllers import STBControl
from Configurations import STBConfiguration
from Configurations import TFWConfiguration

import time
from Controllers.STBControl import executeCommand
from Utils.Logger import Logger

class BaseTest(unittest.TestCase):
    #log = Logger()
    passedTest = None
    testCaseID = None
    
    def setUp(self):
        global logger
        logger = Logger()
        unittest.TestCase.setUp(self)
        #print "DO SOMETHING BEFORE TEST"
        logger.log("INFO", "DO SOMETHING BEFORE TEST")
        global passedTest
        passedTest = False
        global testCaseID
        testCaseID = ""
        if not os.path.exists("testreport.xlsx"):
            #logger.log("INFO", "SpreadSheetHelper.createEmptyTestReport")
            SpreadSheetHelper.createEmptyTestReport()
        #global httpDeamonThread
        #HttpDeamon.startHttpDeamon()
        setConfiguration()
        enableSHEF() # author: hoahtk
        #author: Nhanqt  
        STBControl.VerifyKeycodeIsAvailable()  
        
        TestUtils.cleanTmpFolder()
        STBControl.cleanUpScreenXMLFiles()
        STBControl.sendRemoteKey("EXIT", isSHEF=False)
        
    def tearDown(self):
        #print "DO CLEAN UP AFTER TEST"
        #logger.log("INFO", "DO CLEAN UP AFTER TEST")
        SpreadSheetHelper.writeTestResult(self.passedTest, self.testCaseID) if self.passedTest else SpreadSheetHelper.writeTestResult(False, self.testCaseID)
        #HttpDeamon.stopHttpDeamon()
        TestUtils.cleanTmpFolder()
        STBControl.cleanUpScreenXMLFiles()
        time.sleep(5)
        STBControl.sendRemoteKey("EXIT", isSHEF=False)
        time.sleep(5)
        unittest.TestCase.tearDown(self)
        
def setConfiguration():
    STBConfiguration.STBIPAddress = "192.168.1.101"
    TFWConfiguration.TFWSRV_IP = "192.168.51.1"
    
# author: hoahtk
def enableSHEF():
    
    #enable OnShef
    enableOnShef = executeCommand('dt shef -cmd onShef')
    print('Enable Onshef: Done' + '\n' +  enableOnShef)
    
    #enable onGetTuned SHEF
    enableOnGetTuned = executeCommand('dt shef -cmd onGetTuned')
    print('Enable onGetTuned: Done' + '\n' +  enableOnGetTuned)
    
    #enable onGetPlaylist SHEF
    enableOnGetPlaylist = executeCommand('dt shef cmd onGetPlaylist')
    print('Enable onGetPlaylist: Done' + '\n' +  enableOnGetPlaylist)         
    
    

        
        