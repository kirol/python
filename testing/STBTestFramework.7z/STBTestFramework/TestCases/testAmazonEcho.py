'''
Created on Jun 27, 2017

@author: thanhtran
'''

from BaseTest import BaseTest
from Controllers.SHEFHTTPRequest import RemoteKeyRequest
from Controllers.SHEFJSONResponse import RemoteKeyResponse
from Controllers.SHEFHTTPRequest import TVGetTunedRequest
from Controllers.SHEFJSONResponse import TVGetTunedResponse
from Utils import VoiceUtilities
import time

class testAmazonEcho(BaseTest):
    def setUp(self):
        BaseTest.setUp(self)
        
    def tearDown(self):
        BaseTest.tearDown(self)
        
    def testUtteranceTuneToCNNChannel(self):
        BaseTest.testCaseID = self.id()
        VoiceUtilities.sayUtteranceAndRecognize("Alexa, tune to ESPN channel")
        time.sleep(10)
        tvGetTunedRequest = TVGetTunedRequest()
        responseJSON = tvGetTunedRequest.send()
        print responseJSON
        expectedTVGetTunedResponsed = TVGetTunedResponse(channelName = "ESPNHD", channelIndex = 206)
        testResult = expectedTVGetTunedResponsed.verifyExpectedChannel(getTunedResponseJSON=responseJSON)
        BaseTest.passedTest = testResult