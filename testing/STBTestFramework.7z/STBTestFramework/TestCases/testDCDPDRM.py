'''
Created on Oct 23, 2017

@author: tt4609
'''
from TestCases.BaseTest import BaseTest
from Controllers import STBControl
from Utils import TestUtils
from Configurations import TFWConfiguration
from Configurations import STBConfiguration

class CommonTestCases(BaseTest):
    def setUp(self):
        BaseTest.setUp(self)
        
    def tearDown(self):
        BaseTest.tearDown(self)
            
    def testDCDPDRM_PlayReadyURL(self):
        BaseTest.testCaseID = self.id()
        print "Test streaming a playready URL"
        STBControl.sendDTCommand('playURL -url "http://profficialsite.origin.mediaservices.windows.net/c51358ea-9a5e-4322-8951-897d640fdfd7/tearsofsteel_4k.ism/manifest(format=mpd-time-csf)"')
        BaseTest.passedTest = True

    def testDCDPDRM_PlayBigBuckBunny(self):
        BaseTest.testCaseID = self.id()
        print "Test streaming a playready URL"
        STBControl.sendDTCommand('playURL -url http://dash.edgesuite.net/akamai/bbb_30fps/bbb_30fps.mpd')
        BaseTest.passedTest = True


class PerformanceTestCases(BaseTest):
    def setUp(self):
        BaseTest.setUp(self)
        
    def tearDown(self):
        BaseTest.tearDown(self)
        
    def testDCDPDRM_Performance_BBB(self):
        BaseTest.testCaseID = self.id()
        print "Test streaming a playready URL"
        STBControl.sendDTCommand('playURL -url http://dash.edgesuite.net/akamai/bbb_30fps/bbb_30fps.mpd')
        
        TestUtils.monitor_performance(TFWConfiguration.TFWSRV_IP, TFWConfiguration.TFWSRV_USERID, TFWConfiguration.TFWSRV_USERPASS, True, "TTYS6", STBConfiguration.STBIPAddress, STBConfiguration.STBModel, STBConfiguration.STBManufacturer, STBConfiguration.SSHRootPass, "2", "RemoteMp4MediaStream")
        BaseTest.passedTest = True