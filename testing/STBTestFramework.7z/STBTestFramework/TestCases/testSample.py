'''
Created on Apr 11, 2017

@author: thanhtran
'''
import time
import json
import os
from urllib2 import HTTPDigestAuthHandler
from BaseTest import BaseTest
from Utils import HttpDeamon, VoiceUtilities, TestUtils
from Utils.SpreadSheetHelper import SpreadSheetHelper
from Controllers import STBControl, SHEFHTTPRequest, SHEFJSONResponse
from Controllers.SHEFHTTPRequest import RemoteKeyRequest, SHEFTuneRequest,SHEFgetSTBLocationsRequest,\
    SHEFSerialCommandRequest, SHEFgetMyTeamRequest, SHEFgetHDDStatusRequest
from Controllers.SHEFJSONResponse import RemoteKeyResponse, tunePrivateResponse, SHEFtuneResponse, SHEFgetSTBLocationsResponse,\
    SHEFSerialCommandResponse, SHEFgetMyTeamResponse, SHEFgetHDDStatusResponse
from Controllers.SHEFHTTPRequest import TVGetTunedRequest
from Controllers.SHEFJSONResponse import TVGetTunedResponse
from Controllers.SHEFHTTPRequest import SHEFPlaylistRequest
from Controllers.SHEFHTTPRequest import SHEFRecordPrivateRequest
from STBTestingAgent.STBTestingAgent import STBDriver
from STBTestingAgent.STBTestingAgent import DesiredCapabilities
from Validations import STBValidations
from Validations.STBValidations import STBValidation
from Configurations import STBConfiguration
from Controllers.SHEFHTTPRequest import SHEFPlaybackRequest
from Controllers.SHEFHTTPRequest import TVgetProgInfoRequest
from Controllers.SHEFJSONResponse import TVgetProgInfoResponse
from Controllers.SHEFHTTPRequest import TVgetProgInfoPrivateRequest
from Controllers.SHEFJSONResponse import TVgetProgInfoPrivateResponse
from Controllers.SHEFHTTPRequest import TVGetTunedPrivateRequest
from Controllers.SHEFJSONResponse import TVGetTunedPrivateResponse
from Controllers.SHEFHTTPRequest import SHEFtunePrivateRequest
from Controllers.SHEFJSONResponse import DRMInfoResponse, NotificationforVoiceResponse
from Controllers.SHEFHTTPRequest import SHEFGetPlaylistPrivateRequest, SHEFDRMRequest, SHEFGetPlaylistRequest, SHEFPlaybackViaMRVRequest, SHEFNotificationforVoiceRequest
import re
from Utils.Logger import Logger


class testSample(BaseTest):
    def setUp(self):
        global logger
        logger = Logger('../TestLogs/logfile.log', '%(asctime)s| %(levelname)s| %(message)s')
        #logger.init('../TestLogs/logfile.log', '%(asctime)s| %(levelname)s| %(message)s')
        BaseTest.setUp(self)
        
    def tearDown(self):
        BaseTest.tearDown(self)

    def SHEFPlaybackViaMRV(self):
        '''
        Created on Nov 09, 2017
        @author:Nhanqt
        def: Playback MRV recording
        http://STBIP:port/dvr/play?uniqueId=num&udn=string[&playFrom=string][&offset=num][&clientAddr=string][&fromApp=boolean][&autoDel=boolean]
        '''
        BaseTest.testCaseID = self.id()
        getresult = STBControl.executeCommandonMRVbox("dt getCardStatus | grep receiverID")        
        matchobj = re.match(r'.*\"([0-9]+)',getresult, re.M|re.I)
        MRVRID = matchobj.group(1)
        
        requestPlayback = SHEFPlaybackViaMRVRequest(MRVuniqueId = 4422, MRVReceiverID = MRVRID)
        result = requestPlayback.send()
        print result
        BaseTest.passedTest = True
    
    def SHEFNotificationforVoice(self):
        '''
        Created on Nov 09, 2017
        @author: nhantq
        def: Notification for Voice
        http://STBIP:port/notification/voice?[clientAddr=string]
        '''
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Notification for Voice"
        requestVoice = SHEFNotificationforVoiceRequest()
        resultResponseJSON = requestVoice.send()
        print resultResponseJSON      
        Voiceresult = NotificationforVoiceResponse()
        testresult = Voiceresult.verifyNotificationforVoice(getNotificationforVoiceResponseJSON=resultResponseJSON)
        BaseTest.passedTest = testresult
    
    def SHEFgetHDDStatus(self):
        '''
        #author: ThanhHo
        Date: 9-Nov
        '''
        BaseTest.testCaseID = self.id()
        print "HTTP SHEF: get HDD Status"
        getHDDStatusrequest = SHEFgetHDDStatusRequest()
        responseJSON = getHDDStatusrequest.send()
        expectedgetHDDStatusresponse = SHEFgetHDDStatusResponse()
        testresult = expectedgetHDDStatusresponse.verifyExpectedChannel(responseJSON)
        BaseTest.passedTest = testresult
        
    def SHEFgetMyTeam(self):
        '''
        #author: ThanhHo
        Date: 9-Nov
        '''
        BaseTest.testCaseID = self.id()
        print "HTTP SHEF: get My Team"
        getMyTeamrequest = SHEFgetMyTeamRequest()
        responseJSON = getMyTeamrequest.send()
        expectedgetMyTeamResponse = SHEFgetMyTeamResponse()
        testresult = expectedgetMyTeamResponse.verifyExpectedChannel(responseJSON)
        BaseTest.passedTest = testresult

    def SHEFGetPlaylistPrivate(self):
        '''
        Created on Nov 08, 2017
        @author: nhantq
        def: Display getPlaylist Private
        '''        
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Display getPlaylist Private using SHEF command"
        requestPlaylist = SHEFGetPlaylistPrivateRequest(type='all')
        result = requestPlaylist.send()
        print result
        BaseTest.passedTest = True
    
    def SHEFGenieDvrPlaylist(self):
        '''
        Created on Nov 08, 2017
        @author: nhantq
        def: Genie - /dvr/Playlist
        '''
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Display Genie playlist"
        requestPlaylist = SHEFPlaylistRequest(action='get',type='genie')
        result = requestPlaylist.send()
        print result
        BaseTest.passedTest = True

    def SHEFDRMInfo(self):
        '''
        Created on Nov 08, 2017
        @author: nhantq
        def: DRM-Info
        http://STBIP:port/drm?action=info
        '''
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: DRM-Info"
        requestDRMInfo = SHEFDRMRequest(action='info')
        resultResponseJSON = requestDRMInfo.send()
        print resultResponseJSON      
        expectedDRMresult = DRMInfoResponse()
        testresult = expectedDRMresult.verifyExpectedDRMStatus(getDRMInfoResponseJSON=resultResponseJSON)
        BaseTest.passedTest = testresult
        
    def SHEFDRMConnect(self):
        '''
        Created on Nov 08, 2017
        @author: nhantq
        def: DRM-Connect
        http://STBIP:port/drm?action=connect
        '''
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: DRM-Connect"
        requestDRMConnect = SHEFDRMRequest(action='connect')
        result = requestDRMConnect.send()
        print result
        BaseTest.passedTest = True
        
    def SHEFgetSTBLocations(self):
        '''
        #author: ThanhHo
        Date: 8-Nov
        '''
        BaseTest.testCaseID = self.id()
        print "HTTP SHEF: Get STB Locations"
        getSTBLocationsRequest = SHEFgetSTBLocationsRequest()
        responseJSON = getSTBLocationsRequest.send()
        print responseJSON
        expectedgetSTBLocationsResponse = SHEFgetSTBLocationsResponse()
        testresult = expectedgetSTBLocationsResponse.verifyExpectedChannel(responseJSON)
        BaseTest.passedTest = testresult
                
    def SHEFtune(self):
        '''
        #author: ThanhHo
        Date: 8-Nov
        '''
        BaseTest.testCaseID = self.id()
        print "HTTP SHEF: Tune"
        tuneRequest = SHEFTuneRequest(major = "262")
        responseJSON = tuneRequest.send()
        print responseJSON
        expectedtuneResponse = SHEFtuneResponse()
        testresult = expectedtuneResponse.verifyExpectedChannel(responseJSON)
        BaseTest.passedTest = testresult
    
    def SHEFtuneGlow(self):
        '''
        #author: ThanhHo
        Date: 8-Nov
        '''
        BaseTest.testCaseID = self.id()
        print "HTTP SHEF: tune-Glow"
        tuneRequest = SHEFTuneRequest(major = "262", source = 1)
        responseJSON = tuneRequest.send()
        print responseJSON
        expectedtuneResponse = SHEFtuneResponse()
        testresult = expectedtuneResponse.verifyExpectedChannel(responseJSON)
        BaseTest.passedTest = testresult        
        
    def SHEFtunePrivate(self):
        '''
        #author: ThanhHo
        Date: 8-Nov
        '''
        BaseTest.testCaseID = self.id()
        print "HTTP SHEF: tune-Private"
        tunePrivateRequest = SHEFtunePrivateRequest(major = "262")
        responseJSON = tunePrivateRequest.send()
        print responseJSON
        expectedtunePrivateResponse = tunePrivateResponse()
        testresult = expectedtunePrivateResponse.verifyExpectedChannel(responseJSON)
        BaseTest.passedTest = testresult
        
    def SHEFgetProgInfo(self):
        
        '''
        #author: ThanhHo
        def: Get Program Info
        http://STBIP:port/tv/getProgInfo?major=num[&minor=num][&time=num][&clientAddr=string]
                       
        '''
        BaseTest.testCaseID = self.id()
        remoteKeyRequest = RemoteKeyRequest(key = "exit", hold = None, clientAddr=STBConfiguration.CxclientAddr)
        remoteresponseJSON = remoteKeyRequest.send()
        time.sleep(5)
        tvgetProgInfoRequest = TVgetProgInfoRequest (major= "292", minor=None, time=None, clientAddr=STBConfiguration.CxclientAddr)
        responseJSON = tvgetProgInfoRequest.send()
        print responseJSON
        expectedgetProgInfoResponse = TVgetProgInfoResponse (channelName = "DXDHD", channelIndex = 292 )
        testresult = expectedgetProgInfoResponse.verifyExpectedProgInfo(responseJSON)
        BaseTest.passedTest = testresult
        
    def SHEFDisplayGetPlaylist(self):
        '''
        Created on Nov 07, 2017
        @author: nhantq        
        '''
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Display getPlaylist using SHEF command"
        requestPlaylist = SHEFGetPlaylistRequest(type='all')
        result = requestPlaylist.send()
        print result
        BaseTest.passedTest = True
    
    def SHEFGenieGetPlaylist(self):
        '''
        Created on Nov 07, 2017
        @author: nhantq
        '''
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Display getPlaylist using SHEF command"
        requestPlaylist = SHEFGetPlaylistRequest(type='genie')
        result = requestPlaylist.send()
        print result
        BaseTest.passedTest = True   
        
    def SHEFgetVersion(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        #print "This test case prints out the info of STB including receiverID, CAMID and STBSoftwareVersion"
        logger.log("INFO", "This test case prints out the info of STB including receiverID, CAMID and STBSoftwareVersion")
        result = SHEFHTTPRequest.GetVersion()
        logger.log("INFO",result.send())
        BaseTest.passedTest = True     
        
    def SHEFgetOptions(self):
        '''
        @author: tienttt        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case prints out the options of STB "
        result = SHEFHTTPRequest.GetOptions()
        print(result.send())
        BaseTest.passedTest = True
        
    def SHEFModeInfo(self):
        '''
        @author: tienttt        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case prints out the options of STB "
        result = SHEFHTTPRequest.ModeInfo()
        print(result.send())
        BaseTest.passedTest = True   
        
    def SHEFgetSettings(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case prints out the settings of STB"
        result = SHEFHTTPRequest.GetSettings()
        print(result.send())
        BaseTest.passedTest = True     
        
    def SHEFgetToDoList(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case displays all booking, schedule in To Do List"
        getToDoList = SHEFHTTPRequest.ToDoListRequest(action='get')
        print(getToDoList.send())
        BaseTest.passedTest = True     
    
    def SHEFdeleteToDoList(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case delete one booking, schedule in To Do List"
        deleteToDoList = SHEFHTTPRequest.ToDoListRequest(action='delete', id=6) # id number of booking/scheduler please refer to id number of get to do list command
        deleteResult = deleteToDoList.send()
        if deleteResult == 200:
            BaseTest.passedTest = True
            print('Id of booking/schedule is deleted successfully')
        else:
            BaseTest.passedTest = False
            print('Invalid Id of booking, please double check')         
    
    def SHEFmodifyToDoList(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case modify keepUntil, start and stop info of booking, schedule in To Do List" #keepUntil, start and stop info of booking/scheduler please refer to keepUntil, start and stop info of get to do list command
        modifyTodoList = SHEFHTTPRequest.ToDoListRequest(action='modify', id=10, keepUntil=1, start=1, stop=1)
        modifyResult = modifyTodoList.send()
        if modifyResult == 200:
            BaseTest.passedTest = True
            print('Id of booking/schedule is deleted successfully')
        else:
            BaseTest.passedTest = False
            print('Invalid Id of booking, please double check')    
            BaseTest.passedTest = True
    
    def SHEFgetSeriesManger(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case displays all series booking in Series Manager" 
        getSeries = SHEFHTTPRequest.SeriesManagerRequest(action='get')
        print(getSeries.send())
        BaseTest.passedTest = True
        
    def SHEFmodifySeriesManger(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case modify espisodeType, keepAtMost, keepUntil, start, stop and id info of series booking in Series Manager" #espisodeType, keepAtMost, keepUntil, start, stop and id  info of series booking please refer to info of get series manager command
        modifySeries = SHEFHTTPRequest.SeriesManagerRequest(action='modify', id=21, episodeType=1, keepAtMost=5, keepUntil=0, start=0, stop=0)
        modifyResult = modifySeries.send()
        if modifyResult == 200:
            BaseTest.passedTest = True
            print('Series is updated successfully')
        else:
            BaseTest.passedTest = False
            print('Invalid Id of series, please double check') 
        
    def SHEFdeleteSeriesManger(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case delete one series booking in Series Manager"
        deleteSeries = SHEFHTTPRequest.SeriesManagerRequest(action='delete', id=21) # id number of booking/scheduler please refer to id number of get series manager command
        deleteResult = deleteSeries.send()
        if deleteResult == 200:
            BaseTest.passedTest = True
            print('Series is deleted successfully')
        else:
            BaseTest.passedTest = False
            print('Invalid Id of series, please double check') 
        
    def SHEFPlaybackRecording_UniqueId(self):
        '''
        @author: nhantq
        '''
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Playback a recording in playlist by uniqueId using SHEF command"
        requestPlaylist = SHEFPlaybackRequest(uniqueId=11, playFrom='start')
        result = requestPlaylist.send()
        print result
        BaseTest.passedTest = True
        
    def SHEFPlaybackVOD_MaterialId(self):
    #@author: nhantq
                
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Playback a VOD by materialId using SHEF command"
        #requestPlaylist = SHEFPlaybackRequest(materialId='X000023638M3', playFrom='start')
        #result = requestPlaylist.send()
        #print result
        #BaseTest.passedTest = True
        
    def SHEFPlaybackVOD_MaterialId_withOffset(self):
        #author: nhantq
        
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Playback a VOD by materialId using SHEF command"
        requestPlaylist = SHEFPlaybackRequest(materialId='B001083276M3', playFrom='offset', offset=500)
        result = requestPlaylist.send()
        print result
        BaseTest.passedTest = True
     
    def RemoteKeySHEFonClient_SendRemoteKeySHEF(self):
        #author: Nhanqt 
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Send Remote Key on Client using SHEF command"
        requestkey = RemoteKeyRequest(key='guide', clientAddr=STBConfiguration.CxclientAddr)
        result = requestkey.send()        
        time.sleep(3)        
        print result
        BaseTest.passedTest = True
        
    def SHEFDisplayPlaylist(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Display playlist items using SHEF command and find a recording exist or not"
        requestPlaylist = SHEFPlaylistRequest(action='get',type='user')
        result = requestPlaylist.send()
        #print json.dumps(result)
        datasearch = json.dumps(result)
        print "datasearch is %s" % datasearch      
        if datasearch.find("The Looney Tunes Show") != -1:
            print "The Looney Tunes Show is existing in playlist"                
        else:
            print "Program is not found"        
        BaseTest.passedTest = True
        
    def SHEFDeleteItemInPlaylist(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Delete item in playlist using SHEF command"
        requestPlaylist = SHEFPlaylistRequest(action='delete',uniqueId=11)
        result = requestPlaylist.send()
        print result
        BaseTest.passedTest = True    
    
    def SHEFRecordPrivate_Onetouch(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Record one touch using SHEF command"
        requestRecord = SHEFRecordPrivateRequest(type='oneTouch',major=299)
        result = requestRecord.send()
        print result
        BaseTest.passedTest = True 
        
    def SHEFRecordPrivate_Manual(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Record manual using SHEF command"
        requestRecord = SHEFRecordPrivateRequest(type='manual',major=542, recurrence='daily')
        result = requestRecord.send()
        print result
        BaseTest.passedTest = True
    
    def SHEFRecordPrivate_Series(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Record series using SHEF command"
        requestRecord = SHEFRecordPrivateRequest(type='series',major=296)
        result = requestRecord.send()
        print result
        BaseTest.passedTest = True 
        
    def SHEFgetProgInfoPrivate(self):
        '''
        #author: ThanhHo
        def: Get Program Info Private
        http://STBIP:port/tv/getProgInfo?major=num[&minor=num][&time=num][&clientAddr=string]
                       
        '''
        BaseTest.testCaseID = self.id()  
        tvgetProgInfoPrivateRequest = TVgetProgInfoPrivateRequest (major="262", minor = None, time = None, honorPC = False, clientAddr = None)
        responseJSON = tvgetProgInfoPrivateRequest.send()
        expectedgetProgInfoPrivateResponse = TVgetProgInfoPrivateResponse (channelName = "REAL", channelIndex = 262)
        testresult = expectedgetProgInfoPrivateResponse.verifyExpectedProgInfoPrivate(responseJSON)
        BaseTest.passedTest = testresult

    def SHEFgetTunedPrivate(self):
        '''
        #author: ThanhHo
        def: Get Program Info Private
        http://STBIP:port/tv/getProgInfo?major=num[&minor=num][&time=num][&clientAddr=string]
                       
        '''
        BaseTest.testCaseID = self.id()
        print "SHEF - getTunedPrivate"
        STBControl.executeCommand("watch -channel 262")
        tvgetTunedPrivateRequest = TVGetTunedPrivateRequest()
        responseJSON = tvgetTunedPrivateRequest.send()
        print responseJSON
        expectedgetTunedPrivateResponse = TVGetTunedPrivateResponse(channelName = "REAL", channelIndex = 262)
        testresult = expectedgetTunedPrivateResponse.verifyExpectedChannel(responseJSON)
        BaseTest.passedTest = testresult
    
    def testSampleTestCase0_executeSTBCommand(self):
        BaseTest.testCaseID = self.id()
        result = STBControl.executeCommand("cat /proc/stat")
        print result
        BaseTest.passedTest = True
        
    def testSampleTestCase1_SendRemoteKeySHEF(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE 1 - Send Remote Key using SHEF command"
        result = STBControl.sendRemoteKey("menu", isSHEF=True)
        time.sleep(3)
        print result
        BaseTest.passedTest = True
        
    def testSampleTestCase2_SendRemoteKeyKeyPlayerCommand(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE 2 - Send Remote Key using KeyPlayer command"
        result = STBControl.sendRemoteKey("GUIDE", isSHEF=False) 
        time.sleep(15)
        print result
        BaseTest.passedTest = True
        
    def testSampleTestCase3_SendDTCommandAndgetTVTuned(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE 3 - Send DT Command to tune to channel 202 and get TV tuned"
        #dt command to tune to channel 202 - dt watch -channel 202
        STBControl.sendDTCommand("watch -channel 202")
        time.sleep(5)
        STBControl.sendRemoteKey("exit", isSHEF=False) #OPTIONAL STEP - If the screen has GUIDE or MENU displayed, pressing EXIT will make the channel displayed in full screen
        time.sleep(5)
        tvGetTunedRequest = TVGetTunedRequest()
        responseJSON = tvGetTunedRequest.send()
        print responseJSON
        expectedTVGetTunedResponsed = TVGetTunedResponse(channelName = "CNNHD", channelIndex = 202)
        testResult = expectedTVGetTunedResponsed.verifyExpectedChannel(getTunedResponseJSON=responseJSON)
        BaseTest.passedTest = testResult
        
    def testSampleTestCase4_PrintScreenShot(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE 4: PrintScreenShot"
        STBControl.takeUIScreenshot(self.id())
        BaseTest.passedTest = True
        
    def testMenuScreenDisplay(self):
        '''
        Test steps
        1. Send menu Key (dt/shef)
        2. Get xml file of the 1st screen from STB to PC --> STB Control (outfile)
        3. Verify screen status (XML_Parser) --> To STBValidation
        4. Send down Key (dt/shef)
        5. Get xml file of the 1st screen from STB to PC --> STB Control (outfile)
        6. Verify screen status (XML_Parser) --> To STBValidation
        '''
        
        BaseTest.testCaseID = self.id()
        print "Test case to verify MENU display"
        #Send MENU key to STB
        STBControl.sendRemoteKey("MENU", isSHEF=False)
        time.sleep(5)
        currentScreenXMLFile = STBControl.getCurrentScreenXMLFile("0_screen_MenuScreen.xml")
        time.sleep(5)
        STBValidations.verifyMenuScreenIsDisplayed(currentScreenXMLFile)
        #STBControl.sendRemoteKey("SELECT", isSHEF=False)
        
        #Send DOWN key to STB
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        time.sleep(5)
        currentScreenXMLFile = STBControl.getCurrentScreenXMLFile("1_screen_MenuScreen.xml")
        time.sleep(5)
        STBValidations.verifyMenuScreenIsDisplayed(currentScreenXMLFile, fieldFocus="Recordings")
        time.sleep(5)
        
        #Send UP key to STB
        STBControl.sendRemoteKey("UP", isSHEF=False)
        time.sleep(5)
        currentScreenXMLFile = STBControl.getCurrentScreenXMLFile("2_screen_MenuScreen.xml")
        time.sleep(5)
        STBValidations.verifyMenuScreenIsDisplayed(currentScreenXMLFile)
        time.sleep(5)
        
        #Send RIGHT key to STB
        STBControl.sendRemoteKey("RIGHT", isSHEF=False)
        time.sleep(5)
        currentScreenXMLFile = STBControl.getCurrentScreenXMLFile("3_screen_MenuScreen.xml")
        time.sleep(5)
        STBValidations.verifyMenuScreenIsDisplayed(currentScreenXMLFile, fieldFocus="default-Poster2Selected")
        time.sleep(5)
        
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        time.sleep(10)
        
        BaseTest.passedTest = True
        
    def testClientTestAgent(self):
        BaseTest.testCaseID = self.id()
        print "Test case to verify MENU display through testing agent library"
        desiredCapabilities = DesiredCapabilities(STBModel="HR54", STBManufacturer="PAC", STBIP="192.168.1.100", STBTestingServerAgentPort="8080")
        driver = STBDriver(desiredCapabilities)
        jsonReturned = driver.sendKey("menu")
        #print jsonReturned
        currentScreenXMLFile = STBControl.getCurrentScreenXMLFile("0_screen_MenuScreen.xml")
        screenXML = STBControl.getCurrentScreenXMLAsDict(currentScreenXMLFile)
        print screenXML
        
        print driver.findElementById(screenXML, "What_On_Now_item_2")
        
        
        BaseTest.passedTest = True
        
    def testParentalControl(self):
        BaseTest.testCaseID = self.id()
        print "Test case to test Parental Control through testing agent library"
        desiredCapabilities = DesiredCapabilities(STBModel="HR54", STBManufacturer="PAC", STBIP="192.168.1.100", STBTestingServerAgentPort="8080")
        driver = STBDriver(desiredCapabilities)
        #Press Menu key to open Menu screen
        STBControl.sendRemoteKey("MENU", isSHEF=False)
        #Press down to move to Setting
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        #Press Right to move to Parental Control
        STBControl.sendRemoteKey("RIGHT", isSHEF=False)
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        #Press Down to move to Movie Ratings
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        #Press 1234 to unlock
        STBControl.sendRemoteKey("1", isSHEF=False)
        STBControl.sendRemoteKey("2", isSHEF=False)
        STBControl.sendRemoteKey("3", isSHEF=False)
        STBControl.sendRemoteKey("4", isSHEF=False)
        #Press down to move to Allow R
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        #Press Exit to back to Live TV screen
        STBControl.sendRemoteKey("EXIT", isSHEF=False)
        #Press Menu Key and play The Batman Movie
        STBControl.sendRemoteKey("MENU", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        
        BaseTest.passedTest = True
    
    