'''
Created on 10 Feb, 2017

@author: vunhh
'''
import xml.etree.ElementTree as ET

class XmlParser(object):

	def __init__(self, filename=None):		
		#self.tree = ET.parse(filename)
		self.root = ET.fromstring(filename)	

	def __str__(self):
		#return self.tree
		return self.root

	def getMenuItemHighlight(self, text):

		selectedMenuItem = self.root.findall(".//LeftMenu/MenuItems/Item[@isSelected='true']")
		if (selectedMenuItem != None):
			#todo, check the text response is in "What's On Now"
			for menu in selectedMenuItem:
				if (menu.text == text):
					return menu.text
		else:
			return None
