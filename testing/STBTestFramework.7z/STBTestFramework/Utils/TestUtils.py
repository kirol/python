'''
Created on Oct 3, 2017

@author: tt4609
'''
import os
import shutil
import subprocess

def cleanTmpFolder():
    currentFolder = os.getcwd()
    tmpFolder = currentFolder + "/tmp/"
    shutil.rmtree(tmpFolder)
    os.makedirs(tmpFolder)
    
def getScreenXML():
    print "TODO"

def monitor_performance(TFWSRV_IP, TFW_USER, TFW_USERPASS, isSSH, minicomTTY, STB_IP, STB_Model, STB_Manufacturer, STBRootPass="how42n8", interval=2, monitorLogTag="RemoteMp4MediaStream"):
    currentFolder = os.getcwd()
    perfScriptLocation = currentFolder + "/Supports/Scripts/performance.tcl" 
    print perfScriptLocation
    if (isSSH):   
        #subprocess.call(["tclsh", "performance.tcl", "1", "192.168.12.80", "jcung", "password", "ttyS6", "192.168.12.112", "hr44", "pace", "root", "how42n8", "how42n8 happy2code", "3", "RemoteMp4MediaStream"]) 
        minicomTTY = "NO_NEED"
        subprocess.call(["tclsh", perfScriptLocation, "1", TFWSRV_IP, TFW_USER, TFW_USERPASS, minicomTTY, STB_IP, STB_Model, STB_Manufacturer, "root", STBRootPass, "how42n8 happy2code", interval, monitorLogTag]) 
    else:
        STB_IP = "NO_NEED"
        subprocess.call(["tclsh", perfScriptLocation, "0", TFWSRV_IP, TFW_USER, TFW_USERPASS, minicomTTY, STB_IP, STB_Model, STB_Manufacturer, "root", STBRootPass, "how42n8 happy2code", interval, monitorLogTag]) 
