'''
Created on Aug 1, 2017

@author: tt4609
'''
from web.utils import subprocess

def sayUtterance(utterance):
    ####Send Adb command to Android app
    subprocess.call(["adb", "shell", "am", "broadcast", "-a", "voiceutilities.thanhminhtran.net.voiceutilities.intent.TEST", "-e", "testString", "'start_tts_" + utterance + "'"])
        
def sayUtteranceAndRecognize(utterance):   
    subprocess.call(["adb", "shell", "am", "broadcast", "-a", "voiceutilities.thanhminhtran.net.voiceutilities.intent.TEST", "-e", "testString", "'start_ttsWithResponse_" + utterance + "'"])