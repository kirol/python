'''
Created on Apr 11, 2017

@author: thanhtran
'''
import logging


#log_handler = logging.FileHandler(filename = '../TestLogs/logfile.log')
#log_handler.setFormatter(logging.Formatter(fmt='%(asctime)s| %(levelname)s| %(message)s'))
#logger = logging.getLogger()
#logger.setLevel(logging.INFO)
#logger.addHandler(log_handler)

class Logger:   
    #logger = logging.getLogger()
    logger = None
    log_handler = None#logging.FileHandler()
    fileName = None
    fmt = None
    def __init__(self, fileName = '../TestLogs/logfile.log', fmt = '%(asctime)s| %(levelname)s| %(message)s'):
        global  log_handler
        #log_handler = logging.FileHandler(filename = '../TestLogs/logfile.log')
        if fileName != None :
            self.fileName = fileName
            log_handler = logging.FileHandler(self.fileName)
        #log_handler.setFormatter(logging.Formatter(fmt='%(asctime)s| %(levelname)s| %(message)s'))
        
        if fmt != None:
            self.fmt = fmt
            log_handler.setFormatter(logging.Formatter(fmt))
        global logger
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        logger.addHandler(log_handler)
        
    def critical(self, msg):
        logger.critical(msg)
        
    def error(self, msg):
        logger.error(msg)

    def warning(self, msg):
        logger.warning(msg)
        
    def info(self, msg):
        logger.info(msg)
        
    def debug(self, msg):
        logger.debug(msg)
          
    def logAssertion(self, msg, condition, actual = None, expected = None):
        if actual is None and expected is None:
            if not condition:
                logger.error(msg)
                assert condition, msg
        else:
            if not condition:
                logger.error(msg);
                logger.error("Actual result: " + actual)
                logger.error("Expected result: " + expected)
                assert condition, msg
    
    def logErrorMessage(self, msg, condition, actual, expected):
        if not condition:
            logger.error(msg);
            if actual != None:
                logger.error("Actual result: " + actual)
            if expected != None:
                logger.error("Expected result: " + expected)
    
    def writeResult(self, condition):
        if condition:
            logger.info("PASS");
        else:
            #assert condition,''
            logger.info("FAIL")

    def log(self, level, msg):
        if level == "WARNING":
            self.warning(msg)
        elif level == "DEBUG":
            self.debug(msg)
        elif level == "CRITICAL":
            self.critical(msg)
        elif level == "ERROR":
            self.error(msg)
        else :
            self.info(msg)