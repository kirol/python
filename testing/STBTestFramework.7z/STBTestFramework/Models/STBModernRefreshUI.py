'''
Created on Oct 3, 2017

@author: thanhtran
'''

class menuScreen:
    menuTitle = "Menu"
    defaultLeftMenuItems = ("What's On Now", "Recordings", "On Demand", "Discover")