'''
Created on Jun 27, 2017

@author: thanhtran
'''
STBModel = "HR54"
STBManufacturer = "PAC"
CxclientAddr = "B4F2E847A20E"
SSHUsername = "root"
SSHRootPass = "how42n8"
shefUsername = "super"
shefPassword = "super1"
STBIPAddress = "192.168.1.101"
STBSHEFCMDPort = "8080"
keycodeLocation = "/var/viewer/keycode/"
screenXMLLocation = "/var/viewer/screens/"
SHEFKeyRemoteURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/remote/processKey"
SHEFTVGetTunedURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/getTuned"

#author: Nhanqt
SHEFPlaylistURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/playList"
SHEFRecordPrivateURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/recordPrivate"
SHEFPlaybackURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/play"
SHEFGetPlaylistURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/getPlayList"
SHEFPlaybackViaMRVURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/play?udn=uuid:DIRECTV2PC-Media-Server1_0-RID-0"
MRVIPAddress = "192.168.51.102" 
SHEFGetPlaylistPrivateURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/getPlayListPrivate"
SHEFDRMURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/drm"
SHEFNotificationforVoiceURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/notification/voice"

#ThanhHo
SHEFVGetTunedPrivateURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/getTunedPrivate"
SHEFgetProgInfoURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/getProgInfo"
SHEFgetProgInfoPrivateURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/getProgInfoPrivate"
SHEFtunePrivateURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/tunePrivate"
SHEFTuneURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/tune"
SHEFgetSTBLocationsURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/info/getLocations"
SHEFSerialCommandURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/serial/processCommand"
SHEFgetMyTeamURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/info/getMyTeam"
SHEFgetHDDStatusURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/info/getHDDStatus"
