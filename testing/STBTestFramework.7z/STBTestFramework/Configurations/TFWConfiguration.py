'''
Created on Oct 23, 2017

@author: tt4609
'''

TFWSRV_IP = "192.168.1.200"
TFWSRV_USERID = "tt4609"
TFWSRV_USERPASS = "Ch1chB0ng21o5"
