'''
Created on Apr 10, 2017

@author: thanhtran
'''
import paramiko
import requests
from Configurations import STBConfiguration 
from Controllers.SHEFHTTPRequest import RemoteKeyRequest
from Validations.STBValidations import STBValidation
from web.utils import subprocess
import os
import os.path
import xml.etree.ElementTree as ET
import time
import xmltodict

ssh = paramiko.SSHClient()

def sshSTB():
    print "Doing SSH"
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(hostname=STBConfiguration.STBIPAddress, username=STBConfiguration.SSHUsername, password=STBConfiguration.SSHRootPass)
        print "Connected OK!!!"
        #ssh.exec_command("")
    except paramiko.SSHException:
        print "Connection Failed"
        quit()

def sendRemoteKey(remoteKey, isSHEF=True, _holdStatus=None):
    print("Pressing remote key " + remoteKey)
    result = None
    if (isSHEF):
        if (_holdStatus != None):
            result = sendRemoteKeySHEFCommand(remoteKey, _holdStatus)
        else:
            result = sendRemoteKeySHEFCommand(remoteKey, "keyPress") #hold status default: keyPress
    else:
        result = sendRemoteKeyKeyPlayerCommand(remoteKey)
    time.sleep(1)
    return result

def sendRemoteKeyKeyPlayerCommand(remoteKey):
    consoleOutput = ""
    sshSTB()
    std_in,std_out,std_err =ssh.exec_command("/opt/key_dispatcher/bin/keyplayer " + STBConfiguration.keycodeLocation + remoteKey + '.sid')
    #for line in std_out.read().splitlines():
    #    print(line) 
    consoleOutput = std_out.read()
    print consoleOutput
    std_in.flush()
    std_out.flush()
    std_err.flush()
    ssh.close()
    return consoleOutput
   
def sendRemoteKeySHEFCommand(remoteKey, holdStatus):
    #remotekey should follow SHEF commands
    print "Pressing key " + remoteKey + " using SHEF"
    #urlSendKey = "http://" + STBConfiguration.STBIPAddress + ":" + STBConfiguration.STBSHEFCMDPort + "/remote/processKey?key=" + remoteKey + "&hold=" + holdStatus
    #r = requests.get(urlSendKey)
    #if (r.status_code == 200 and "\"msg\": \"OK.\"" in r.text):
    #    print("Send key successfully!!!")
    menuKeyRemote = RemoteKeyRequest(key="menu")
    responseJSON = menuKeyRemote.send()
    return responseJSON

def sendDTCommand(dtCommand):
    consoleOutput = ""
    sshSTB()
    std_in,std_out,std_err =ssh.exec_command("dt " + dtCommand)
    #for line in std_out.read().splitlines():
    #    print(line) 
    consoleOutput = std_out.read()
    #print consoleOutput
    std_in.flush()
    std_out.flush()
    std_err.flush()
    ssh.close()
    return consoleOutput

def executeCommand(STBCommand):
    consoleOutput = ""
    sshSTB()
    std_in,std_out,std_err =ssh.exec_command(STBCommand)
    #for line in std_out.read().splitlines():
    #    print(line) 
    consoleOutput = std_out.read()
    #print consoleOutput
    std_in.flush()
    std_out.flush()
    std_err.flush()
    ssh.close()
    return consoleOutput

def takeUIScreenshot(testcaseID):
    print "Executing..."    
    #sshSTB(ssh, STBConfiguration.SSHUsername, STBConfiguration.SSHRootPass)
    sshSTB()
    output_file = "/var/tmp/" + testcaseID[testcaseID.rfind('.')+1:] +".png"
    cmd = "/root/screenshot.sh " + output_file    
    #std_in,std_out,std_err = ssh.exec_command()
    std_in,std_out,std_err =ssh.exec_command(cmd)
    #copy file to Data folder
    #std_in,std_out,std_err =ssh.exec_command("scp " + output_file + " localhost:/TestData/ ")
    std_in.flush()
    ssh.close()
      
def sendRecommendationsRequest():
    #http://STBIP:port/tv/recommendations?[clientAddr=string][&modType=int]
    print "in Proc sendRecommendationsRequest"
    urlSendKey = "http://" + STBConfiguration.STBIPAddress + ":" + STBConfiguration.STBSHEFCMDPort + "/tv/recommendations?clientAddr=0&modType=0"
    print urlSendKey
    r = requests.get(urlSendKey)
    if (r.status_code == 200 and "\"msg\": \"OK.\"" in r.text):
        print r.text
    #store json output from shef


def getCurrentScreenXMLFile(filename):
    #This function call DT command to generate the screen as XML file
    #Then execute scp command to get XML file from STB to the tmp folder
    #### sshpass should be installed for the machine running test framework
    print "Send DT command to generate screen XML file..."
    sendDTCommand("exportXml")
    #from_file = "/var/viewer/screens/" + filename
    from_file = "/var/viewer/screens/" + filename
    to_file = os.getcwd() + "/tmp/" + filename
    #cmd = "sshpass -p scp " + from_file + STBConfiguration.LinuxUser + "@" + STBConfiguration.LinuxIP + ":/data/tmp/"
    #std_in,std_out,std_err = ssh.exec_command()
    #std_in,std_out,std_err =ssh.exec_command(cmd)
    #copy file to Data folder
    #std_in,std_out,std_err =ssh.exec_command("scp " + output_file + " localhost:/TestData/ ")
    #std_in.flush()
    #ssh.close()
    from_location = STBConfiguration.SSHUsername + "@" + STBConfiguration.STBIPAddress + ":"
    subprocess.call(["sshpass", "-p", STBConfiguration.SSHRootPass, "scp", from_location + from_file, to_file])
    xmlScreen = None
    if os.path.exists(to_file):
        return to_file
    else:
        return xmlScreen
    
def getCurrentScreenXMLAsDict(screenXMLFile):
    with open(screenXMLFile) as fd:
        xmldoc = xmltodict.parse(fd.read())
    return xmldoc
    
def cleanUpScreenXMLFiles():
    print "Removing all XML files..."
    sshSTB()
    cmd = "rm -f /var/viewer/screens/*"
    std_in,std_out,std_err =ssh.exec_command(cmd)
    #copy file to Data folder
    #std_in,std_out,std_err =ssh.exec_command("scp " + output_file + " localhost:/TestData/ ")
    std_in.flush()
    ssh.close()   

#author: Nhanqt

def CopyKeycodeFolderToSTB():
#keycode folder is located at server build 106: /data/tftpboot/NewFeature/TFW4BAU/keycode/
    print "Copying keycode folder to STB"     
    to_STB = STBConfiguration.SSHUsername + "@" + STBConfiguration.STBIPAddress + ":"    
    keycode_source = "../TestData/keycode"   
    subprocess.call(['sshpass', '-p', STBConfiguration.SSHRootPass, 'scp', '-r', keycode_source, to_STB + "/var/viewer/"])
          
def VerifyKeycodeIsAvailable():
    sshSTB()
    std_in,std_out,std_err =ssh.exec_command('ls /var/viewer/keycode')    
    if std_out.read() != "":          
        print "Keycode folder is available in STB"
    else:
        print "Keycode folder is unavailable. Please copy it to your STB"
        CopyKeycodeFolderToSTB() 
    ssh.close()

def sshtoMRVSTB():
    '''
    Created on Nov 09, 2017
    @author:Nhanqt    
    '''
    print "Doing SSH to the MRV server"
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(hostname=STBConfiguration.MRVIPAddress, username=STBConfiguration.SSHUsername, password=STBConfiguration.SSHRootPass)
        print "Connected OK!!!"
        #ssh.exec_command("")
    except paramiko.SSHException:
        print "Connection Failed"
        quit()    
def executeCommandonMRVbox(MRVcommand):
    '''
    Created on Nov 09, 2017
    @author:Nhanqt    
    '''
    sshtoMRVSTB()
    std_in,std_out,std_err=ssh.exec_command(MRVcommand)
    MRVoutput=std_out.read()
    print MRVoutput
    std_in.flush()
    std_out.flush()
    std_err.flush()
    ssh.close()
    return MRVoutput
    
    
    
