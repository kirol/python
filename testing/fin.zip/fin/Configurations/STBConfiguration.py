'''
Created on Jun 27, 2017

@author: thanhtran
'''
STBModel = "HR54"
STBManufacturer = "PAC"
CxclientAddr = "B4F2E847A20E"
SSHUsername = "root"
SSHRootPass = "how42n8"
shefUsername = "super"
shefPassword = "super1"
STBIPAddress = "192.168.154.17"
STBSHEFCMDPort = "8080"
HTTPRequestPort = "8383"
keycodeLocation = "/var/viewer/keycode/"
screenXMLLocation = "/var/viewer/screens/"
SHEFKeyRemoteURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/remote/processKey"
SHEFTVGetTunedURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/getTuned"

#author: Nhanqt
SHEFPlaylistURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/playList"
SHEFRecordPrivateURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/recordPrivate"
SHEFPlaybackURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/play"
SHEFGetPlaylistURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/getPlayList"
SHEFPlaybackViaMRVURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/play?udn=uuid:DIRECTV2PC-Media-Server1_0-RID-0"
MRVIPAddress = "192.168.51.102" 
SHEFGetPlaylistPrivateURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/dvr/getPlayListPrivate"
SHEFDRMURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/drm"
SHEFNotificationforVoiceURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/notification/voice"
KeyPressURL = 'http://' + STBIPAddress + ':' + HTTPRequestPort + '/rest/key --noproxy ' + STBIPAddress
sendDTcommandURL = 'http://' + STBIPAddress + ':' + HTTPRequestPort + '/rest/dt --noproxy ' + STBIPAddress

#Minhqly
GetUIScreenshotURL = "http://" + STBIPAddress + ":" + HTTPRequestPort + "/rest/ui/screenshot"
GetCurrentScreenInfoURL = "http://" + STBIPAddress + ":" + HTTPRequestPort + "/rest/ui/screen"
playReadyURL = "http://" + STBIPAddress + ":" + HTTPRequestPort + "/rest/dt"

#tienttt
GetMGSURL = "http://" + STBIPAddress + ":" + HTTPRequestPort + "/rest/ui/screen"
GetScreenShotURL = 'http://' + STBIPAddress + ':' + HTTPRequestPort + '/rest/screenshot --noproxy ' + STBIPAddress

#ThanhHo
SHEFVGetTunedPrivateURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/getTunedPrivate"
SHEFgetProgInfoURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/getProgInfo"
SHEFgetProgInfoPrivateURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/getProgInfoPrivate"
SHEFtunePrivateURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/tunePrivate"
SHEFTuneURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/tv/tune"
SHEFgetSTBLocationsURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/info/getLocations"
SHEFSerialCommandURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/serial/processCommand"
SHEFgetMyTeamURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/info/getMyTeam"
SHEFgetHDDStatusURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/info/getHDDStatus"
SHEFGraphicsModeURL = "http://" + STBIPAddress + ":" + STBSHEFCMDPort + "/voice/graphics"