'''
Created on Oct 23, 2017

@author: tt4609 - Thanh Tran
'''
import os

TFWSRV_IP = "192.168.154.14"
TFWSRV_USERID = ""
TFWSRV_USERPASS = ""
TFW_WEBSERVER = "/WebServer/"
TFW_TEMP_DIR = "/tmp/"
TFW_WEBSERVER_PORT = 8009
TFW_ITV_SAMPLE_APP_1_URL = "http://" + TFWSRV_IP + ":" + str(TFW_WEBSERVER_PORT) + "/iTVSampleApp/iTVTestApp.html"