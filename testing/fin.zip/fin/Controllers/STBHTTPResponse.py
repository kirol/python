'''
Created on Dec 05, 2017

@author: Nhan Tran
'''
import os
import requests
from requests.auth import HTTPDigestAuth
import json
   
class KeyPressResponse:     
    def verifyKeyPressResponse(self, keyResponse):
        if keyResponse.find("\"status\":\"Success\"") != -1:
            return True
        else:
            return False
        
class sendDTcommandResponse:     
    def verifysendDTcommandResponse(self, commandResponse):
        if type(commandResponse) is dict:
            if commandResponse['status']['code'] is 200:
                return True
            else:
                return False
        else:
            return False
        
        
def sendPlayReadyCommandResponse(commandResponse):
    if type(commandResponse) is dict:
        if commandResponse['status']['code'] is 200:
            return True
        else:
            return False
    else:
        return False
    
    
    
    