'''
Created on Dec 05, 2017

@author: Nhan Tran
'''
import os
import requests
from requests.auth import HTTPDigestAuth
from Configurations import STBConfiguration
from Configurations import TFWConfiguration
import json
from sepolgen.defaults import headers
import subprocess

   
def KeyPressRequest(keypress):
    KeyPressURL = STBConfiguration.KeyPressURL        
    datarequest = {'sessionId': '0','remoteType': 'ir','time': 1}
    datarequest['key'] = keypress
    p = subprocess.Popen(['curl','-X','POST','--data',json.dumps(datarequest),KeyPressURL],stdout=subprocess.PIPE)
    output,err = p.communicate()
    result = json.dumps(output)
    return result    

def sendDTcommandResquest():
    URLcommand = STBConfiguration.sendDTcommandURL
    dataRequest = {"args": {"override": "true","url": TFWConfiguration.TFW_ITV_SAMPLE_APP_1_URL,"sessionId": "0"},"command": "itvStartApp"}
    subprocess.call(['curl','-X','POST','--data', json.dumps(dataRequest),URLcommand])

def sendPlayReadyCommandRequest():
    URLcommand = STBConfiguration.playReadyURL
    dataRequest = {"command": "startStream","args": {"sessionId": "0","cmd": "load","url": "http://dash.edgesuite.net/akamai/bbb_30fps/bbb_30fps.mpd","type": "dash"}}
    p = subprocess.Popen(['curl','-X','POST','--data',json.dumps(dataRequest),URLcommand],stdout=subprocess.PIPE)
    output,err = p.communicate()
    result = json.dumps(output)
    return result    
    
def sendDTcommandResquestFailure():
    TFW_ITV_SAMPLE_APP_FAIL_URL = "http://192.168.154.5:8999" + "/iTVSampleApp/iTVTestApp.html"
    URLcommand = STBConfiguration.sendDTcommandURL
    dataRequest = {"args": {"override": "true","url": TFW_ITV_SAMPLE_APP_FAIL_URL,"sessionId": "0"},"command": "itvStartApp"}
    subprocess.call(['curl','-X','POST','--data', json.dumps(dataRequest),URLcommand])
	
def getScreenshot():
    URLcommand = STBConfiguration.GetScreenShotURL
    dataRequest = {}
    subprocess.call(['curl','-X','GET','--data', json.dumps(dataRequest),URLcommand])

    