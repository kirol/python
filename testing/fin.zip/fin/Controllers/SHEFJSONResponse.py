'''
Created on Apr 14, 2017

@author: thanhtran
'''

import json

class SHEFGraphicsModeResponse:
    '''
    #author: ThanhHo
    http://STBIP:port/voice/graphics?action=string[&state=num][&commandId=num][&clientAddr=string]
    Date: 10-Nov
    '''
    _action = None
    _state = None
    
    def __init__(self, action, state):
        self._action = action
        self._state = state
        
    def verifyExpectedChannel(self, GraphicsModeResponseJSON):
        if type(GraphicsModeResponseJSON) is dict:
            if GraphicsModeResponseJSON['status']['code'] is 200:
                print("Successful response code return - %d ") %  GraphicsModeResponseJSON['status']['code']
                #print ("State is requested: %d") % GraphicsModeResponseJSON['state']
                if self._action is "get":                    
                    print ("State is response: %d") % GraphicsModeResponseJSON['state']
                else : 
                #if self._action is "set":
                    if self._state == 1:
                        print ("The STB enters to Enter Poster Graphics mode")
                    elif self._state == 2:
                        print ("The STB enters to Exit Poster Graphics mode")
                    elif self._state == 3:
                        print ("The STB enters to Cancel Poster Graphics Display")
                    else :
                        print ("The STB enters invalid value")    
                print("Message returns: %s") % GraphicsModeResponseJSON['status']['msg']
                return True
            else:
                print "Error message returns: %s" % GraphicsModeResponseJSON['status']['msg']
                return False
        else:
            print("Error: not JSON object")
            return False
    
class VoiceResponse:
    '''
    Created on Nov 08, 2017
    @author: Nhanqt    
    def: Verify DRM status
    '''     
    def verifyNotificationforVoice(self, getVoiceResponseJSON):
        if type(getVoiceResponseJSON) is dict:
            if getVoiceResponseJSON['status']['code'] is 200 and getVoiceResponseJSON['isRegistered'] is True:
                print "Voice Controller is registered"                
            else:
                print "Voice Controller is NOT registered"
            return True   
        else:
            print("Error: not JSON object" )
            return False

class SHEFgetHDDStatusResponse:
    '''
	#author: ThanhHo
    http://STBIP:port/info/getHDDStatus
    Date: 9-Nov
    '''
    def verifyExpectedChannel(self, getHDDStatusResponseJSON):
        if type(getHDDStatusResponseJSON) is dict:
            if getHDDStatusResponseJSON['status']['code'] is 200:
                print("Successful response code return - %d " %  getHDDStatusResponseJSON['status']['code'])
                return True
            else:
                print("ErrorMessage - %s" %  getHDDStatusResponseJSON['status']['msg'])
                return False
        else:
            print("Error: not JSON object" )
            return False

class SHEFgetMyTeamResponse:
    '''
	#author: ThanhHo
	http://STBIP:port/info/getMyTeam
    Date: 9-Nov
	'''
    def verifyExpectedChannel(self, getMyTeamResponseJSON):
        if type(getMyTeamResponseJSON) is dict:
            if getMyTeamResponseJSON['status']['code'] is 200:
                print("Successful response code return - %d " %  getMyTeamResponseJSON['status']['code'])
                return True
            else:
                print("Error Message - %s" %  getMyTeamResponseJSON['status']['msg'])
                return False		
        else:
            print("Error: not JSON object" )
            return False

class SHEFSerialCommandResponse:
    '''
	#author: ThanhHo
	http://STBIP:port/serial/processCommand?cmd=string
	Date: 9-Nov
	'''
    _cmd = None
    
    def __init__(self, cmd = None):
        self._type = type
    
    def verifyExpectedChannel(self, SerialCommandResponseJSON):
        if type(SerialCommandResponseJSON) is dict:
            if SerialCommandResponseJSON['status']['code'] is 200:
                print("Successful response code return - %d " %  SerialCommandResponseJSON['status']['code'])
                return True
            else:
                print("Error Message - %s" %  SerialCommandResponseJSON['status']['msg'])
                return False
        else:
            print("Error: not JSON object" )
            return False

class DRMInfoResponse:
    '''
    Created on Nov 08, 2017
    @author: Nhanqt    
    def: Verify DRM status
    ''' 	
    def verifyExpectedDRMStatus(self, getDRMInfoResponseJSON):
        if type(getDRMInfoResponseJSON) is dict:
            if getDRMInfoResponseJSON['status']['code'] is 200 and getDRMInfoResponseJSON['isReady'] is True:
                print "DRM is ready"
                
            else:
                print "DRM is NOT ready"
            return True   
        else:
            print("Error: not JSON object" )
            return False

class SHEFgetSTBLocationsResponse:
    '''
    #author: ThanhHo
    http://STBIP:port/info/getLocations?[type=num]
    Date: 8-Nov
    '''
    _type = None
    
    def __init__(self, type = None):
        self._type = type
    
    def verifyExpectedChannel(self, getSTBLocationsResponseJSON):
        if type(getSTBLocationsResponseJSON) is dict:
            if getSTBLocationsResponseJSON['status']['code'] is 200:
                print("Successful response code return - %d " %  getSTBLocationsResponseJSON['status']['code'])
                return True
            else:
                print("Error Message - %s" %  getSTBLocationsResponseJSON['status']['msg'])
                return False
        else:
            print("Error: not JSON object" )
            return False

class SHEFtuneResponse:
    '''
    #author: ThanhHo
    def: SHEF Tune Private
    http://STBIP:port/tv/tunePrivate?major=num[&minor=num][&honorPC=boolean][&clientAddr=string][&source=num]
    Date: 8-Nov
    '''
    def verifyExpectedChannel(self, tuneResponseJSON):
        if type(tuneResponseJSON) is dict:
            if tuneResponseJSON['status']['code'] is 200:
                print("Successful response code return - %d " %  tuneResponseJSON['status']['code'])
                return True
            else:
                print("ErrorMessage - %s" %  tuneResponseJSON['status']['msg'])
                return False
        else:
            print("Error: not JSON object" )
            return False
    
class tunePrivateResponse:
    '''
    #author: ThanhHo
    def: SHEF Tune Private
    http://STBIP:port/tv/tunePrivate?major=num[&minor=num][&honorPC=boolean][&clientAddr=string][&source=num]
    Date: 8-Nov
    '''
    def verifyExpectedChannel(self, tunePrivateResponseJSON):
        if type(tunePrivateResponseJSON) is dict:
            if tunePrivateResponseJSON['status']['code'] is 200:
                print("Successful response code return - %d " %  tunePrivateResponseJSON['status']['code'])
                return True
            else:
                print("ErrorMessage - %s" %  tunePrivateResponseJSON['status']['msg'])
                return False
        else:
            print("Error: not JSON object" )
            return False
            
class GetVersionJSONResponse:
    _accessCardId = None
    _receiverId = None
    _status_code = None
    _status_msg = None
    _stbSoftwareVersion = None
    
    def __init__(self, accessCardId, receiverId, statusCode, statusMsg, stbSoftwareVersion):
        self._accessCardId = accessCardId
        self._receiverId = receiverId
        self._status_code = statusCode
        self._status_msg = statusMsg
        self._stbSoftwareVersion = stbSoftwareVersion
        
    def verifyGetVersionResponse(self, getVersionJSON):
        if type (getVersionJSON) is dict:
            if self.__status_code is getVersionJSON['status']['code']:
                return True
            else:
                return False
        else:
            print("Error: not JSON object" )
            return False
    

class RecommendationsJSONResponse:
    '''
    This is for Recommendation JSON response definition
    Implement later
    '''
        
class RemoteKeyResponse:
    #Sample remote key response
        #{
        #   "hold": "keyPress",
        #    "key": "menu",
        #    "status": {
        #        "code": 200,
        #        "commandResult": 0,
        #        "msg": "OK.",
        #        "query": "/remote/processKey?key=menu"
        #    }
        #}
       
    _hold = None
    _key = None
    _status_code = None
    _status_msg = None
        
    def __init__(self, key, hold, statusCode, statusMsg):
        self._key = key
        self._hold = hold
        self._status_code = statusCode
        self._status_msg = statusMsg
        
    def verifySuccessRemoteKeyResponse(self, expectedResponseJSON):
        #print responseJSON['key']
        #print type(responseJSON)
        if type(expectedResponseJSON) is dict:
            if self._key is expectedResponseJSON['key'] and self._hold is expectedResponseJSON['hold'] and self._status_code is expectedResponseJSON['status']['code']:
                return True
            else:
                return False
        else:
            print("Error: not JSON object" )
            return False

class TVGetTunedResponse:
    #Sample get tuned response JSON
    #{
    #    "callsign": "CNNHD",
    #    "date": "20081003",
    #    "duration": 3600,
    #    "episodeTitle": "Shoot to Thrill",
    #    "isOffAir": false,
    #    "isPclocked": 3,
    #    "isPpv": false,
    #    "isRecording": false,
    #    "isVod": false,
    #    "major": 202,
    #    "minor": 65535,tunePrivateResponse
    #    "offset": 1370,
    #    "programId": "44018433",
    #    "rating": "No Rating",
    #    "startTime": 1505422800,
    #    "stationId": 3900947,
    #    "status": {
    #        "code": 200,
    #        "commandResult": 0,
    #        "msg": "OK.",
    #        "query": "/tv/getTuned"
    #    },
    #    "title": "Forensic Files"
    #}
    _channelName = None
    _channelIndex = None
    _duration = None
    _programTitle = None
    _episodeTitle = None
    _isRecording = None
    _rating = None
    
    def __init__(self, channelName = None, channelIndex = None, duration = None, programTitle = None, episodeTitle = None, isRecording = None, rating = None):
        self._channelName = channelName
        self._channelIndex = channelIndex
        self._duration = duration
        self._programTitle = programTitle
        self._episodeTitle = episodeTitle
        self._isRecording = isRecording
        self._rating = rating
        
    def verifyExpectedChannel(self, getTunedResponseJSON):
        if type(getTunedResponseJSON) is dict:
            if getTunedResponseJSON['status']['code'] is 200:
                if (getTunedResponseJSON['callsign'] == self._channelName and getTunedResponseJSON['major'] == self._channelIndex):
                    print ("Channel name and channel index are as expected")
                    return True
                else:
                    print ("Expected channel name: " + self._channelName + " - " + "Expected channel index: " + str(self._channelIndex)) 
                    print ("Actual channel name: " + str(getTunedResponseJSON['callsign']) + " - " + "Actual channel index: " + str(getTunedResponseJSON['major']))
                    print ("Error: Incorrect channel name or channel index")
                    return False
            else:
                print("Error: Unsuccessful response code return - " +  getTunedResponseJSON['status']['code'])
                return False
        else:
            print("Error: not JSON object" )
            return False

class  TVGetTunedPrivateResponse:
    '''
    @author: ThanhH
    def: getTunedPrivate
        http://STBIP:port/tv/getTunedPrivate?[clientAddr=string][&videoWindow=string][&honorPC=boolean]
    '''
    _channelName = None
    _channelIndex = None
    _duration = None
    _programTitle = None
    _episodeTitle = None
    _isRecording = None
    _rating = None
    
    def __init__(self, channelName = None, channelIndex = None, duration = None, programTitle = None, episodeTitle = None, isRecording = None, rating = None):
        self._channelName = channelName
        self._channelIndex = channelIndex
        self._duration = duration
        self._programTitle = programTitle
        self._episodeTitle = episodeTitle
        self._isRecording = isRecording
        self._rating = rating
        
    def verifyExpectedChannel(self, getTunedPrivateResponseJSON):
        if type(getTunedPrivateResponseJSON) is dict:
            if getTunedPrivateResponseJSON['status']['code'] is 200:
                if (getTunedPrivateResponseJSON['callsign'] == self._channelName and getTunedPrivateResponseJSON['major'] == self._channelIndex):
                    print ("Channel name and channel index are as expected")
                    return True
                else:
                    print ("Expected channel name: " + self._channelName + " - " + "Expected channel index: " + str(self._channelIndex)) 
                    print ("Actual channel name: " + str(getTunedPrivateResponseJSON['callsign']) + " - " + "Actual channel index: " + str(getTunedPrivateResponseJSON['major']))
                    print ("Error: Incorrect channel name or channel index")
                    return False
            else:
                print("Error: Unsuccessful response code return - " +  getTunedPrivateResponseJSON['status']['code'])
                return False
        else:
            print("Error: not JSON object" )
            return False
                      
class TVgetProgInfoResponse:
    '''
    @author: ThanhH
    def: Get Program Info
        http://STBIP:port/tv/getProgInfo?major=num[&minor=num][&time=num][&clientAddr=string]
    '''
    _channelName = None
    _channelIndex = None
    _duration = None
    _programTitle = None
    _episodeTitle = None
    _isRecording = None
    _rating = None
    
    def __init__(self, channelName = None, channelIndex = None, duration = None, programTitle = None, episodeTitle = None, isRecording = None, rating = None):
        self._channelName = channelName
        self._channelIndex = channelIndex
        self._duration = duration
        self._programTitle = programTitle
        self._episodeTitle = episodeTitle
        self._isRecording = isRecording
        self._rating = rating
        
    def verifyExpectedProgInfo(self, getProgInfoResponseJSON):
        if type(getProgInfoResponseJSON) is dict:
            if getProgInfoResponseJSON['status']['code'] is 200:
                if (getProgInfoResponseJSON['callsign'] == self._channelName and getProgInfoResponseJSON['major'] == self._channelIndex):
                    print ("Channel name and channel index are as expected")
                    return True
                else:
                    print ("Expected channel name: " + self._channelName + " - " + "Expected channel index: " + str(self._channelIndex)) 
                    print ("Actual channel name: " + str(getProgInfoResponseJSON['callsign']) + " - " + "Actual channel index: " + str(getProgInfoResponseJSON['major']))
                    print ("Error: Incorrect channel name or channel index")
                    return False
            else:
                print("Error Message - " +  getProgInfoResponseJSON['status']['msg'])
                return False
        else:
            print("Error: not JSON object" )
            return False
       
class TVgetProgInfoPrivateResponse:
    '''
    @author: ThanhH
    def: Get Program Info Private
        http://STBIP:port/tv/getProgInfoPrivate?major=num[&minor=num][&time=num][&honorPC=boolean][&clientAddr=string]
    ''' 
    _channelName = None
    _channelIndex = None
    _duration = None
    _programTitle = None
    _episodeTitle = None
    _isRecording = None
    _rating = None
    
    def __init__(self, channelName = None, channelIndex = None, duration = None, programTitle = None, episodeTitle = None, isRecording = None, rating = None):
        self._channelName = channelName
        self._channelIndex = channelIndex
        self._duration = duration
        self._programTitle = programTitle
        self._episodeTitle = episodeTitle
        self._isRecording = isRecording
        self._rating = rating
        
    def verifyExpectedProgInfoPrivate (self, getProgInfoPrivareResponseJSON):
        
        if type(getProgInfoPrivareResponseJSON) is dict:
            if getProgInfoPrivareResponseJSON['status']['code'] is 200:
                if getProgInfoPrivareResponseJSON['callsign'] == self._channelName and getProgInfoPrivareResponseJSON['major'] == self._channelIndex:
                    print ("Program info is got from expected channel")
                    return True
                else:
                    print ("Expected channel name: ") + self._channelName + "-" + "Expected channel index: " + str(self._channelIndex)
                    print ("Actual channel name: " + str(getProgInfoPrivareResponseJSON['callsign']) + " - " + "Actual channel index: " + str(getProgInfoPrivareResponseJSON['major']))
                    print ("Error: Incorrect channel name or channel index")
                    return False
            else:
                print("\nError message - " + getProgInfoPrivareResponseJSON['status']['msg'])
                return False
        else:
            print("Error: not JSON object" )
            return False			