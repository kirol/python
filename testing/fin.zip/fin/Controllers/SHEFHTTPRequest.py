'''
Created on Apr 14, 2017

@author: thanhtran
'''
import requests
from requests.auth import HTTPDigestAuth
from Configurations import STBConfiguration

import json

class SHEFGraphicsModeRequest:
    '''
    #author: ThanhHo
    http://STBIP:port/voice/graphics?action=string[&state=num][&commandId=num][&clientAddr=string]
    Date: 10-Nov
    '''
    _SHEFGraphicsModeURL = STBConfiguration.SHEFGraphicsModeURL
    _action = None
    _state = None
    _commandId = None
    _clientAddr = None
    
    def __init__(self, action = None, state = None, commandId = None, clientAddr = None):
        if action != None:
            self._action = action
        if state != None:
            self._state = state
        if commandId != None:
            self._commandId = commandId
        if clientAddr != None:
            self._clientAddr = clientAddr
    
    def send(self):
        payload = {}
        if self._action != None:
            payload['action'] = self._action
        if self._state != None:
            payload['state']=self._state
        if self._commandId != None:
            payload['commandId'] = self._commandId
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr
        r = requests.get(self._SHEFGraphicsModeURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params = payload)
        if r.status_code == 200:
            return r.json()
        else:
            print "Error sending request with status code: %d" % r.status_code
        return r.json()

class SHEFPlaybackViaMRVRequest:
    '''    
    Created on Nov 09 2017
    @author: Nhanqt
    def: Playback via MRV
    http://STBIP:port/dvr/play?uniqueId=num&udn=string[&playFrom=string][&offset=num][&clientAddr=string][&fromApp=boolean][&autoDel=boolean]
    '''
    _SHEFPlaybackViaMRVURL = None       
    _MRVuniqueId = None
    _playFrom = None
    _offset = None
    _clientAddr = None
    _fromApp = None
    _autoDel = None
    _MRVReceiverID = None
       
    def __init__(self, MRVuniqueId=None, clientAddr=None, playFrom=None, offset=None, fromApp=None, autoDel=None, MRVReceiverID=None):
        if MRVuniqueId != None:
            self._MRVuniqueId = MRVuniqueId
        if clientAddr != None:
            self._clientAddr = clientAddr
        if playFrom != None:
            self._playFrom = playFrom
        if offset != None:
            self._offset = offset
        if fromApp != None:
            self._fromApp = fromApp
        if autoDel != None:
            self._autoDel = autoDel
        if MRVReceiverID != None:
            self._MRVReceiverID = MRVReceiverID
    def send(self):
        payload = {}
        if self._MRVuniqueId != None:
            payload['uniqueId'] = self._MRVuniqueId
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr
        if self._playFrom != None:
            payload['playFrom'] = self._playFrom
        if self._offset != None:
            payload['offset'] = self._offset
        if self._fromApp != None:
            payload['fromApp'] = self._fromApp
        if self._autoDel != None:
            payload['autoDel'] = self._autoDel
        
        if self._MRVReceiverID != None:
            self._SHEFPlaybackViaMRVURL = STBConfiguration.SHEFPlaybackViaMRVURL + self._MRVReceiverID
            print "asdsad %s" % self._SHEFPlaybackViaMRVURL       
    
        try:
            r = requests.get(self._SHEFPlaybackViaMRVURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)  
            print "payload is %s " % payload          
            if (r.status_code == 200):
                print r.json()
                return True
            else:
                print "Error sending request with status code: " + str(r.status_code)            
                print r.json()
                return False
        except Exception as testError:
            print testError

class SHEFNotificationforVoiceRequest:
    '''
    Created on Nov 09, 2017
    @author: Nhanqt    
    def: Notification for Voice
    http://STBIP:port/notification/voice?[clientAddr=string]
    ''' 
    _SHEFNotificationforVoiceURL = STBConfiguration.SHEFNotificationforVoiceURL   
    _clientAddr = None 
    def __init__(self, clientAddr=None):            
        if clientAddr != None:
            self._clientAddr = clientAddr
    def send(self):
        payload = {}
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr                  
        r = requests.get(self._SHEFNotificationforVoiceURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)            
        if (r.status_code == 200):
            return r.json()
        else:
            print "Error sending request with status code: " + str(r.status_code)            
        return r.json()

class SHEFgetHDDStatusRequest:
    '''
    #author: ThanhHo
    http://STBIP:port/info/getHDDStatus
    Date: 9-Nov
    '''
    _SHEFgetHDDStatusURL = STBConfiguration.SHEFgetHDDStatusURL
    
    def send(self):
        payload = {}
        r = requests.get(self._SHEFgetHDDStatusURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)            
        if (r.status_code == 200):
            return r.json()
        else:
            print "Error sending request with status code: %d" % r.status_code            
        return r.json()
    
class SHEFgetMyTeamRequest:
    '''
    #author: ThanhHo
    http://STBIP:port/info/getMyTeam
    Date: 9-Nov
    '''
    _SHEFgetMyTeamURL = STBConfiguration.SHEFgetMyTeamURL
    
    def send(self):
        payload = {}
        r = requests.get(self._SHEFgetMyTeamURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)            
        if (r.status_code == 200):
            return r.json()
        else:
            print "Error sending request with status code: %d" % r.status_code            
        return r.json()    
    
class SHEFSerialCommandRequest:
    '''
    #author: ThanhHo
    http://STBIP:port/serial/processCommand?cmd=string
    Date: 9-Nov
    '''
    _SHEFSerialCommandURL = STBConfiguration.SHEFSerialCommandURL
    _cmd = None
    
    def __init__(self, cmd = None):
        if type != None:
            self._cmd = type
    
    def send(self):
        payload = {}
        if self._type != None:
            payload['cmd'] = self._cmd
        r = requests.get(self._SHEFSerialCommandURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)            
        if (r.status_code == 200):
            return r.json()
        else:
            print "Error sending request with status code: %d" % r.status_code            
        return r.json()

class SHEFGetPlaylistPrivateRequest:
    '''
    Created on Nov 08, 2017
    @author: Nhanqt    
    def: Display getPlaylist Private
    http://STBIP:port/dvr/getPlayListPrivate?type=all[&start=num][&max=num][&honorPC=boolean][&clientAddr=string]
    '''   
    _SHEFGetPlaylistPrivateURL = STBConfiguration.SHEFGetPlaylistPrivateURL   
    _type = None
    _clientAddr = None  
    def __init__(self, type=None, clientAddr=None):            
        if type != None:
            self._type = type
        if clientAddr != None:
            self._clientAddr = clientAddr   
    def send(self):
        payload = {}
        if self._type != None:
            payload['type'] = self._type            
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr                
        r = requests.get(self._SHEFGetPlaylistPrivateURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)            
        if (r.status_code == 200):
            print r.json()
            return True
        else:
            print "Error sending request with status code: " + str(r.status_code)            
            return False
    
class SHEFDRMRequest:
    '''
    Created on Nov 08, 2017
    @author: Nhanqt    
    def: Verify DRM status
    DRM-Info: http://STBIP:port/drm?action=info
    DRM-Connect: http://STBIP:port/drm?action=connect
    ''' 
    _SHEFDRMURL = STBConfiguration.SHEFDRMURL   
    _action = None 
    def __init__(self, action=None):            
        if action != None:
            self._action = action
    def send(self):
        payload = {}
        if self._action != None:
            payload['action'] = self._action                  
        r = requests.get(self._SHEFDRMURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)            
        if (r.status_code == 200):
            print r.json()
            return True
        else:
            print "Error sending request with status code: " + str(r.status_code)            
            print r.json()
            return False

class SeriesManagerRequest():
    '''
    @author: hoahtk
    Get: http://STBIP:port/dvr/seriesManager?action=get
    Modify: http://STBIP:port/dvr/seriesManager?action=modify[&id=number][&episodeType=number][&keepAtMost=number][&keepUntil=number][&start=number][&stop=number]
    Delete: http://STBIP:port/dvr/seriesManager?action=delete&id=number        
    '''        
    _SeriesManagertRequestSHEFURL = None
    _action = None #action: get or modify or delete
    _episodeType = None
    _keepAtMost = None
    _keepUntil = None
    _start = None
    _stop = None
    _id = None
    
    def __init__(self, action, id = None, episodeType = None, keepAtMost = None, keepUntil = None, start = None, stop = None):
        self._ToDoListRequestSHEFURL = "http://" + STBConfiguration.STBIPAddress + ":" + STBConfiguration.STBSHEFCMDPort + "/dvr/seriesManager"
        
        self._action = action
        
        if id != None:
            self._id = id           
           
        if episodeType != None:
            self._episodeType = episodeType
            
        if keepAtMost != None:
            self._keepAtMost = keepAtMost
        
        if keepUntil != None:
            self._keepUntil = keepUntil
            
        if start != None:
            self._start = start
            
        if stop != None:            
            self._stop = stop    
        
    def send (self):
        payload = {}
        if self._action != None:
            payload['action'] = self._action
        
        if self._id != None:
            payload['id'] = self._id
        
        if self._episodeType != None:
            payload['episodeType']= self._episodeType
        
        if self._keepAtMost != None:
            payload['keepAtMost'] = self._keepAtMost
        
        if self._keepUntil != None:
            payload['keepUntil'] = self._keepUntil      
            
        if self._start != None:
            payload['start'] = self._start
        
        if self._stop != None:
            payload['stop'] = self._stop     
            
        r = requests.get(self._ToDoListRequestSHEFURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params = payload)
        if (r.status_code == 200):
            return r.text
        else:
            print "Error sending request with status code: %d" % r.status_code
            return None

class GetSettings:
    '''
    @author: hoahtk
    http://STBIP:port/info/getSettings        
    '''
    _getSettingSHEFURL = None
    
    def __init__(self):
        self._getSettingSHEFURL = "http://" + STBConfiguration.STBIPAddress + ":" + STBConfiguration.STBSHEFCMDPort + "/info/getSettings"
    
    def send(self):       
        r = requests.get(self._getSettingSHEFURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword))    
        if (r.status_code == 200):
            return r.json()
            #print (r.text)
        else:
            print "Error sending request with status code: %d" %r.status_code
            return None       

class GetVersion:    
    '''
    @author: hoahtk
    http://STBIP:port/info/getVersion        
    '''
    
    _getVersionSHEFURL = None    
    def __init__(self):
        self._getVersionSHEFURL = "http://" + STBConfiguration.STBIPAddress + ":" + STBConfiguration.STBSHEFCMDPort + "/info/getVersion"
    
    def send(self):
       
        r = requests.get(self._getVersionSHEFURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword))    
        if (r.status_code == 200):
            return r.json()
            #print (r.text)
        else:
            print "Error sending request with status code: %d" %r.status_code
            return None   

class GetOptions:    
    '''
    @author: tienttt
    http://STBIP:port/info/getOptions        
    '''
    
    _getVersionSHEFURL = None    
    def __init__(self):
        self._getVersionSHEFURL = "http://" + STBConfiguration.STBIPAddress + ":" + STBConfiguration.STBSHEFCMDPort + "/info/getOptions"
    
    def send(self):
       
        r = requests.get(self._getVersionSHEFURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword))    
        if (r.status_code == 200):
            return r.json()
            #print (r.text)
        else:
            print "Error sending request with status code: %d" %r.status_code
            return None   

class ModeInfo:    
    '''
    @author: tienttt
    http://STBIP:port/info/ModeInfo       
    '''
    
    _getVersionSHEFURL = None    
    def __init__(self):
        self._getVersionSHEFURL = "http://" + STBConfiguration.STBIPAddress + ":" + STBConfiguration.STBSHEFCMDPort + "/info/mode"
    
    def send(self):
       
        r = requests.get(self._getVersionSHEFURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword))    
        if (r.status_code == 200):
            return r.json()
            #print (r.text)
        else:
            print "Error sending request with status code: %d" %r.status_code
            return None   

class ToDoListRequest:
    '''
    @author: hoahtk
    Get: http://STBIP:port/dvr/todoList?action=get
    Modify: http://STBIP:port/dvr/todoList?action=modify[&id=number][&keepUntil=number][&start=number][&stop=number]
    Delete: http://STBIP:port/dvr/todoList?action=delete&id=number        
    '''    
    
    _ToDoListRequestSHEFURL = None
    _action = None #action: get or modify or delete
    _id = None
    _keepUntil = None
    _start = None
    _stop = None
    
    def __init__(self, action, id = None, keepUntil = None, start = None, stop = None):
        self._ToDoListRequestSHEFURL = "http://" + STBConfiguration.STBIPAddress + ":" + STBConfiguration.STBSHEFCMDPort + "/dvr/todoList"
        
        self._action = action
            
        if id != None:
            self._id = id
        
        if keepUntil != None:
            self._keepUntil = keepUntil
            
        if start != None:
            self._start = start
            
        if stop != None:            
            self._stop = stop
            
    def send (self):
        payload = {}
        if self._action != None:
            payload['action'] = self._action
        
        if self._id != None:
            payload['id'] = self._id
        
        if self._keepUntil != None:
            payload['keepUntil'] = self._keepUntil
        
        if self._start != None:
            payload['start'] = self._start
        
        if self._stop != None:
            payload['stop'] = self._stop
              
        r = requests.get(self._ToDoListRequestSHEFURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params = payload)
        if (r.status_code == 200):
            return r.text
        else:
            print "Error sending request with status code: %d" % r.status_code
            return None

class SHEFgetSTBLocationsRequest:
    '''
    #author: ThanhHo
    http://STBIP:port/info/getLocations?[type=num]
    Date: 8-Nov
    '''
    _getSTBLocationsURL = STBConfiguration.SHEFgetSTBLocationsURL
    _type = None
    
    def __init__(self, type = None):
        if type != None:
            self._type = type
    
    def send(self):
        payload = {}
        if self._type != None:
            payload['type'] = self._type
        r = requests.get(self._getSTBLocationsURL, auth = HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params = payload)
        if r.status_code == 200:
            return r.json()
        else:
            print "Error sending request with status code: %d" % r.status_code
        return r.json()
            
class SHEFTuneRequest:
    '''
    #author: ThanhHo
    http://STBIP:port/tv/tune?major=num[&minor=num][&clientAddr=string][&source=num]
    Date: 8-Nov
    '''
    _tuneURL = STBConfiguration.SHEFTuneURL
    _major = None
    _minor = None
    _clientAddr = None
    _source = None
    
    def __init__(self, major = None, minor = None, clientAddr = None, source = None):
        if major != None:
            self._major = major
        if minor != None:
            self._minor = minor
        if clientAddr != None:
            self._clientAddr = clientAddr
        if source != None:
            self._source = source    
    def send(self):
        payload = {}
        if self._major != None:
            payload['major'] = self._major
        if self._minor != None:
            payload['minor'] = self._minor
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr
        if self._source != None:
            payload['source'] = self._source
        r = requests.get(self._tuneURL, auth = HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params = payload)
        if r.status_code == 200:
            return r.json()
        else:
            print "Error sending request with status code: %d" % r.status_code
        return r.json()
    
class SHEFtunePrivateRequest:
    '''
    #author: ThanhHo
    http://STBIP:port/tv/tunePrivate?major=num[&minor=num][&honorPC=boolean][&clientAddr=string][&source=num]
    Date: 8-Nov
    '''
    _tunePrivateURL = STBConfiguration.SHEFtunePrivateURL
    _major = None
    _minor = None
    _honorPC = False
    _clientAddr = None
    _source = None
    
    def __init__(self, major = None, minor = None, honorPC = False, clientAddr = None, source = None):
        if major != None:
            self._major = major
        if minor != None:
            self._minor = minor
        if honorPC:
            self._honorPC = honorPC
        if clientAddr != None:
            self._clientAddr = clientAddr
        if source != None:
            self._source = source
    
    def send(self):
        payload = {}
        if self._major != None:
            payload['major'] = self._major
        if self._minor != None:
            payload['minor'] = self._minor
        if self._honorPC:
            payload['honorPC'] = self._honorPC
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr
        if self._source != None:
            payload['source'] = self._source
        r = requests.get(self._tunePrivateURL, auth = HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params = payload)
        if r.status_code == 200:
            return r.json()
        else:
            print "Error sending request with status code: %d" % r.status_code
        return r.json()          

class SHEFPlaybackRequest():

        #author: nhantq            
  
        #Use to playback VOD/Recording        
        _SHEFPlaybackURL = STBConfiguration.SHEFPlaybackURL         
        _uniqueId = None
        _materialId = None
        _playFrom = None
        _offset = None
        _clientAddr = None
        #playFrom is start/resume/offset
        #offset is number of seconds from beginning of recording to start at
   
        def __init__(self, uniqueId=None, materialId=None, clientAddr=None, playFrom=None, offset=None):
            if uniqueId != None:
                self._uniqueId = uniqueId
            if materialId != None:
                self._materialId = materialId
            if playFrom != None:
                self._playFrom = playFrom
            if offset != None:
                self._offset = offset   
            if clientAddr != None:
                self._clientAddr = clientAddr 
   
        def send(self):
            payload = {}
            if self._uniqueId != None:
                payload['uniqueId'] = self._uniqueId
            if self._materialId != None:
                payload['materialId'] = self._materialId
            if self._playFrom != None:
                payload['playFrom'] = self._playFrom
            if self._offset != None:
                payload['offset'] = self._offset
            if self._clientAddr != None:
                payload['clientAddr'] = self._clientAddr         
            r = requests.get(self._SHEFPlaybackURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)
            print "SHEF request is " + self._SHEFPlaybackURL
            print "SHEF payload is %s " % payload
            if (r.status_code == 200):
                print r.json()
                return True
            else:
                print "Error sending request with status code: " + str(r.status_code)           
                print r.json()
                return False


    
    
#author: Nhanqt
class SHEFPlaylistRequest:
        '''
        @author: Nhan Tran
        '''
        _SHEFPlaylistURL = STBConfiguration.SHEFPlaylistURL        
        _action = None
        _type = None
        _uniqueId = None
        #action is get or delete
        #type is user or genie
        #uniqueId is number
        
        def __init__(self, action=None,type=None, uniqueId=None):
            if action != None:
                self._action = action
            if type != None:
                self._type = type
            if uniqueId != None:
                self._uniqueId = uniqueId        
        
        def send(self):
            payload = {}
            if self._action != None:
                payload['action'] = self._action
            if self._type != None:
                payload['type'] = self._type
            if self._uniqueId != None:
                payload['uniqueId'] = self._uniqueId                
            r = requests.get(self._SHEFPlaylistURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)            
            if (r.status_code == 200):
                print r.json()
                return r.json()
            else:
                print "Error sending request with status code: " + str(r.status_code)            
                print r.json()
                return False

class SHEFRecordPrivateRequest():
        '''
        @author: Nhan Tran
        Use for record private: One Touch / Series / Manual
        '''
        
        _SHEFRecordPrivateURL = STBConfiguration.SHEFRecordPrivateURL        
        _major = None
        _type = None
        _recurrence = None
        _clientAddr = None
        #major is channel number
        #type is oneTouch / series / manual        
        #recurrence is daily
        
        def __init__(self, type=None,major=None, recurrence=None, clientAddr=None):
            if type != None:
                self._type = type
            if major != None:
                self._major = major
            if recurrence != None:
                self._recurrence = recurrence
            if clientAddr != None:
                self._clientAddr = clientAddr                
        def send(self):
            payload = {}
            if self._type != None:
                payload['type'] = self._type
            if self._major != None:
                payload['major'] = self._major
            if self._recurrence != None:
                payload['recurrence'] = self._recurrence
            if self._clientAddr != None:
                payload['clientAddr'] = self._clientAddr          
            r = requests.get(self._SHEFRecordPrivateURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)
            print "SHEF request is " + self._SHEFRecordPrivateURL
            print "SHEF payload is %s " % payload
            if (r.status_code == 200):
                print r.json()
                return True
            else:
                print "Error sending request with status code: " + str(r.status_code)            
                print r.json()
                return False   
        

class RecommendationsRequest:
    recommendations_httpUser = None
    recommendations_httpUserPass = None
    recommendationsSHEFURL = None  
    clientAddr = None
    modType = None
    def __init__(self, _recomendationsSHEFURL, _clientAddr, _modType, _recommendations_httpUser, _recommendations_httpUserPass):
        self.recommendations_httpUser = _recommendations_httpUser
        self.recommendations_httpUserPass = _recommendations_httpUserPass
        self.recommendationsSHEFURL = _recomendationsSHEFURL
        self.clientAddr = _clientAddr
        self.modType = _modType
        
    def send(self):
        payload = {}
        if self.clientAddr != None:
            payload['clientAddr'] = self.clientAddr
        if self.modType != None:
            payload['modType'] = self.modType 
        r = requests.get(self.recommendationSHEFURL, auth=(self.recommendation_httpUser, self.recommendation_httpUserPass), params=payload)   
        if (r.status_code == 200):
            return r.json()
        else:
            print "Error sending request with status code: " + r.status_code
            return None
    
class RemoteKeyRequest:
    _remoteKeySHEFURL = STBConfiguration.SHEFKeyRemoteURL
    _key = None
    _hold = None
    _clientAddr = None
    
    def __init__(self, key, hold=None , clientAddr=None):
        self._key = key
        self._hold = hold
        self._clientAddr = clientAddr
        
    def send(self):
        payload = {'key' : self._key }
        if self._hold != None:
            payload['hold'] = self._hold
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr
            print "client addr %s" % self._clientAddr
        r = requests.get(self._remoteKeySHEFURL, params=payload)   
        if (r.status_code == 200):
            return r.json()
        else:
            print "Error sending request with status code: " + r.status_code
            return None
        
class TVGetTunedRequest:     
        _tvGetTunedURL = STBConfiguration.SHEFTVGetTunedURL
        _clientAddr = None
        _videoWindow = None
        
        def __init__(self, clientAddr=None, videoWindow=None):
            if clientAddr != None:
                self._clientAddr = clientAddr
            if videoWindow != None:
                self._videoWindow = videoWindow    
        
        def send(self):
            payload = {}
            if self._clientAddr != None:
                payload['clientAddr'] = self._clientAddr
            if self._videoWindow != None:
                payload['videoWindow'] = self._videoWindow
                
            r = requests.get(self._tvGetTunedURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)
            if (r.status_code == 200):
                return r.json()
            else:
                print "Error sending request with status code: " + str(r.status_code)
            return None
            
class TVGetTunedPrivateRequest:
    '''
    @author: ThanhHo
    def: getTuned Private
        http://STBIP:port/tv/getTunedPrivate?[clientAddr=string][&videoWindow=string][&honorPC=boolean]
    '''  
    _tvGetTunedPrivateURL = STBConfiguration.SHEFVGetTunedPrivateURL
    _clientAddr = None
    _videoWindow = None
    _honorPC = False
    
    def __init__(self, clientAddr = None, videoWindow = None, honorPC = False):
        if clientAddr != None:
            self._clientAddr = clientAddr
        if videoWindow != None:
            self._videoWindow = videoWindow 
        if honorPC:
            self._honorPC = honorPC
    
    def send(self):
        payload = {}
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr
        if self._videoWindow != None:
            payload['videoWindow'] = self._videoWindow
        if self._honorPC:
            payload['honorPC'] = self._honorPC    
        r = requests.get(self._tvGetTunedPrivateURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)
        if (r.status_code == 200):
            #print r.json()
            return r.json()
            
        else:
            print "Error sending request with status code: %d" % r.status_code
        return None
        
class TVgetProgInfoRequest:
    '''
    @author: ThanhHo
    def: Get Program Info
        http://STBIP:port/tv/getProgInfo?major=num[&minor=num][&time=num][&clientAddr=string]
    '''
    _getProgInfosURL = STBConfiguration.SHEFgetProgInfoURL
    _major = None
    _minor = None
    _time = None
    _clientAddr = None
            
    def __init__(self, major=None, minor=None, time=None, clientAddr=None):
        if major != None:
            self._major = major
        if minor != None:
            self._minor = minor
        if time != None:
            self._time = time
        if clientAddr != None:
            self._clientAddr = clientAddr
            
    def send(self):
        payload = {}
        if self._major != None:
            payload['major'] = self._major
        if self._minor != None:
            payload['minor'] = self._minor
        if self._time != None:
            payload['time'] = self._time
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr
        r = requests.get(self._getProgInfosURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)
        if r.status_code == 200:
            return r.json()
        else:
            print "Error sending request with status code: %d" % r.status_code
            #print r.raise_for_status()
        return None
            
 
class TVgetProgInfoPrivateRequest:
    '''
    @author: ThanhHo
    def: Get Program Info Private
        http://STBIP:port/tv/getProgInfoPrivate?major=num[&minor=num][&time=num][&honorPC=boolean][&clientAddr=string]
        honorPC: Flag to indicate whether to honor the parental controls settings (true: honor PC in STB/ False: ignore PC)
        
    '''      
    _getprogInfoPrivateURL = STBConfiguration.SHEFgetProgInfoPrivateURL
    _major = None
    _minor = None
    _time = None
    _honorPC = False
    _clientAddr = None
    
    def __init__(self, major = None, minor = None, time = None, honorPC = False, clientAddr = None):
        if major != None:
            self._major = major
        if minor != None:
            self._minor = minor
        if time != None:
            self._time = time
        if honorPC:
            self._honorPC = True
        if clientAddr != None:
            self._clientAddr = clientAddr
    
    def send(self):
        payload = {}
        if self._major != None:
            payload['major'] = self._major
        if self._minor != None:
            payload['minor'] = self._major
        if self._time != None:
            payload['time'] = self._time
        if self._honorPC:
            payload['honorPC'] = self._honorPC
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr
        r = requests.get(self._getprogInfoPrivateURL, auth = HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params = payload)
        if r.status_code == 200:
            return r.json()
        else:
            print "Error sending request with status code: %d" % r.status_code
        return r.json()
                      
class SHEFGetPlaylistRequest:
    '''
    Created on Nov 07, 2017
    @author: Nhanqt    
    def: Use for getPlaylist test cases
    '''   
    
    _SHEFGetPlaylistURL = STBConfiguration.SHEFGetPlaylistURL   
    _type = None
    _clientAddr = None
    
    
    def __init__(self, type=None, clientAddr=None):            
        if type != None:
            self._type = type
        if clientAddr != None:
            self._clientAddr = clientAddr        
    
    def send(self):
        payload = {}
        if self._type != None:
            payload['type'] = self._type            
        if self._clientAddr != None:
            payload['clientAddr'] = self._clientAddr                
        r = requests.get(self._SHEFGetPlaylistURL, auth=HTTPDigestAuth(STBConfiguration.shefUsername, STBConfiguration.shefPassword), params=payload)            
        if (r.status_code == 200):
            print r.json()
            return True
        else:
            print "Error sending request with status code: " + str(r.status_code)            
            print r.json()
            return False  
    
  