#!/usr/bin/python

import sys
import argparse
import subprocess

def main(sysArgs):
        global args
        parser = argparse.ArgumentParser()
        parser.add_argument("-a","--all",action="store_true",help="Run all tests")
        parser.add_argument("-t","--test",action="append",help="Run this test")
        args = parser.parse_args()

        if args.all:
                print "Running all tests"
                proc = subprocess.Popen(['python -m unittest discover TestCases/'] \
                ,shell=True)
                procOutput, procError = proc.communicate()
        else:
                print "Running selected tests"
                print(vars(args)["test"][0])
                input = vars(args)["test"][0]
                proc = subprocess.Popen(['python -m unittest TestCases.' + input] \
                ,shell=True)

main(sys.argv)