'''
Created on Jul 26, 2017

@author: tt4609
'''

from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
from urlparse import urlparse, parse_qs
import threading

server = None
HTTPPort = 8008
httpThread = None
Result = None

class MyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        print("Just received a GET request")
        self.send_response(200)
        #self.send_header("Content-type", "text/html")   
        #self.end_headers()
        #self.wfile.write("<html><head><title>Test Page</title></head>")
        #self.wfile.write("<body><p>This is a test.</p>")
        #### If someone went to "http://something.somewhere.net/foo/bar/",
        #### then s.path equals "/foo/bar/".
        #self.wfile.write("<p>You accessed path: %s</p>" % self.path)
        #self.wfile.write("</body></html>")
        #self.wfile.close()
        print("Path: " + self.path)
        res = parse_qs(urlparse(self.path).query) 
        global Result
        Result = res
        print(Result)
        return Result

    #def log_request(self, code=None, size=None):
    #    print('Request')

    #def log_message(self, format, *args):
    #    print('Message')

def startHttpDeamon():
    global server
    server = HTTPServer(('', HTTPPort), MyHandler)
    print('Started http server')
    global httpThread
    httpThread = threading.Thread(target=server.serve_forever)
    httpThread.daemon = True
    httpThread.start()
    
def stopHttpDeamon():
    print('Stopped http server')
    global server
    server.shutdown()
    server.server_close()#Author : MinhLy
    global httpThread
    #httpThread.daemon = False
    #print("Thread is still alive: " + str(httpThread.isAlive()))
    
    
    