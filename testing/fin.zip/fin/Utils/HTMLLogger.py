'''
Created on Nov 27, 2017

@author: Tien Tran
'''

"""
HTML logger inspired by the Horde3D logger.
Usage:
 - call setup and specify the filename, title, version and level
 - call dbg, info, warn or err to log messages.
"""

import logging
import time

#: HTML header (starts the document
_START_OF_DOC_FMT = """<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>%(title)s</title>
<style type="text/css">
.err {
color: orange;
font-weight: bold
}
.warn {
color: darkorange;
font-weight: bold
}
.info {
color: blue;
}
.debug {
color: green;
}
.critical {
color: red;
}
</style>
</head>
<body>
<h3>%(title)s ----- %(asctime)s</h3>
<div class="box">
<table>
"""

_END_OF_DOC_FMT = """</table>
</div>
</body>
</html>
"""

_MSG_FMT = """
<tr>
<!--td width="100">%(time)s</td-->
<td class="%(class)s"><pre>|%(time)s|%(asctime)s|%(levelname)s|%(msg)s</pre></td>
<tr>
"""

class HTMLFileHandler(logging.FileHandler):
    def __init__(self, filename, mode='a', encoding=None):
        logging.FileHandler.__init__(self, filename, mode=mode, encoding=encoding)
        self.stream.write(_START_OF_DOC_FMT % {"title" : "logfile","asctime": time.asctime()})
        
    def close(self):
        self.stream.write(_END_OF_DOC_FMT)
        logging.FileHandler.close(self)
        

class HTMLFormatter(logging.Formatter):
    """
    Formats each record in html
    """
    CSS_CLASSES = {'WARNING': 'warn','INFO': 'info','DEBUG': 'debug','CRITICAL': 'err','ERROR': 'err'}

    def __init__(self):
        logging.Formatter.__init__(self, fmt = '%(asctime)s| %(levelname)s| %(message)s')
        #super().__init__()
        self._start_time = time.time()

    def format(self, record):
        try:
            class_name = self.CSS_CLASSES[record.levelname]
        except KeyError:
            class_name = "info"

        t = time.time() - self._start_time
        
        # handle '<' and '>' (typically when logging %r)
        msg = record.msg
        msg = msg.replace("<", "&#60")
        msg = msg.replace(">", "&#62")
        return _MSG_FMT % {"class": class_name, "time": "%.4f" % t,"asctime":time.asctime(),"levelname":class_name,"msg": msg}
        #return _MSG_FMT % {"class": class_name, "time": "%.4f" % t,
        #               "msg": msg}



class HTMLLogger(logging.Logger):
    """
    Log records to html using a custom HTML formatter and a specialised
    file stream handler.
    """
    DEBUG = "DEBUG"
    def __init__(self, textlog = "TestLogs/logfile.log",htmllog = "TestLogs/logfile.html", mode='w'):
        global logger
        logger = logging.getLogger()
        logger.setLevel(logging.DEBUG)        
        if not len(logger.handlers):
            if textlog:
                log_handler = logging.FileHandler(filename = textlog)
                log_handler.setFormatter(logging.Formatter(fmt='%(asctime)s| %(levelname)s| %(message)s'))            
                logger.addHandler(log_handler)
                
            if htmllog:
                f = HTMLFormatter()
                h = HTMLFileHandler(htmllog)
                h.setFormatter(f)            
                logger.addHandler(h)    
        
       
    def dbg(self,msg):
        """
        Logs a debug message
        """
        
        logger.debug(msg)
    
    
    def info(self,msg):
        """
        Logs an info message
        """
        logger.info(msg)
    
    
    def warn(self,msg):
        """
        Logs a warning message
        """
        logger.warning(msg)
    
    
    def err(self,msg):
        """
        Logs an error message
        """
        logger.error(msg)
    
    def critical(self,msg):
        logger.critical(self, msg)
        
def log(level, msg, writeToFile = True):

    #global logger #author : Tienttt
    newlog = HTMLLogger()
    if(writeToFile == False):
        print(msg)
    else :
        if level == "WARNING":
            newlog.warn(msg)
        elif level == "DEBUG":
            newlog.dbg(msg)
        elif level == "CRITICAL":
            newlog.critical(msg)
        elif level == "ERROR":
            newlog.err(msg)
        else :
            newlog.info(msg)
