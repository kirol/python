'''
Created on Apr 11, 2017

@author: thanhtran
'''

import openpyxl
from openpyxl.styles import Font
 
class SpreadSheetHelper:
    reportFile = "testreport.xlsx"
 
    @staticmethod
    def getTestDataSheet(fileName, sheetName):
        rows= []
        if fileName.split('.')[1]=='xlsx':
            wb = openpyxl.load_workbook('../../TestData/' + fileName)
            sheet= wb.get_sheet_by_name(sheetName)
            for r in sheet.rows:
                row1 = []
                for cellObj in r:
                    row1.append(cellObj.value)
                rows.append(row1)     
        return rows   
    
    @staticmethod
    def createEmptyTestReport():         
        wb = openpyxl.Workbook()
        sheet = wb.get_sheet_by_name("Sheet")
        sheet.title = "TestReport"
        sheet['A1'] = "TEST REPORT"
        titleFontStyle = Font(size=22, bold=True, italic=False, color='FF000000') 
        sheet['A1'].font = titleFontStyle 
        sheet.merge_cells('A1:D1')
        sheet['A3'] = "No"
        sheet['B3'] = "Test Case"
        sheet['C3'] = "Result"
        sheet['D3'] = "Note/Comment"
        sheet.column_dimensions['A'].width = 5
        sheet.column_dimensions['B'].width = 40
        sheet.column_dimensions['C'].width =12
        sheet.column_dimensions['D'].width = 60
        #reportFile = "testreport.xlsx"
        global reportFile
        wb.save("testreport.xlsx")
        
    @staticmethod
    def writeTestResult(isPassed, testcaseID):
        print("Results: " + str(isPassed))
        #print("TEST: " + BaseTest.testCaseID)
        global reportFile
        wb = openpyxl.load_workbook(filename = "testreport.xlsx")
        sheet = wb.get_sheet_by_name("TestReport")
        lastrow = sheet.max_row
        nextrow = lastrow + 1
        sheet['B' + str(nextrow)] = testcaseID;
        sheet["C" + str(nextrow)] = "Passed" if isPassed else "Failed"
        wb.save("testreport.xlsx")
        
        
        