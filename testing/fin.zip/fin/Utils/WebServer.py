'''
Created on Nov 10, 2017

@author: tt4609 - Thanh Tran
'''
from SimpleHTTPServer import SimpleHTTPRequestHandler
from BaseHTTPServer import HTTPServer as BaseHTTPServer
import threading
import os
from Configurations import TFWConfiguration
import time


webServer = None
HTTPPort = 8009
#web_dir = os.path.dirname(os.getcwd()) + TFWConfiguration.TFW_WEBSERVER
web_dir = os.getcwd() + TFWConfiguration.TFW_WEBSERVER
webServerThread = None
Result = None

class HTTPHandler(SimpleHTTPRequestHandler):
    """This handler uses server.base_path instead of always using os.getcwd()"""
    def translate_path(self, path):
        path = SimpleHTTPRequestHandler.translate_path(self, path)
        relpath = os.path.relpath(path, os.getcwd())
        fullpath = os.path.join(self.server.base_path, relpath)
        return fullpath

class HTTPServer(BaseHTTPServer):
    """The main server, you pass in base_path which is the path you want to serve requests from"""
    def __init__(self, base_path, server_address, RequestHandlerClass=HTTPHandler):
        self.base_path = base_path
        BaseHTTPServer.__init__(self, server_address, RequestHandlerClass)

def startWebServer():
    global web_dir
    global webServer
    global HTTPPort
    
    webServer = HTTPServer(web_dir, ("", HTTPPort))
    print('Started web server')
    global webServerThread
    webServerThread = threading.Thread(target=webServer.serve_forever)
    webServerThread.daemon = True
    webServerThread.start()
    print(web_dir)
    
def stopWebServer():
    print('Stopped web server')
    global webServer
    webServer.shutdown()
    webServer.server_close()#Author : MinhLy
    time.sleep(10)
    #global webServerThread
    #webServerThread.daemon = False
    #print("Thread is still alive: " + str(webServerThread.isAlive()))