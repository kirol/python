tclsh performance.tcl 1 192.168.1.80 tt4609 Ch1chB0ng21o5 ttyS4 192.168.1.122 hr54 hum root how42n8 "how42n8 happytocode" 3 "RemoteMp4MediaStream"
