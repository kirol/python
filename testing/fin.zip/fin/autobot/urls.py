#autobot/urls.py
from django.conf.urls import url
from autobot import views

urlpatterns = [
    url(r'^$', views.HomePageView.as_view()),
    url(r'^testcase1/$', views.TestCase1View.as_view()),
    url(r'^testcase2/$', views.TestCase2View.as_view()),
    url(r'^runtestcase/$', views.RunTestCaseView.as_view()),
]
