myDiagram.model = go.Model.fromJson(response);
