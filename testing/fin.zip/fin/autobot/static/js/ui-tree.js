var UITree = function(data) {
	
	function createNewProject(node) {
		$('#newProjectModal').modal('show'); 
	}
	
	function deleteProject(node) {
		var tree = $('#workspaceTree').jstree(true);
		tree.delete_node([node]);
		console.log(node.li_attr);
		var projectID = node.li_attr["project_id"];
		$.ajax({
            url: '/process_delete_project',
            type: 'post',
            data: {
                projectID: projectID
            },
            success: function(response) {
            	console.log('Project '+node.li_attr['project_name']+' has deleted!');
                /*reloadExistingProjectInWizardModal();   // HITA-183*/
                location.reload(); // HITA-206
            }
        });
	}
	
	function deleteImpactReport(node) {
		var tree = $('#workspaceTree').jstree(true);
		var parent_node = tree.get_parent(node);
		tree.delete_node([node]);
		
		if ( tree.is_leaf(parent_node) ) {
			//Check and delete the parent if it becomes leaf node
			tree.delete_node([parent_node]);
		}
		console.log(node.li_attr);
		var projectID = node.li_attr["project_id"];
		var impactID = node.li_attr["impact_id"];
		$.ajax({
            url: '/process_delete_impact_report',
            type: 'post',
            data: {
                projectID: projectID,
                impactID: impactID
            },
            success: function(response) {
            	//alert(response);
				//var data = response;
				//showImpactTable(data);							
            }
        });
	}
	
	function deleteAllReport(node) {
		var tree = $('#workspaceTree').jstree(true);
		tree.delete_node([node]);
		var projectID = node.li_attr["project_id"];
		$.ajax({
            url: '/process_delete_all_impact_report',
            type: 'post',
            data: {
                projectID: projectID,
            },
            success: function(response) {
            	//alert(response);
				//var data = response;
				//showImpactTable(data);							
            }
        });
	}
	
	function refreshWorkspace() {
		var ajax = getWorkspace();
        ajax.success(function(response) {
            var data = JSON.parse(response);
            UITree.refresh(data);
        });
	}
	
	function generateImpactByRevisions(node){
		$('#projectRevisionCompare').text("Project: "+node.li_attr.project_name);
		$('#projectRevisionCompare').val(node.li_attr.project_id);
		$('#viewRevisionCompare').text(node.text);
		$('#viewRevisionCompare').val(node.li_attr.source_name);
		$("#baseRevision").html("");
		$("#compareRevision").html("");
		for (var i=1; i <= node.li_attr.version_id; i++) {
			$("#baseRevision").append($('<option>', {
	            value: i,
	            text: i
	        }));
			$("#compareRevision").append($('<option>', {
	            value: i,
	            text: i
	        }));
		}
		
		$("#chooseRevisionsModal").modal("show");
		$(".warningAlert").hide();
	}
	
	function customMenu(node) {
		var node_level = node.li_attr["class"];
		var items = {};
		var root_items = {
	        'item1' : {
	            'label' : 'New project',
	            'action' : function () { createNewProject(node);/* action */ }
	        },
	        'item2' : {
	            'label' : 'Refresh',
	            'action' : function () { 
	            	refreshWorkspace();
	            }
	        }
	    };
		
	    var project_items = {
	        'item2' : {
	            'label' : 'Delete Project',
	            'action' : function () { deleteProject(node);}
	        }
	    };
	    
	    var source_view_items = {
    		'item1' : {
	            'label' : 'Generate Impact By Revisions',
	            'action' : function () { generateImpactByRevisions(node);}
	        }  
    	};
	    
	    var impact_history_items = {
    	        'item2' : {
    	            'label' : 'Delete All',
    	            'action' : function () { deleteAllReport(node);}
    	        }
    	    };
	    
	    var impact_time_items = {
    	        'item2' : {
    	            'label' : 'Delete report',
    	            'action' : function () { deleteImpactReport(node);}
    	        }
    	    };
	    
	    switch (node_level) {
    	    case "TreeRoot":
	    		items = root_items;
	    		break;
	    	case "TreeProject":
	    		items = project_items;
	    		break;
	    	case "TreeVersion":
	    		break;
	    	case "TreeSourceView":
	    		items = source_view_items;
	    		break;
	    	case "TreeImpact":
	    		items = impact_history_items;
	    		break;
	    	case "TreeImpactTime":
	    		items = impact_time_items;
	    		break;
	    	default:
	    		break;
	    }
	    
	    if (node.type === 'level_1') {
	        delete items.item2;
	    } else if (node.type === 'level_2') {
	        delete items.item1;
	    }

	    return items;
	}
	
	function appendSourceView(project, node_children, latestVersionID) {
		switch( project['type'] ) {
	        case "sourceCode":
	        	var classObj = {};
	        	classObj.li_attr={"title": "Class View", "project_id": project['projectID'], "project_name": project['projectName'],'version_id': latestVersionID,"class": "TreeSourceView", "source_name":"class"};
	        	classObj.text = "Class View"; 
	        	classObj.icon = "fa fa-file icon-state-warning";
	        	
	        	var packageObj = {};
	        	packageObj.li_attr={"title": "Package View", "project_id": project['projectID'], "project_name": project['projectName'],'version_id': latestVersionID,"class": "TreeSourceView", "source_name":"package"};
	        	packageObj.text = "Package View"; 
	        	packageObj.icon = "fa fa-file icon-state-warning";
	        	
	        	var componentObj = {};
	        	componentObj.li_attr={"title": "Component View", "project_id": project['projectID'], "project_name": project['projectName'],'version_id': latestVersionID,"class": "TreeSourceView", "source_name":"component"};
	        	componentObj.text = "Component View"; 
	        	componentObj.icon = "fa fa-file icon-state-warning";
	        	
	        	node_children.push(classObj);
	        	node_children.push(packageObj);
	        	node_children.push(componentObj);
	            break;
	        case "systemIntegration":
	        	var componentObj = {};
	        	componentObj.li_attr={"title": "Component View", "project_id": project['projectID'], "project_name": project['projectName'],'version_id': latestVersionID, "class": "TreeSourceView", "source_name":"component"};
	        	componentObj.text = "Component View"; 
	        	componentObj.icon = "fa fa-file icon-state-warning";
	        	
	        	node_children.push(componentObj);
	            break;
	        case "database":
	            var dbObj = {};
	            dbObj.li_attr={"title": "Database View", "project_id": project['projectID'], "project_name": project['projectName'],'version_id': latestVersionID, "class": "TreeSourceView", "source_name":"database"};
	            dbObj.text = "Database View"; 
	            dbObj.icon = "fa fa-file icon-state-warning";
	            
	            node_children.push(dbObj);
	            break;
	        default:
	            break;
	    }
	}
	
	function appendImpact(project, impactChildren, impacti) {
		var impactByTime ={};
		impactByTime.text = "Impact_"+impacti['reportTime'];
		impactByTime.li_attr = {"title": "Impact_"+impacti['reportTime'], "project_id": project['projectID'], "impact_id": impacti['impactID'], "class": "TreeImpactTime"};
		impactByTime.children = [];
		
		// Append 2 children for every impact times
		var tableImpact = {};
		tableImpact.text = "Table";
		tableImpact.li_attr = {"title": "", "project_type_zzz":impacti['view'], "project_id": project['projectID'], "impact_id": impacti['impactID'], "class": "TreeImpactTable"};
		tableImpact.icon = ""; 
		
		var diagramImpact = {};
		diagramImpact.text = "Diagram";
		diagramImpact.li_attr = {"title": "", "project_id": project['projectID'], "impact_id": impacti['impactID'], "class": "TreeImpactDiagram"};
		diagramImpact.icon = "";
		
		var flowsImpact = {};
		flowsImpact.text = "Test Flows";
		flowsImpact.li_attr = {"title": "Test Flows", "project_id": project['projectID'], "impact_id": impacti['impactID'], "class": "TreeImpactFlows"};
		flowsImpact.icon = "";
		impactByTime.children.push(tableImpact);
		impactByTime.children.push(diagramImpact);
		impactByTime.children.push(flowsImpact);
		// Append 2 children
		
		impactChildren.push(impactByTime);
	}
	
	function appendImpactHistories(project, histories, impacts) {
		//
    	if ( impacts != undefined && impacts != null ) {
    		if ( impacts.length >0   ) {
        		var impactOnProject = {};
        		impactOnProject.text = "Impact Histories("+impacts.length.toString()+")";
        		impactOnProject.li_attr = {"title": "Impact Histories("+impacts.length.toString()+")", "project_id": project['projectID'], "class": "TreeImpact"};
        		impactOnProject.icon = "fa fa-check icon-state-success";//"fa fa-warning icon-state-danger";
        		impactOnProject.state = { "opened": true };
        		impactOnProject.children = [] ;
        		for (i in impacts) {
        			var impacti = impacts[i];
        			appendImpact(project, impactOnProject.children, impacti);
        		}
        		
        		//Append impact histories
        		histories.push(impactOnProject);
        	} 
    	} 
	}
	
	function appendProject(root_children, project) {
		if ( project['projectID']!= undefined ) {
    		var node = {};
        	node.text = project['projectName'];
        	node.id="Project_"+project['projectID'].toString();
        	node.children = [];
        	//var latestVersionID = Math.max.apply(Math,sourceViews.map(function(o){return o.versionID;}));
        	var latestVersion = project["sources"].pop();

        	if ( latestVersion!=null && latestVersion!=undefined ) {
        		latestVersionID = latestVersion.versionID;
        		node.text+= " (v"+latestVersionID+")";
        		node.li_attr={"title": project['projectName'] + " (v" + latestVersionID + ")", "class": "TreeProject", "project_name": project['projectName'], "project_id": project['projectID'], "project_type": project['type']};
            	appendSourceView(project, node.children, latestVersionID);
        	}
        	
        	var impacts = project["impactHistories"];
        	appendImpactHistories(project,node.children, impacts);
        	root_children.push(node);
    	}
	}
	
	function appendRoot(projects) {
    	var root ={};
    	root.text = "Project Explorer";
    	root.id = "Root";
    	root.li_attr = {"class": "TreeRoot"};
    	root.children = [];
        for (var i = 0; i < projects.length; i++ ) {
        	var proji = projects[i];
        	appendProject(root.children, proji);
        }
        return root;
	}
	
    var workspaceTree = function(projects) {
    	var wsData= {
                "core": {
                	"themes": { "responsive": false },
    		        "check_callback": true,
    		        "data": []
    		    },
                "types": {
                    "default": {"icon": "fa fa-folder icon-state-warning icon-lg" },
                    "file": { "icon": "fa fa-file icon-state-warning icon-lg"}
                },
                
                "plugins": ["wholerow", "contextmenu", "state", "types"],
                "contextmenu": {"items": customMenu}
            };
    	var root = appendRoot(projects);
        wsData.core.data.push(root);
        $("#workspaceTree").jstree(wsData);

    }    
    
    var refreshTree = function(data){
    	var root = appendRoot(data);
    	$("#workspaceTree").jstree(true).settings.core.data = root;
    	$("#workspaceTree").jstree("refresh");
    } 
    
    return {
        //main function to initiate the module
        init: function(data) {
            workspaceTree(data);
        },
        
    	refresh: function(data){
    		refreshTree(data);
    	}
    };

}();

if (App.isAngularJsApp() === false) {
    jQuery(document).ready(function() {
        //UITree.init();
    });
}