# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.views.generic import TemplateView
import subprocess
import os
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.utils.decorators import method_decorator
from django.http.response import HttpResponse

# Create your views here.
class HomePageView(TemplateView):
    def get(self, request, **kwargs):
        return render(request, 'index.html', context=None)
    
    
# Add this view
class TestCase1View(TemplateView):
    def get(self, request, **kwargs):
        proc = subprocess.Popen(['python -m unittest TestCases.newOTTtest'] \
                ,shell=True)
        procOutput, procError = proc.communicate()
        return render(request, 'index.html', context=None)
    
    
class TestCase2View(TemplateView):
    def get(self, request, **kwargs):
        proc = subprocess.Popen(['fuser -k 8008;fuser -k 8009;python -m unittest TestCases.testDCDPDRM'] \
                ,shell=True)
        procOutput, procError = proc.communicate()
        return render(request, 'index.html', context=None)
    
    
class RunTestCaseView(TemplateView):
    @method_decorator(csrf_exempt)   
    # Disable csrf
    def dispatch(self,request,*args,**kwargs):
        return super(RunTestCaseView,self).dispatch(request,*args,**kwargs)
    
    def post(self, request, **kwargs):
        name = request.POST.get("name","")
        proc = subprocess.Popen(['fuser -k 8008/tcp;fuser -k 8009/tcp;python -m unittest TestCases.' + name] \
                ,shell=True)
        procOutput, procError = proc.communicate()
        return HttpResponse("Hello")

