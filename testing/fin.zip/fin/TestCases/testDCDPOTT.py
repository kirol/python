'''
Created on Nov 10, 2017

@author: tt4609 - Thanh Tran
'''
import BaseTest as BaseTestMain
from TestCases.BaseTest import BaseTest
from Utils import TestUtils
import time
from Controllers import STBControl
from Configurations import TFWConfiguration

class CommonTestCases(BaseTest):
    def setUp(self):
        BaseTest.setUp(self)
        TestUtils.startWebServer()
        #BaseTestMain.restoreSTBOriginalStatus()
        
    def tearDown(self):
        TestUtils.stopWebServer()
        BaseTest.tearDown(self)
            
    def test(self):
        BaseTest.testCaseID = self.id()
        print "Test streaming a BBB URL in iTV app"
        print "Launch iTV Test App: " + TFWConfiguration.TFW_ITV_SAMPLE_APP_1_URL
        testResult = False
        STBControl.sendDTCommand("itvStartApp -sessionId 0 -url " + TFWConfiguration.TFW_ITV_SAMPLE_APP_1_URL)
        time.sleep(300)
        STBControl.sendDTCommand("itvStopApp -sessionId 0")
        BaseTest.passedTest = True
    
    def testDCDPOTT_PlayBBBURL(self):
        BaseTest.testCaseID = self.id()
        print "Test streaming a BBB URL in iTV app"
        print "Launch iTV Test App: " + TFWConfiguration.TFW_ITV_SAMPLE_APP_1_URL
        testResult = False
        STBControl.sendDTCommand("itvStartApp -sessionId 0 -url " + TFWConfiguration.TFW_ITV_SAMPLE_APP_1_URL)
        time.sleep(3)
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        time.sleep(3) #Wait for loading
        STBControl.sendRemoteKey("RIGHT", isSHEF=False)
        STBControl.sendRemoteKey("RIGHT", isSHEF=False)
        STBControl.sendRemoteKey("RIGHT", isSHEF=False)
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        for x in range(0, 650):
            time.sleep(1)
            successfulPlayBackLog = STBControl.findLog(expectedLogString="enk mediaplayer.eof() - EOF")
            if len(successfulPlayBackLog) > 0:
                testResult = True
                break
            #print actualLog
            #print "No of chars: " + str(len(actualLog))
        #time.sleep(615) #Wait for loading
        if testResult == False:
            print "The movie is not finished properly"

        STBControl.sendDTCommand("itvStopApp -sessionId 0")
        BaseTest.passedTest = testResult
        
    def testDCDPOTT_PlayTOSURL(self):
        BaseTest.testCaseID = self.id()
        print "Test streaming a Tears Of Steel URL in iTV app"
        print "Launch iTV Test App: " + TFWConfiguration.TFW_ITV_SAMPLE_APP_1_URL
        STBControl.sendDTCommand("itvStartApp -sessionId 0 -url " + TFWConfiguration.TFW_ITV_SAMPLE_APP_1_URL)
        time.sleep(3)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        time.sleep(3) #Wait for loading
        STBControl.sendRemoteKey("RIGHT", isSHEF=False)
        STBControl.sendRemoteKey("RIGHT", isSHEF=False)
        STBControl.sendRemoteKey("RIGHT", isSHEF=False)
        STBControl.sendRemoteKey("UP", isSHEF=False)
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        for x in range(0, 800):
            time.sleep(1)
            successfulPlayBackLog = STBControl.findLog(expectedLogString="enk mediaplayer.eof() - EOF")
            if len(successfulPlayBackLog) > 0:
                testResult = True
                break
            #print actualLog
            #print "No of chars: " + str(len(actualLog))
        #time.sleep(615) #Wait for loading
        if testResult == False:
            print "The movie is not finished properly"

        STBControl.sendDTCommand("itvStopApp -sessionId 0")
        BaseTest.passedTest = testResult