'''
Created on Apr 11, 2017

@author: thanhtran
'''
import time
import json
import os
from urllib2 import HTTPDigestAuthHandler
from BaseTest import BaseTest
from Utils import HttpDeamon, VoiceUtilities, TestUtils
from Utils.SpreadSheetHelper import SpreadSheetHelper
from Controllers import STBControl, SHEFHTTPRequest
from Controllers.SHEFHTTPRequest import RemoteKeyRequest, SHEFTuneRequest,SHEFgetSTBLocationsRequest,\
    SHEFSerialCommandRequest, SHEFgetMyTeamRequest, SHEFgetHDDStatusRequest,\
    SHEFGraphicsModeRequest
from Controllers.SHEFJSONResponse import RemoteKeyResponse, tunePrivateResponse, SHEFtuneResponse, SHEFgetSTBLocationsResponse,\
    SHEFSerialCommandResponse, SHEFgetMyTeamResponse, SHEFgetHDDStatusResponse,\
    SHEFGraphicsModeResponse
from Controllers.SHEFHTTPRequest import TVGetTunedRequest
from Controllers.SHEFJSONResponse import TVGetTunedResponse
from Controllers.SHEFHTTPRequest import SHEFPlaylistRequest
from Controllers.SHEFHTTPRequest import SHEFRecordPrivateRequest
from STBTestingAgent.STBTestingAgent import STBDriver
from STBTestingAgent.STBTestingAgent import DesiredCapabilities
from Validations import STBValidations
from Validations.STBValidations import STBValidation
from Configurations import STBConfiguration
from Controllers.SHEFHTTPRequest import SHEFPlaybackRequest
from Controllers.SHEFHTTPRequest import TVgetProgInfoRequest
from Controllers.SHEFJSONResponse import TVgetProgInfoResponse
from Controllers.SHEFHTTPRequest import TVgetProgInfoPrivateRequest
from Controllers.SHEFJSONResponse import TVgetProgInfoPrivateResponse
from Controllers.SHEFHTTPRequest import TVGetTunedPrivateRequest
from Controllers.SHEFJSONResponse import TVGetTunedPrivateResponse
from Controllers.SHEFHTTPRequest import SHEFtunePrivateRequest
from Controllers.SHEFJSONResponse import DRMInfoResponse, VoiceResponse
from Controllers.SHEFHTTPRequest import SHEFGetPlaylistPrivateRequest, SHEFDRMRequest, SHEFGetPlaylistRequest, SHEFPlaybackViaMRVRequest, SHEFNotificationforVoiceRequest
import re
from nacl.utils import random
import random
#from Utils.Logger import Logger
from Utils import HTMLLogger


class testSample(BaseTest):
    def setUp(self):
        BaseTest.setUp(self)
        
    def tearDown(self):
        BaseTest.tearDown(self)

    def test_TuningbyRemoteKeyPlayer(self):
        '''
        @author: Nhan Tran
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case TuningbyRemoteKeyPlayer'
            HTMLLogger.log("INFO", "Running test case TuningbyRemoteKeyPlayer")
            channel = "296"
            STBControl.TuningbyKeyPlayer(channel)            
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)    
            print testError
        BaseTest.passedTest = True
         
    
    def test_RecordAndVerifyByExportXML(self):
        '''
        Created on Nov 17, 2017
        @Author: Nhan Tran
        Steps: 
            1.Send dt command to record a linear program: dt recordOneShot -channel 296
            2.Get its program title
            3.Go to Playlist then send exportXml command to get Playlist xml file
            4.Verify the program is recording in playlit or not  
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case RecordAndVerifyByExportXML'
            HTMLLogger.log("INFO", "Running test case RecordAndVerifyByExportXML")
            result = False
            STBControl.sendDTCommand("recordOneShot -channel 536")
            programTitle = STBControl.getProgramInfo(536)
            STBControl.sendRemoteKeyKeyPlayerCommand("LIST")
            time.sleep(30)
            xmlfile = STBControl.getXmlfile("PlayList")
            verifyxml = STBValidations.verifyRecordingProgram(xmlfile, programTitle)            
            if verifyxml:
                result = True
        except Exception as testError:
            #HTMLLogger.log("ERROR", testError)    
            print testError
        BaseTest.passedTest = result
        
    def test_SHEFListAllRecordingTitleInPlaylist(self):
        '''
        Created on Nov 21, 2017
        @Author: Nhan Tran
        List all recording title in Playlist
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFListAllRecordingTitleInPlaylist'
            HTMLLogger.log("INFO", "Running test case SHEFListAllRecordingTitleInPlaylist")
            result = False
            requestPlaylist = SHEFPlaylistRequest(action='get',type='user')
            sendrequest = requestPlaylist.send()            
            list = []     
            newvalue = sendrequest['updates']        
            for i in range(len(newvalue)):
                list.append(newvalue[i]['title'])                
            HTMLLogger.log("INFO","Recording list = " + json.dumps(list))   
            print "Recording list = " + json.dumps(list)         
            result = True
        except Exception as testError:            
            HTMLLogger.log("ERROR", str(testError))
            print  testError  
        BaseTest.passedTest = result

    def test_SHEFPlaybackViaMRV(self):
        '''
        Created on Nov 09, 2017
        @author:Nhanqt
        def: Playback MRV recording
        http://STBIP:port/dvr/play?uniqueId=num&udn=string[&playFrom=string][&offset=num][&clientAddr=string][&fromApp=boolean][&autoDel=boolean]
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFPlaybackViaMRV'
            result = False
            HTMLLogger.log("INFO", "Running test case SHEFPlaybackViaMRV")
            getresult = STBControl.executeCommandonMRVbox("dt getCardStatus | grep receiverID")        
            matchobj = re.match(r'.*\"([0-9]+)',getresult, re.M|re.I)
            MRVRID = matchobj.group(1)
            testID = STBControl.getUniqueID_MRVRecording()            
            requestPlayback = SHEFPlaybackViaMRVRequest(MRVuniqueId = random.choice(testID), MRVReceiverID = MRVRID)
            result = requestPlayback.send()
        except Exception as testError:
            HTMLLogger.log("ERROR", str(testError))
            print testError        
        BaseTest.passedTest = result
    
    def test_SHEFNotificationforVoice(self):
        '''
        Created on Nov 09, 2017
        @author: nhantq
        def: Notification for Voice
        http://STBIP:port/notification/voice?[clientAddr=string]
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFNotificationforVoice'
            result = False
            HTMLLogger.log("INFO", "Running test case SHEFNotificationforVoice")
            requestVoice = SHEFNotificationforVoiceRequest()
            resultResponseJSON = requestVoice.send()
            print resultResponseJSON      
            Voiceresult = VoiceResponse()
            result = Voiceresult.verifyNotificationforVoice(getVoiceResponseJSON=resultResponseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", str(testError))
            print testError        
        BaseTest.passedTest = result
    
    def test_SHEFgetHDDStatus(self):
        '''
        #author: ThanhHo
        Date: 9-Nov
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFgetHDDStatus'            
            HTMLLogger.log("INFO", "Running test case SHEFgetHDDStatus")
            getHDDStatusrequest = SHEFgetHDDStatusRequest()
            responseJSON = getHDDStatusrequest.send()
            expectedgetHDDStatusresponse = SHEFgetHDDStatusResponse()
            testresult = expectedgetHDDStatusresponse.verifyExpectedChannel(responseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = testresult
        
    def test_SHEFgetMyTeam(self):
        '''
        #author: ThanhHo
        Date: 9-Nov
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFgetMyTeam'            
            HTMLLogger.log("INFO", "Running test case SHEFgetMyTeam")
            getMyTeamrequest = SHEFgetMyTeamRequest()
            responseJSON = getMyTeamrequest.send()
            expectedgetMyTeamResponse = SHEFgetMyTeamResponse()
            testresult = expectedgetMyTeamResponse.verifyExpectedChannel(responseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = testresult

    def test_SHEFGetPlaylistPrivate(self):
        '''
        Created on Nov 08, 2017
        @author: nhantq
        def: Display getPlaylist Private
        '''
        try:                
            BaseTest.testCaseID = self.id()            
            print "Running test case SHEFGetPlaylistPrivate"
            requestPlaylist = SHEFGetPlaylistPrivateRequest(type='all')
            result = requestPlaylist.send()
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)        
        BaseTest.passedTest = result
    
    def test_SHEFGenieDvrPlaylist(self):
        '''
        Created on Nov 08, 2017
        @author: nhantq
        def: Genie - /dvr/Playlist
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFGenieDvrPlaylist'
            result = False            
            HTMLLogger.log("INFO", "Running test case SHEFGenieDvrPlaylist")
            requestPlaylist = SHEFPlaylistRequest(action='get',type='genie')
            resultrequest = requestPlaylist.send()
            if (resultrequest['status']['code']==200):
                result = True            
        except Exception as testError:
            HTMLLogger.log("ERROR", str(testError))        
        BaseTest.passedTest = result

    def test_SHEF_DRMInfo(self):
        '''
        Created on Nov 08, 2017
        @author: nhantq
        def: DRM-Info
        http://STBIP:port/drm?action=info
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEF_DRMInfo'             
            HTMLLogger.log("INFO", "Running test case SHEF_DRMInfo")
            requestDRMInfo = SHEFDRMRequest(action='info')
            resultResponseJSON = requestDRMInfo.send()
            print resultResponseJSON      
            expectedDRMresult = DRMInfoResponse()
            result = expectedDRMresult.verifyExpectedDRMStatus(getDRMInfoResponseJSON=resultResponseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result        
        
    def test_SHEF_DRMConnect(self):
        '''
        Created on Nov 08, 2017
        @author: nhantq
        def: DRM-Connect
        http://STBIP:port/drm?action=connect
        '''
        try:
            BaseTest.testCaseID = self.id()            
            HTMLLogger.log("INFO", "Running test case SHEF_DRMConnect")
            requestDRMConnect = SHEFDRMRequest(action='connect')
            result = requestDRMConnect.send()            
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result
        
    def test_SHEFgetSTBLocations(self):
        '''
        #author: ThanhHo
        Date: 8-Nov
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFgetSTBLocations'            
            HTMLLogger.log("INFO", "Running test case SHEFgetSTBLocations")
            getSTBLocationsRequest = SHEFgetSTBLocationsRequest()
            responseJSON = getSTBLocationsRequest.send()
            print responseJSON
            expectedgetSTBLocationsResponse = SHEFgetSTBLocationsResponse()
            testresult = expectedgetSTBLocationsResponse.verifyExpectedChannel(responseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = testresult
                
    def test_SHEFtune(self):
        '''
        #author: ThanhHo
        Date: 8-Nov
        '''
        try:
            BaseTest.testCaseID = self.id()         
            print 'Running test case SHEFtune'   
            HTMLLogger.log("INFO", "Running test case SHEFtune")
            tuneRequest = SHEFTuneRequest(major = "262")
            responseJSON = tuneRequest.send()
            print responseJSON
            expectedtuneResponse = SHEFtuneResponse()
            testresult = expectedtuneResponse.verifyExpectedChannel(responseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = testresult
    
    def test_SHEFtuneGlow(self):
        '''
        #author: ThanhHo
        Date: 8-Nov
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFtuneGlow'            
            HTMLLogger.log("INFO", "Running test case _SHEFtuneGlow")
            tuneRequest = SHEFTuneRequest(major = "262", source = 1)
            responseJSON = tuneRequest.send()
            print responseJSON
            expectedtuneResponse = SHEFtuneResponse()
            testresult = expectedtuneResponse.verifyExpectedChannel(responseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = testresult        
        
    def test_SHEFtunePrivate(self):
        '''
        #author: ThanhHo
        Date: 8-Nov
        '''
        try:
            BaseTest.testCaseID = self.id()            
            HTMLLogger.log("INFO", "Running test case _SHEFtunePrivate")
            tunePrivateRequest = SHEFtunePrivateRequest(major = "262")
            responseJSON = tunePrivateRequest.send()
            print responseJSON
            expectedtunePrivateResponse = tunePrivateResponse()
            testresult = expectedtunePrivateResponse.verifyExpectedChannel(responseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = testresult
        
    def test_SHEFgetProgInfo(self):
        
        '''
        #author: ThanhHo
        def: Get Program Info
        http://STBIP:port/tv/getProgInfo?major=num[&minor=num][&time=num][&clientAddr=string]
                       
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFgetProgInfo'             
            HTMLLogger.log("INFO", "Running test case _SHEFgetProgInfo")
            remoteKeyRequest = RemoteKeyRequest(key = "exit", hold = None, clientAddr=STBConfiguration.CxclientAddr)
            remoteresponseJSON = remoteKeyRequest.send()
            time.sleep(5)
            tvgetProgInfoRequest = TVgetProgInfoRequest (major= "292", minor=None, time=None, clientAddr=STBConfiguration.CxclientAddr)
            responseJSON = tvgetProgInfoRequest.send()
            print responseJSON
            expectedgetProgInfoResponse = TVgetProgInfoResponse (channelName = "DXDHD", channelIndex = 292 )
            testresult = expectedgetProgInfoResponse.verifyExpectedProgInfo(responseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = testresult
        
    def test_SHEF_DisplayGetPlaylist(self):
        '''
        Created on Nov 07, 2017
        @author: nhantq        
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEF_DisplayGetPlaylist'            
            HTMLLogger.log("INFO", "Running test case SHEF_DisplayGetPlaylist")
            requestPlaylist = SHEFGetPlaylistRequest(type='all')
            result = requestPlaylist.send()
            HTMLLogger.log("INFO", "Running result is " + str(result))
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result
    
    def test_SHEFGenieGetPlaylist(self):
        '''
        Created on Nov 07, 2017
        @author: nhantq
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEF_DisplayGetPlaylist'            
            HTMLLogger.log("INFO", "Running test case SHEF_DisplayGetPlaylist")
            requestPlaylist = SHEFGetPlaylistRequest(type='all')
            requestPlaylist = SHEFGetPlaylistRequest(type='genie')
            result = requestPlaylist.send()
            HTMLLogger.log("INFO", "Running result is " + str(result))
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result 
        
    def test_SHEFgetVersion(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print 'Running test case SHEFgetVersion'
        #print "This test case prints out the info of STB including receiverID, CAMID and STBSoftwareVersion"
        HTMLLogger.log("DEBUG","This test case prints out the info of STB including receiverID, CAMID and STBSoftwareVersion", True) #author: Tienttt
        #logger.log("INFO", "This test case prints out the info of STB including receiverID, CAMID and STBSoftwareVersion")
        result = SHEFHTTPRequest.GetVersion()
        HTMLLogger.log("DEBUG", str(result.send()), True) #author: Tienttt
        BaseTest.passedTest = True     
        
    def test_SHEFgetOptions(self):
        '''
        @author: tienttt        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case prints out the options of STB "
        result = SHEFHTTPRequest.GetOptions()
        print(result.send())
        BaseTest.passedTest = True
        
    def test_SHEFModeInfo(self):
        '''
        @author: tienttt        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case prints out the options of STB "
        result = SHEFHTTPRequest.ModeInfo()
        print(result.send())
        BaseTest.passedTest = True   
        
    def test_SHEFgetSettings(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case prints out the settings of STB"
        result = SHEFHTTPRequest.GetSettings()
        print(result.send())
        BaseTest.passedTest = True     
        
    def test_SHEFgetToDoList(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case displays all booking, schedule in To Do List"
        getToDoList = SHEFHTTPRequest.ToDoListRequest(action='get')
        print(getToDoList.send())
        BaseTest.passedTest = True     
    
    def test_SHEFdeleteToDoList(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case delete one booking, schedule in To Do List"
        deleteToDoList = SHEFHTTPRequest.ToDoListRequest(action='delete', id=6) # id number of booking/scheduler please refer to id number of get to do list command
        deleteResult = deleteToDoList.send()
        if deleteResult == 200:
            BaseTest.passedTest = True
            print('Id of booking/schedule is deleted successfully')
        else:
            BaseTest.passedTest = False
            print('Invalid Id of booking, please double check')         
    
    def test_SHEFmodifyToDoList(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case modify keepUntil, start and stop info of booking, schedule in To Do List" #keepUntil, start and stop info of booking/scheduler please refer to keepUntil, start and stop info of get to do list command
        modifyTodoList = SHEFHTTPRequest.ToDoListRequest(action='modify', id=10, keepUntil=1, start=1, stop=1)
        modifyResult = modifyTodoList.send()
        if modifyResult == 200:
            BaseTest.passedTest = True
            print('Id of booking/schedule is deleted successfully')
        else:
            BaseTest.passedTest = False
            print('Invalid Id of booking, please double check')    
            BaseTest.passedTest = True
    
    def test_SHEFgetSeriesManger(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case displays all series booking in Series Manager" 
        getSeries = SHEFHTTPRequest.SeriesManagerRequest(action='get')
        print(getSeries.send())
        BaseTest.passedTest = True
        
    def test_SHEFmodifySeriesManger(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case modify espisodeType, keepAtMost, keepUntil, start, stop and id info of series booking in Series Manager" #espisodeType, keepAtMost, keepUntil, start, stop and id  info of series booking please refer to info of get series manager command
        modifySeries = SHEFHTTPRequest.SeriesManagerRequest(action='modify', id=21, episodeType=1, keepAtMost=5, keepUntil=0, start=0, stop=0)
        modifyResult = modifySeries.send()
        if modifyResult == 200:
            BaseTest.passedTest = True
            print('Series is updated successfully')
        else:
            BaseTest.passedTest = False
            print('Invalid Id of series, please double check') 
        
    def test_SHEFdeleteSeriesManger(self):
        '''
        @author: hoahtk        
        '''
        BaseTest.testCaseID = self.id()
        print "This test case delete one series booking in Series Manager"
        deleteSeries = SHEFHTTPRequest.SeriesManagerRequest(action='delete', id=21) # id number of booking/scheduler please refer to id number of get series manager command
        deleteResult = deleteSeries.send()
        if deleteResult == 200:
            BaseTest.passedTest = True
            print('Series is deleted successfully')
        else:
            BaseTest.passedTest = False
            print('Invalid Id of series, please double check') 
        
    def test_SHEFPlaybackRecording_UniqueId(self):
        '''
        @author: nhantq
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFPlaybackRecording_UniqueId'            
            HTMLLogger.log("INFO", "Running test case SHEFPlaybackRecording_UniqueId")            
            testID = STBControl.getUniqueIDofPlaylistRecording()
            requestPlaylist = SHEFPlaybackRequest(uniqueId=random.choice(testID), playFrom='start')
            result = requestPlaylist.send()
            HTMLLogger.log("INFO", "Running result is " + str(result))
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result
        
    def test_SHEFPlaybackVOD_MaterialId(self):
        '''
        @author: Nhan Tran
        '''   
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFPlaybackVOD_MaterialId'            
            HTMLLogger.log("INFO", "Running test case SHEFPlaybackVOD_MaterialId") 
            requestPlaylist = SHEFPlaybackRequest(materialId='X000023638M3', playFrom='start')
            result = requestPlaylist.send()
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result
        
    def test_SHEFPlaybackVOD_MaterialId_withOffset(self):
        '''
        @author: Nhan Tran
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFPlaybackVOD_MaterialId_withOffset'            
            HTMLLogger.log("INFO", "Running test case SHEFPlaybackVOD_MaterialId_withOffset") 
            requestPlaylist = SHEFPlaybackRequest(materialId='B001083276M3', playFrom='offset', offset=500)
            result = requestPlaylist.send()
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result
     
    def test_RemoteKeySHEFonClient_SendRemoteKeySHEF(self):
        '''
        @author: Nhan Tran
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case RemoteKeySHEFonClient_SendRemoteKeySHEF'            
            HTMLLogger.log("INFO", "Running test case RemoteKeySHEFonClient_SendRemoteKeySHEF") 
            requestkey = RemoteKeyRequest(key='guide', clientAddr=STBConfiguration.CxclientAddr)
            result = requestkey.send()        
            time.sleep(3)        
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result 
        
    def test_SHEFDisplayPlaylist(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE: Display playlist items using SHEF command and find a recording exist or not"
        requestPlaylist = SHEFPlaylistRequest(action='get',type='user')
        result = requestPlaylist.send()
        #print json.dumps(result)
        datasearch = json.dumps(result)
        print "datasearch is %s" % datasearch      
        if datasearch.find("The Looney Tunes Show") != -1:
            print "The Looney Tunes Show is existing in playlist"                
        else:
            print "Program is not found"        
        BaseTest.passedTest = True
        
    def test_SHEFDeleteItemInPlaylist(self):
        '''
        @author: Nhan Tran
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFDeleteItemInPlaylist'
            result = False            
            HTMLLogger.log("INFO", "Running test case SHEFDeleteItemInPlaylist") 
            testID = STBControl.getUniqueIDofPlaylistRecording()
            requestPlaylist = SHEFPlaylistRequest(action='delete',uniqueId=random.choice(testID))
            resultrequest = requestPlaylist.send()
            if (resultrequest['status']['code']==200):
                result = True            
        except Exception as testError:
            HTMLLogger.log("ERROR", str(testError))
            print testError        
        BaseTest.passedTest = result     
    
    def test_SHEFRecordPrivate_Onetouch(self):
        '''
        @author: Nhan Tran
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFRecordPrivate_Onetouch'            
            HTMLLogger.log("INFO", "Running test case SHEFRecordPrivate_Onetouch") 
            requestRecord = SHEFRecordPrivateRequest(type='oneTouch',major=299)
            result = requestRecord.send()
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result     
    
    def test_SHEFRecordPrivate_Manual(self):
        '''
        @author: Nhan Tran
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFRecordPrivate_Manual'            
            HTMLLogger.log("INFO", "Running test case SHEFRecordPrivate_Manual")
            requestRecord = SHEFRecordPrivateRequest(type='manual',major=542, recurrence='daily')
            result = requestRecord.send()
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result
    
    def test_SHEFRecordPrivate_Series(self):
        '''
        @author: Nhan Tran
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case _SHEFRecordPrivate_Series'            
            HTMLLogger.log("INFO", "Running test case _SHEFRecordPrivate_Series")
            requestRecord = SHEFRecordPrivateRequest(type='series',major=296)
            result = requestRecord.send()
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = result 
        
    def test_SHEFgetProgInfoPrivate(self):
        '''
        #author: ThanhHo
        def: Get Program Info Private
        http://STBIP:port/tv/getProgInfo?major=num[&minor=num][&time=num][&clientAddr=string]
                       
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFgetProgInfoPrivate'            
            HTMLLogger.log("INFO", "Running test case SHEFgetProgInfoPrivate")
            tvgetProgInfoPrivateRequest = TVgetProgInfoPrivateRequest (major="262", minor = None, time = None, honorPC = False, clientAddr = None)
            responseJSON = tvgetProgInfoPrivateRequest.send()
            expectedgetProgInfoPrivateResponse = TVgetProgInfoPrivateResponse (channelName = "REAL", channelIndex = 262)
            testresult = expectedgetProgInfoPrivateResponse.verifyExpectedProgInfoPrivate(responseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = testresult 

    def test_SHEFgetTunedPrivate(self):
        '''
        #author: ThanhHo
        def: Get Program Info Private
        http://STBIP:port/tv/getProgInfo?major=num[&minor=num][&time=num][&clientAddr=string]
                       
        '''
        try:
            BaseTest.testCaseID = self.id()
            print 'Running test case SHEFgetTunedPrivate'            
            HTMLLogger.log("INFO", "Running test case _SHEFgetTunedPrivate")
            STBControl.executeCommand("watch -channel 262")
            tvgetTunedPrivateRequest = TVGetTunedPrivateRequest()
            responseJSON = tvgetTunedPrivateRequest.send()
            print responseJSON
            expectedgetTunedPrivateResponse = TVGetTunedPrivateResponse(channelName = "REAL", channelIndex = 262)
            testresult = expectedgetTunedPrivateResponse.verifyExpectedChannel(responseJSON)
        except Exception as testError:
            HTMLLogger.log("ERROR", testError)
            print testError        
        BaseTest.passedTest = testresult 
    
    def test_testSampleTestCase0_executeSTBCommand(self):
        BaseTest.testCaseID = self.id()
        result = STBControl.executeCommand("cat /proc/stat")
        print result
        BaseTest.passedTest = True
        
    def test_testSampleTestCase1_SendRemoteKeySHEF(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE 1 - Send Remote Key using SHEF command"
        result = STBControl.sendRemoteKey("menu", isSHEF=True)
        time.sleep(3)
        print result
        BaseTest.passedTest = True
        
    def test_testSampleTestCase2_SendRemoteKeyKeyPlayerCommand(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE 2 - Send Remote Key using KeyPlayer command"
        result = STBControl.sendRemoteKey("GUIDE", isSHEF=False) 
        time.sleep(15)
        print result
        BaseTest.passedTest = True
        
    def test_testSampleTestCase3_SendDTCommandAndgetTVTuned(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE 3 - Send DT Command to tune to channel 202 and get TV tuned"
        #dt command to tune to channel 202 - dt watch -channel 202
        STBControl.sendDTCommand("watch -channel 202")
        time.sleep(5)
        STBControl.sendRemoteKey("exit", isSHEF=False) #OPTIONAL STEP - If the screen has GUIDE or MENU displayed, pressing EXIT will make the channel displayed in full screen
        time.sleep(5)
        tvGetTunedRequest = TVGetTunedRequest()
        responseJSON = tvGetTunedRequest.send()
        print responseJSON
        expectedTVGetTunedResponsed = TVGetTunedResponse(channelName = "CNNHD", channelIndex = 202)
        testResult = expectedTVGetTunedResponsed.verifyExpectedChannel(getTunedResponseJSON=responseJSON)
        BaseTest.passedTest = testResult
        
    def test_testSampleTestCase4_PrintScreenShot(self):
        BaseTest.testCaseID = self.id()
        print "IN TESTCASE 4: PrintScreenShot"
        STBControl.takeUIScreenshot(self.id())
        BaseTest.passedTest = True
        
    def test_testMenuScreenDisplay(self):
        '''
        Test steps
        1. Send menu Key (dt/shef)
        2. Get xml file of the 1st screen from STB to PC --> STB Control (outfile)
        3. Verify screen status (XML_Parser) --> To STBValidation
        4. Send down Key (dt/shef)
        5. Get xml file of the 1st screen from STB to PC --> STB Control (outfile)
        6. Verify screen status (XML_Parser) --> To STBValidation
        '''
        
        BaseTest.testCaseID = self.id()
        print "Test case to verify MENU display"
        #Send MENU key to STB
        STBControl.sendRemoteKey("MENU", isSHEF=False)
        time.sleep(5)
        currentScreenXMLFile = STBControl.getCurrentScreenXMLFile("0_screen_MenuScreen.xml")
        time.sleep(5)
        STBValidations.verifyMenuScreenIsDisplayed(currentScreenXMLFile)
        #STBControl.sendRemoteKey("SELECT", isSHEF=False)
        
        #Send DOWN key to STB
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        time.sleep(5)
        currentScreenXMLFile = STBControl.getCurrentScreenXMLFile("1_screen_MenuScreen.xml")
        time.sleep(5)
        STBValidations.verifyMenuScreenIsDisplayed(currentScreenXMLFile, fieldFocus="Recordings")
        time.sleep(5)
        
        #Send UP key to STB
        STBControl.sendRemoteKey("UP", isSHEF=False)
        time.sleep(5)
        currentScreenXMLFile = STBControl.getCurrentScreenXMLFile("2_screen_MenuScreen.xml")
        time.sleep(5)
        STBValidations.verifyMenuScreenIsDisplayed(currentScreenXMLFile)
        time.sleep(5)
        
        #Send RIGHT key to STB
        STBControl.sendRemoteKey("RIGHT", isSHEF=False)
        time.sleep(5)
        currentScreenXMLFile = STBControl.getCurrentScreenXMLFile("3_screen_MenuScreen.xml")
        time.sleep(5)
        STBValidations.verifyMenuScreenIsDisplayed(currentScreenXMLFile, fieldFocus="default-Poster2Selected")
        time.sleep(5)
        
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        time.sleep(10)
        
        BaseTest.passedTest = True
        
    def test_testClientTestAgent(self):
        BaseTest.testCaseID = self.id()
        print "Test case to verify MENU display through testing agent library"
        desiredCapabilities = DesiredCapabilities(STBModel="HR54", STBManufacturer="PAC", STBIP="192.168.1.100", STBTestingServerAgentPort="8080")
        driver = STBDriver(desiredCapabilities)
        jsonReturned = driver.sendKey("menu")
        #print jsonReturned
        currentScreenXMLFile = STBControl.getCurrentScreenXMLFile("0_screen_MenuScreen.xml")
        screenXML = STBControl.getCurrentScreenXMLAsDict(currentScreenXMLFile)
        print screenXML
        
        print driver.findElementById(screenXML, "What_On_Now_item_2")
        
        
        BaseTest.passedTest = True
        
    def test_testParentalControl(self):
        BaseTest.testCaseID = self.id()
        print "Test case to test Parental Control through testing agent library"
        desiredCapabilities = DesiredCapabilities(STBModel="HR54", STBManufacturer="PAC", STBIP="192.168.1.100", STBTestingServerAgentPort="8080")
        driver = STBDriver(desiredCapabilities)
        #Press Menu key to open Menu screen
        STBControl.sendRemoteKey("MENU", isSHEF=False)
        #Press down to move to Setting
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        #Press Right to move to Parental Control
        STBControl.sendRemoteKey("RIGHT", isSHEF=False)
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        #Press Down to move to Movie Ratings
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        #Press 1234 to unlock
        STBControl.sendRemoteKey("1", isSHEF=False)
        STBControl.sendRemoteKey("2", isSHEF=False)
        STBControl.sendRemoteKey("3", isSHEF=False)
        STBControl.sendRemoteKey("4", isSHEF=False)
        #Press down to move to Allow R
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        #Press Exit to back to Live TV screen
        STBControl.sendRemoteKey("EXIT", isSHEF=False)
        #Press Menu Key and play The Batman Movie
        STBControl.sendRemoteKey("MENU", isSHEF=False)
        STBControl.sendRemoteKey("DOWN", isSHEF=False)
        STBControl.sendRemoteKey("SELECT", isSHEF=False)
        
        BaseTest.passedTest = True
    

    