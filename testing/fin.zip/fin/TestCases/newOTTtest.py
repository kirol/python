'''
Created on Dec 05, 2017

@author: Nhan Tran
'''
import BaseTest as BaseTestMain
from TestCases.BaseTest import BaseTest
from Utils import TestUtils
import time
from Controllers.STBHTTPRequest import KeyPressRequest, sendDTcommandResquest
from Controllers.STBHTTPResponse import KeyPressResponse, sendDTcommandResponse
from Configurations import TFWConfiguration
from Controllers import STBControl

class CommonTestCases(BaseTest):
    def setUp(self):
        BaseTest.setUp(self)
        TestUtils.startWebServer()        
        
    def tearDown(self):
        time.sleep(30)
        TestUtils.stopWebServer()
        BaseTest.tearDown(self)
            
    def test(self):
        BaseTest.testCaseID = self.id()
        print "Test streaming a BBB URL in iTV app"
        print "Launch iTV Test App: " + TFWConfiguration.TFW_ITV_SAMPLE_APP_1_URL
        #testResult = False
        sendDTcommandResquest()
        time.sleep(3)
        KeyPressRequest("SELECT")
        time.sleep(3)
        KeyPressRequest("RIGHT")
        time.sleep(2)
        #=======================================================================
        # KeyPressRequest("RIGHT")
        # time.sleep(2)
        # KeyPressRequest("RIGHT")
        # time.sleep(2)
        #=======================================================================
        KeyPressRequest("SELECT")
        
		
        for x in range(0, 20):
            time.sleep(1)
            successfulPlayBackLog = STBControl.findLog(expectedLogString="File PLAYING")
            if len(successfulPlayBackLog) > 0:
                testResult = True
                print "The movie is finished properly" 
                break            
        #=======================================================================
        # if testResult == False:
        #     print "The movie is not finished properly"        
        #=======================================================================
       
        self.assertEqual(testResult,True)
        BaseTest.passedTest = testResult
        
        
        
        
        