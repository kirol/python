'''
Created on Dec 05, 2017

@author: Nhan Tran
'''
import BaseTest as BaseTestMain
from TestCases.BaseTest import BaseTest
from Utils import TestUtils
import time
from Controllers.STBHTTPRequest import KeyPressRequest, sendDTcommandResquest, getScreenshot
from Controllers.STBHTTPResponse import KeyPressResponse, sendDTcommandResponse
from Configurations import TFWConfiguration
from Controllers import STBControl

class CommonTestCases(BaseTest):
    def setUp(self):
        BaseTest.setUp(self)
        TestUtils.startWebServer()        
        
    def tearDown(self):
        time.sleep(30)
        TestUtils.stopWebServer()
        BaseTest.tearDown(self)
            
    def test(self):
        BaseTest.testCaseID = self.id()
        getScreenshot()
        BaseTest.passedTest = True
        
        
        
        
        