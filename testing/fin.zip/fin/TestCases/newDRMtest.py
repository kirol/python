'''
Created on Dec 05, 2017

@author: Nhan Tran
'''
from TestCases.BaseTest import BaseTest
from Controllers import STBControl
from Utils import TestUtils
from Configurations import TFWConfiguration
from Configurations import STBConfiguration
from Controllers.STBHTTPRequest import KeyPressRequest, sendDTcommandResquest, sendPlayReadyCommandRequest
from Controllers.STBHTTPResponse import KeyPressResponse, sendDTcommandResponse, sendPlayReadyCommandResponse
import time

#===============================================================================
# class CommonTestCases(BaseTest):
#     def setUp(self):
#         BaseTest.setUp(self)
#         
#     def tearDown(self):
#         BaseTest.tearDown(self)
#             
#     def testDCDPDRM_PlayReadyURL(self):
#         BaseTest.testCaseID = self.id()
#         print "Test streaming a playready URL"
#         testUrl = "http://profficialsite.origin.mediaservices.windows.net/c51358ea-9a5e-4322-8951-897d640fdfd7/tearsofsteel_4k.ism/manifest(format=mpd-time-csf)"
#         sendrequest = sendDTcommandRequest(testUrl)        
#         expectResult = sendDTcommandResponse()
#         result = expectResult.verifysendDTcommandResponse(sendrequest)
#         time.sleep(100)
#         BaseTest.passedTest = result
#     
#     def testDCDPDRM_PlayBigBuckBunny(self):
#         BaseTest.testCaseID = self.id()
#         print "Test streaming a playready URL"
#         testUrl = "http://dash.edgesuite.net/akamai/bbb_30fps/bbb_30fps.mpd"
#         sendrequest = sendDTcommandRequest(testUrl)        
#         expectResult = sendDTcommandResponse()
#         result = expectResult.verifysendDTcommandResponse(sendrequest)
#         time.sleep(100)
#         BaseTest.passedTest = result
#         
#===============================================================================
        
class PerformanceTestCases(BaseTest):
    def setUp(self):
        BaseTest.setUp(self)
        
    def tearDown(self):
        BaseTest.tearDown(self)
        
    #===========================================================================
    # def test_restfulAPI(self):
    #     BaseTest.testCaseID = self.id()
    #     print "Test streaming a playready URL"
    #     commandResponse = sendPlayReadyCommandRequest()
    #     result = sendPlayReadyCommandResponse(commandResponse)
    #     self.assertEqual(result,True)
    #     BaseTest.passedTest = result
    #===========================================================================
    
    def test_dtCommand(self):
        BaseTest.testCaseID = self.id()
        print "Test streaming a playready URL"
        #STBControl.sendDTCommand('playURL -url http://dash.edgesuite.net/akamai/bbb_30fps/bbb_30fps.mpd')
        STBControl.sendDTCommand('startStream -sessionId 0 -cmd load -url http://dash.edgesuite.net/akamai/bbb_30fps/bbb_30fps.mpd -type dash')
        time.sleep(900)        
        TestUtils.monitor_performance(TFWConfiguration.TFWSRV_IP, TFWConfiguration.TFWSRV_USERID, TFWConfiguration.TFWSRV_USERPASS, True, "TTYS6", STBConfiguration.STBIPAddress, STBConfiguration.STBModel, STBConfiguration.STBManufacturer, STBConfiguration.SSHRootPass, "2", "RemoteMp4MediaStream")
        #self.assertEqual(result,True)
        #BaseTest.passedTest = result