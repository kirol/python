'''
Created on Oct 19, 2017

@author: tt4609
'''
SERVERAGENTSENDKEYAPI = "remote/processKey"

