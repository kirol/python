'''
Created on Oct 18, 2017

@author: thanhtran
'''

import requests
import Information
import time

class DesiredCapabilities():
    _STBModel = None
    _STBManufacturer = None
    _STBIP = None
    _STBTestingServerAgentPort = None
    
    def __init__(self, STBModel, STBManufacturer, STBIP, STBTestingServerAgentPort):
        self._STBModel = STBModel
        self._STBManufacturer = STBManufacturer
        self._STBIP = STBIP
        self._STBTestingServerAgentPort = STBTestingServerAgentPort
        
    
class STBDriver():
    _desiredCapabilities = None
    def __init__(self, desiredCapabilities=None):
        self._desiredCapabilities = desiredCapabilities

    def setDesiredCapabilities(self, desiredCapabilities):
        self._desiredCapabilities = desiredCapabilities
        
    def sendKey(self, key):
        SENDKEYAPI = "http://" + self._desiredCapabilities._STBIP + ":" + self._desiredCapabilities._STBTestingServerAgentPort + "/" + Information.SERVERAGENTSENDKEYAPI
        payload = {'key' : key }
        r = requests.get(SENDKEYAPI, params=payload)   
        return r.text
        time.sleep(1)
        
    def findElementById(self, xmldoc, id):
        print "Will be implemented later"
        if id is "What_On_Now_item_2":
            return {"text" : str(xmldoc['Screen']['Widget'][0]['Posters']['Poster'][1]['#text'])}
        
        