var Controller = {};
var mediaplayer = {};
var _video;
var _audio;
var IP = location.host;
var STB_IP = "localhost";
var currCh = Channel.getCurrentChannel();
console.log("enk current channel = "+currCh.getMajorNumber());
var isClient = navigator.isClient();
console.log("enk isClient? "+isClient);
var videoPlaying = false;
var liveTV = true;
var count = 0;
var curTime = 0;
var buffPos = 0;
var duration = 0;
var testNum = 0;
var srcAttr;
var progTitle = "";
var progDuration = 0;
var progDescription = "";

var img = new Image(1920, 1080);
img.src = "background.jpeg";
function arbiterInit() {
    navigator.setResolution(1920,1080);
    try {
        var result = navigator.drawImageInBackground(img, 0, 0, 1920, 1080);
    } catch(ex) {
        result = "    Error: " + ex.message;
        console.log("draw bg error" + result);
    }
    try {
        var result = navigator.clearBackground(575, 200, 1230, 540);
    } catch(ex) {
        result = "    Error: " + ex.message;
        console.log("clear bg  error" + result);
    }
    VideoSource.setInputOutputWindow(0,0,1920,1080, 575,200,1230,540);
}

var title1, title2, title3, title4, title5;
var source1, source2, source3, source4, source5;
var type1, type2, type3, type4, type5;
var progTitle1, progTitle2, progTitle3, progTitle4;
var progDuration1, progDuration2, progDuration3, progDuration4, progDuration5;
var progDescription1, progDescription2, progDescription3, progDescription4, progDescription5;

var linksSet1 = [   // HLS Video Pg. 1
    {   
        "title":"Big Bug Bunny", 
        "source":"http://184.72.239.149/vod/smil:BigBuckBunny.smil/playlist.m3u8", 
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"Basic Stream 1",
	"progDuration":"60",
	"progDescription":"Big Bug Bunny"
    },  
    {   
        "title":"Tears Of Steel", 
        "source":"http://s3.amazonaws.com/_bc_dml/example-content/tears-of-steel/playlist.m3u8",
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"Basic Stream 2",
        "progDuration":"6298",
        "progDescription":"Tear Of Steel"	

    },  
    {   
        "title":"HTTPS Basic Stream",
        "source":"https://telserv1.dtvbb.tv/webkit/hls_video/video/basic/index.m3u8",
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"HTTPS Basic Stream",
        "progDuration":"60",
        "progDescription":"Description of HTTPS Basic Stream"
    },  
];
var linksSet2 = [   // HLS Video Pg. 2
    {   
        "title":"HLS ID3 Stream", 
        "source":"video/ID3/index.m3u8",
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"HLS ID3 Stream",
        "progDuration":"0",
        "progDescription":"Description of HLS ID3 Stream"
    },  
    {   
        "title":"Live Stream", 
        "source":"http://vevoplaylist-live.hls.adaptive.level3.net/vevo/ch1/01/prog_index.m3u8",
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"Live Stream",
        "progDuration":"43200",
        "progDescription":"Description of Live Stream"
    },  
    {
        "title":"Live Stream 2",
        "source":"http://vevoplaylist-live.hls.adaptive.level3.net/vevo/ch1/appleman.m3u8",
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"Live Stream 2",
        "progDuration":"0",
        "progDescription":"Description of Live Stream 2"
    },
    {   
        "title":"AES Basic Stream", 
        "source":"http://playertest.longtailvideo.com/adaptive/oceans_aes/oceans_aes.m3u8", 
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"AES Basic Stream",
        "progDuration":"118",
        "progDescription":"Description of AES Basic Stream"
    },
    {   
        "title":"AES Live Stream", 
	"source":"http://cdntest.dtvce.com/NFL/10/000325/latest.m3u8",
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"AES Live Stream",
        "progDuration":"0",
        "progDescription":"Description of AES Live Stream"
    }
];
var linksSet3 = [   // ESPN Streams 
    {
        "title":"RES=768x432",
        "source":"https://content-ausc1.uplynk.com/91edb88824c44efa9c8228a194c275f6/d.m3u8",
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"RES=768x432",
        "progDuration":"0",
        "progDescription":"Description of RES=768x432"
    },
    {
        "title":"RES=960x540",
        "source":"https://content-ausc1.uplynk.com/91edb88824c44efa9c8228a194c275f6/e.m3u8",
        "type":"application/vnd.apple.mpegurl",
        "progTitle":"RES=960x540",
        "progDuration":"0",
        "progDescription":"Description of RES=960x540"
    },
    {
        "title":"RES=1280x720",
        "source":"https://content-ausc1.uplynk.com/91edb88824c44efa9c8228a194c275f6/g.m3u8",
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"RES=1280x720",
        "progDuration":"0",
        "progDescription":"Description of RES=1280x720"
    },
    {
        "title":"RES=480x270",
        "source":"https://content-ausc1.uplynk.com/91edb88824c44efa9c8228a194c275f6/b.m3u8",
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"RES=480x270",
        "progDuration":"0",
        "progDescription":"Description of RES=480x270"
    },
    {
        "title":"RES=640x360",
        "source":"https://content-ausc1.uplynk.com/91edb88824c44efa9c8228a194c275f6/c.m3u8",
        "type":"application/vnd.apple.mpegurl",
	"progTitle":"RES=640x360",
        "progDuration":"0",
        "progDescription":"Description of RES=640x360"
    }
];
var linksSet4 = [   // MP4 Video
    {   
        "title":"TrueBlood.mp4", 
        "source":"./src/TrueBlood.mp4", 
        "type":"video/mp4",
	"progTitle":"TrueBlood",
        "progDuration":"40",
        "progDescription":"Description of TrueBlood"
    },
    {   
        "title":"Boardwalk.mp4", 
        "source":"./src/Boardwalk.mp4",
        "type":"video/mp4",
	"progTitle":"Boardwalk",
        "progDuration":"40",
        "progDescription":"Description of Boardwalk"
    },
    {   
        "title":"Girls.mp4", 
        "source":"./src/Girls.mp4", 
        "type":"video/mp4",
	"progTitle":"Girls",
        "progDuration":"35",
        "progDescription":"Description of Girls"
    },
    {   
        "title":"Missing MP4", 
        "source":"./src/Pandora.mp4",
        "type":"video/mp4"
    },
    {   
        "title":"Corrupted MP4", 
        "source":"./src/Corrupt.mp4",
        "type":"video/mp4"
    }
];
var linksSet5 = [   // Error Test Case
    {
        "title":"Crpt EXT-X-BYTERANGE", 
        "source":"http://live.theriverworshipcentre.org/trash/video-js/node_modules/videojs-contrib-hls/test/manifest/byteRange.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"Crpt EXTINF",
        "source":"https://telserv1.dtvbb.tv/video/error/error2/bipbopCorruptedExtInf/bipbopall.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"Crpt EXT-X-MEDIA-SEQ",
        "source":"https://telserv1.dtvbb.tv/video/error/error3/bipbopShortCorrputedExtMediaSequence/bipbopall.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"Crpt EXT-X-TARGETDUR",
        "source":"https://telserv1.dtvbb.tv/video/error/error4/bipbopCorrputedTargetDuration/bipbopall.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"Crpt Ext-X-STREAM-INF",
        "source":"https://telserv1.dtvbb.tv/video/error/error5/bipbopCorruptedStreamInf/bipbopall.m3u8",
        "type":"application/vnd.apple.mpegurl"
    }
];
var linksSet6 = [   // Error Test Case #2
    {
        "title":"Missing EXTM3U tag",
        "source":"https://telserv1.dtvbb.tv/video/error/error1/bipbop_audio_only_mpeg2ts/playlist.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"EXT-X-IFRAMES-ONLY",
        "source":"https://telserv1.dtvbb.tv/video/error/error6/iframe_index.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"EXT-X-IFRAME-STREAM-INF",
        "source":"http://85.94.1.9:8802/hls/CH_C02_SETHD/variant.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"EXT-X-INDEPENDENT-SEGMENTS",
        "source":"https://telserv1.dtvbb.tv/video/error/error7/enc.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"Invalid URL",
        "source":"https://telserv1.dtvbb.tv/video/error/error8/bipbop_not_available_for_highest_quality/bipbopall.m3u8",
        "type":"application/vnd.apple.mpegurl"
    }
];
var linksSet7 = [   // Error Test Case #3 - Currently disabled
    {
        "title":"Err11",
        "source":"https://github.com/kanongil/node-m3u8parse/blob/master/test/fixtures/enc.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"Err12",
        "source":"https://trac.redembedded.com/stream1/list.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"Err13",
        "source":"http://www.msdailynews.com/public/hls/27749731.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"Err14",
        "source":"https://github.com/Jonovono/HLS-example-streams/blob/master/iframe_index.m3u8",
        "type":"application/vnd.apple.mpegurl"
    },
    {
        "title":"Err15",
        "source":"http://85.94.1.9:8802/hls/CH_C02_SETHD/variant.m3u8",
        "type":"application/vnd.apple.mpegurl"
    }
];

var currentPage = linksSet1;


function checkNodeName() {
    if (currentPage == linksSet1) {
        console.log("enk currentPage == linksSet1");
        document.getElementById("s1").childNodes[1].childNodes[0].innerHTML = linksSet1[0].title;
        title1 = linksSet1[0].title;
        source1 = linksSet1[0].source; 
        type1 = linksSet1[0].type;
        document.getElementById("s2").childNodes[1].childNodes[0].innerHTML = linksSet1[1].title;
        title2 = linksSet1[1].title;
        source2 = linksSet1[1].source;
        type2 = linksSet1[1].type;
        //document.getElementById("s3").childNodes[1].childNodes[0].innerHTML = linksSet1[2].title;
        //title3 = linksSet1[2].title;
        //source3 = linksSet1[2].source;
        //type3 = linksSet1[2].type;
        //document.getElementById("s4").childNodes[1].childNodes[0].innerHTML = linksSet1[3].title;
        //title4 = linksSet1[3].title;
        //source4 = linksSet1[3].source;
        //type4 = linksSet1[3].type;
        //document.getElementById("s5").childNodes[1].childNodes[0].innerHTML = linksSet1[4].title;
        //title5 = linksSet1[4].title;
        //source5 = linksSet1[4].source;
        //type5 = linksSet1[4].type;
    	progTitle1= linksSet1[0].progTitle;
	progDuration1 = linksSet1[0].progDuration;
	progDescription1 = linksSet1[0].progDescription;
	progTitle2= linksSet1[1].progTitle;
        progDuration2 = linksSet1[1].progDuration;
        progDescription2 = linksSet1[1].progDescription;
	progTitle3= linksSet1[2].progTitle;
        progDuration3 = linksSet1[2].progDuration;
        progDescription3 = linksSet1[2].progDescription;
	//progTitle4= linksSet1[3].progTitle;
    //    progDuration4 = linksSet1[3].progDuration;
    //    progDescription4 = linksSet1[3].progDescription;
	//progTitle5= linksSet1[4].progTitle;
    //    progDuration5 = linksSet1[4].progDuration;
    //    progDescription5 = linksSet1[4].progDescription;


    } else if (currentPage == linksSet2) {
        console.log("enk currentPage == linksSet2");
        document.getElementById("s1").childNodes[1].childNodes[0].innerHTML = linksSet2[0].title;
        title1 = linksSet2[0].title;
        source1 = linksSet2[0].source;
        type1 = linksSet2[0].type;
        document.getElementById("s2").childNodes[1].childNodes[0].innerHTML = linksSet2[1].title;
        title2 = linksSet2[1].title;
        source2 = linksSet2[1].source;
        type2 = linksSet2[1].type;
        document.getElementById("s3").childNodes[1].childNodes[0].innerHTML = linksSet2[2].title;
        title3 = linksSet2[2].title;
        source3 = linksSet2[2].source;
        type3 = linksSet2[2].type;
        document.getElementById("s4").childNodes[1].childNodes[0].innerHTML = linksSet2[3].title;
        title4 = linksSet2[3].title;
        source4 = linksSet2[3].source;
        type4 = linksSet2[3].type;
        document.getElementById("s5").childNodes[1].childNodes[0].innerHTML = linksSet2[4].title;
        title5 = linksSet2[4].title;
        source5 = linksSet2[4].source;
        type5 = linksSet2[4].type;
	progTitle1= linksSet2[0].progTitle;
        progDuration1 = linksSet2[0].progDuration;
        progDescription1 = linksSet2[0].progDescription;
        progTitle2= linksSet2[1].progTitle;
        progDuration2 = linksSet2[1].progDuration;
        progDescription2 = linksSet2[1].progDescription;
        progTitle3= linksSet2[2].progTitle;
        progDuration3 = linksSet2[2].progDuration;
        progDescription3 = linksSet2[2].progDescription;
        progTitle4= linksSet2[3].progTitle;
        progDuration4 = linksSet2[3].progDuration;
        progDescription4 = linksSet2[3].progDescription;
        progTitle5= linksSet2[4].progTitle;
        progDuration5 = linksSet2[4].progDuration;
        progDescription5 = linksSet2[4].progDescription;
    } else if (currentPage == linksSet3) {
        console.log("enk currentPage == linksSet3");
        document.getElementById("s1").childNodes[1].childNodes[0].innerHTML = linksSet3[0].title;
        title1 = linksSet3[0].title;
        source1 = linksSet3[0].source;
        type1 = linksSet3[0].type;
        document.getElementById("s2").childNodes[1].childNodes[0].innerHTML = linksSet3[1].title;
        title2 = linksSet3[1].title;
        source2 = linksSet3[1].source;
        type2 = linksSet3[1].type;
        document.getElementById("s3").childNodes[1].childNodes[0].innerHTML = linksSet3[2].title;
        title3 = linksSet3[2].title;
        source3 = linksSet3[2].source;
        type3 = linksSet3[2].type;
        document.getElementById("s4").childNodes[1].childNodes[0].innerHTML = linksSet3[3].title;
        title4 = linksSet3[3].title;
        source4 = linksSet3[3].source;
        type4 = linksSet3[3].type;
        document.getElementById("s5").childNodes[1].childNodes[0].innerHTML = linksSet3[4].title;
        title5 = linksSet3[4].title;
        source5 = linksSet3[4].source;
        type5 = linksSet3[4].type;
	progTitle1= linksSet3[0].progTitle;
        progDuration1 = linksSet3[0].progDuration;
        progDescription1 = linksSet3[0].progDescription;
        progTitle2= linksSet3[1].progTitle;
        progDuration2 = linksSet3[1].progDuration;
        progDescription2 = linksSet3[1].progDescription;
        progTitle3= linksSet3[2].progTitle;
        progDuration3 = linksSet3[2].progDuration;
        progDescription3 = linksSet3[2].progDescription;
        progTitle4= linksSet3[3].progTitle;
        progDuration4 = linksSet3[3].progDuration;
        progDescription4 = linksSet3[3].progDescription;
        progTitle5= linksSet3[4].progTitle;
        progDuration5 = linksSet3[4].progDuration;
        progDescription5 = linksSet3[4].progDescription;
    } else if (currentPage == linksSet4) {
        console.log("enk currentPage == linksSet4");
        document.getElementById("s1").childNodes[1].childNodes[0].innerHTML = linksSet4[0].title;
        title1 = linksSet4[0].title;
        source1 = linksSet4[0].source;
        type1 = linksSet4[0].type;
        document.getElementById("s2").childNodes[1].childNodes[0].innerHTML = linksSet4[1].title;
        title2 = linksSet4[1].title;
        source2 = linksSet4[1].source;
        type2 = linksSet4[1].type;
        document.getElementById("s3").childNodes[1].childNodes[0].innerHTML = linksSet4[2].title;
        title3 = linksSet4[2].title;
        source3 = linksSet4[2].source;
        type3 = linksSet4[2].type;
        document.getElementById("s4").childNodes[1].childNodes[0].innerHTML = linksSet4[3].title;
        title4 = linksSet4[3].title;
        source4 = linksSet4[3].source;
        type4 = linksSet4[3].type;
        document.getElementById("s5").childNodes[1].childNodes[0].innerHTML = linksSet4[4].title;
        title5 = linksSet4[4].title;
        source5 = linksSet4[4].source;
        type5 = linksSet4[4].type;
	progTitle1= linksSet4[0].progTitle;
        progDuration1 = linksSet4[0].progDuration;
        progDescription1 = linksSet4[0].progDescription;
        progTitle2= linksSet4[1].progTitle;
        progDuration2 = linksSet4[1].progDuration;
        progDescription2 = linksSet4[1].progDescription;
        progTitle3= linksSet4[2].progTitle;
        progDuration3 = linksSet4[2].progDuration;
        progDescription3 = linksSet4[2].progDescription;
        progTitle4= linksSet4[3].progTitle;
        progDuration4 = linksSet4[3].progDuration;
        progDescription4 = linksSet4[3].progDescription;
        progTitle5= linksSet4[4].progTitle;
        progDuration5 = linksSet4[4].progDuration;
        progDescription5 = linksSet4[4].progDescription;
    } else if (currentPage == linksSet5) {
        console.log("enk currentPage == linksSet5");
        document.getElementById("s1").childNodes[1].childNodes[0].innerHTML = linksSet5[0].title;
        title1 = linksSet5[0].title;
        source1 = linksSet5[0].source;
        type1 = linksSet5[0].type;
        document.getElementById("s2").childNodes[1].childNodes[0].innerHTML = linksSet5[1].title;
        title2 = linksSet5[1].title;
        source2 = linksSet5[1].source;
        type2 = linksSet5[1].type;
        document.getElementById("s3").childNodes[1].childNodes[0].innerHTML = linksSet5[2].title;
        title3 = linksSet5[2].title;
        source3 = linksSet5[2].source;
        type3 = linksSet5[2].type;
        document.getElementById("s4").childNodes[1].childNodes[0].innerHTML = linksSet5[3].title;
        title4 = linksSet5[3].title;
        source4 = linksSet5[3].source;
        type4 = linksSet5[3].type;
        document.getElementById("s5").childNodes[1].childNodes[0].innerHTML = linksSet5[4].title;
        title5 = linksSet5[4].title;
        source5 = linksSet5[4].source;
        type5 = linksSet5[4].type;
	progTitle1= linksSet5[0].progTitle;
        progDuration1 = linksSet5[0].progDuration;
        progDescription1 = linksSet5[0].progDescription;
        progTitle2= linksSet5[1].progTitle;
        progDuration2 = linksSet5[1].progDuration;
        progDescription2 = linksSet5[1].progDescription;
        progTitle3= linksSet5[2].progTitle;
        progDuration3 = linksSet5[2].progDuration;
        progDescription3 = linksSet5[2].progDescription;
        progTitle4= linksSet5[3].progTitle;
        progDuration4 = linksSet5[3].progDuration;
        progDescription4 = linksSet5[3].progDescription;
        progTitle5= linksSet5[4].progTitle;
        progDuration5 = linksSet5[4].progDuration;
        progDescription5 = linksSet5[4].progDescription;
    } else if (currentPage == linksSet6) {
        console.log("enk currentPage == linksSet6");
        document.getElementById("s1").childNodes[1].childNodes[0].innerHTML = linksSet6[0].title;
        title1 = linksSet6[0].title;
        source1 = linksSet6[0].source;
        type1 = linksSet6[0].type;
        document.getElementById("s2").childNodes[1].childNodes[0].innerHTML = linksSet6[1].title;
        title2 = linksSet6[1].title;
        source2 = linksSet6[1].source;
        type2 = linksSet6[1].type;
        document.getElementById("s3").childNodes[1].childNodes[0].innerHTML = linksSet6[2].title;
        title3 = linksSet6[2].title;
        source3 = linksSet6[2].source;
        type3 = linksSet6[2].type;
        document.getElementById("s4").childNodes[1].childNodes[0].innerHTML = linksSet6[3].title;
        title4 = linksSet6[3].title;
        source4 = linksSet6[3].source;
        type4 = linksSet6[3].type;
        document.getElementById("s5").childNodes[1].childNodes[0].innerHTML = linksSet6[4].title;
        title5 = linksSet6[4].title;
        source5 = linksSet6[4].source;
        type5 = linksSet6[4].type;
    } else if (currentPage == linksSet7) {
        console.log("enk currentPage == linksSet7");
        document.getElementById("s1").childNodes[1].childNodes[0].innerHTML = linksSet7[0].title;
        title1 = linksSet7[0].title;
        source1 = linksSet7[0].source;
        type1 = linksSet7[0].type;
        document.getElementById("s2").childNodes[1].childNodes[0].innerHTML = linksSet7[0].title;
        title2 = linksSet7[1].title;
        source2 = linksSet7[1].source;
        type2 = linksSet7[1].type;
        document.getElementById("s3").childNodes[1].childNodes[0].innerHTML = linksSet7[2].title;
        title3 = linksSet7[2].title;
        source3 = linksSet7[2].source;
        type3 = linksSet7[2].type;
        document.getElementById("s4").childNodes[1].childNodes[0].innerHTML = linksSet7[3].title;
        title4 = linksSet7[3].title;
        source4 = linksSet7[3].source;
        type4 = linksSet7[3].type;
        document.getElementById("s5").childNodes[1].childNodes[0].innerHTML = linksSet7[4].title;
        title5 = linksSet7[4].title;
        source5 = linksSet7[4].source;
        type5 = linksSet7[4].type;
    } else {
        console.log("enk currentPage cannot be determined!!! defaulting to linksSet1");
        currentPage = linksSet1;
        checkNodeName();
    }
}


/** @type {null|Node} */
Controller.focus = null;

/**
 *  @constructor
 *  
 *  @param {String} nodeId   
 *  @param {String} nodeType 
 *  
 */
function Node(domId, body){
  
  this.body = body;
  
  this.domId = domId;
};

function setTestCase(test) {
    testNum = test;
};

/*PAGE ERRORS: 501 (bad gateway)*/
window.onerror = function(param1, param2, param3) {
    //document.getElementById("stats").innerHTML += "!!! window.ONERROR !!!<br><br>";
    console.log("enk - window.onerror - encountered a page error");
    console.log("enk - param 1: "+param1); 
    console.log("enk - param 2: "+param2);
    console.log("enk - param 3: "+param3);
    return true; // lets error go to STB
}

/**/
Node.prototype.onFocus = function(){
    if(!!$(this.domId) ){
        $(this.domId).addClass("selected");
    }
};

/**/ 
Node.prototype.lostFocus = function(){
  if(!!$(this.domId) ){
    $(this.domId).removeClass("selected");
    if(!!$("nextPlaylistItemAudio")
      && typeof($("nextPlaylistItemAudio").play) == "function"
      && !!Core.Config.AudioFeedback ){
      $("nextPlaylistItemAudio").play();
    }
  }
};

/**/
Node.prototype.onAction = function(){
    if(!!this.img_src)
    alert(this.img_src);
};

var head = null;

var sTbody = {};

var s1body = {
  // Basic HLS 
  video : true,
};

var s2body = {
  // Live Stream - NFL
  video : true,
};

var s3body = {
  // Girls.mp4
  video : true,
};

var s4body = {
  // HLS2
  video : true,
};

var s5body = {
  // Sintel Trailer
  video : true,
};

var s7body = {
  // LIVE TV
  video : true,
};

var statusWindowbody = {
  // Status/Error
  video : false,
};

var k0body = {
  video : false,
};

var k1body = {
  video : false,
};

var k2body = {
  video : false,
};

var k3body = {
  video : false,
};

var k4body = {
  video : false,
};

var k5body = {
  video : false,
};

var k6body = {
  video : false,
};

var p1body = {};
var p2body = {};
var p3body = {};
var p4body = {};
var p5body = {};
var p6body = {};
var p7body = {};


var c1 = new Node("c1",sTbody);
// media links
var s1 = new Node("s1",s1body);
var s2 = new Node("s2",s2body);
var s3 = new Node("s3",s3body);
var s4 = new Node("s4",s4body);
var s5 = new Node("s5",s5body);
var statusWindow = new Node("statusWindow",statusWindowbody);
var s7 = new Node("s7",s7body);
// keyboard buttons
var k0 = new Node("key-0",k0body);
var k1 = new Node("key-1",k1body);
var k2 = new Node("key-2",k2body);
var k3 = new Node("key-3",k3body);
var k4 = new Node("key-4",k4body);
var k5 = new Node("key-5",k5body);
var k6 = new Node("key-6",k6body);
// pages of media links
var p1 = new Node("p1",p1body);
var p2 = new Node("p2",p2body);
var p3 = new Node("p3",p3body);
var p4 = new Node("p4",p4body);
var p5 = new Node("p5",p5body);
var p6 = new Node("p6",p6body);
var p7 = new Node("p7",p7body);

// Judge Not Lest Ye Be Judged
// Basic HLS
s1.rightNode = s4;
s1.leftNode = p1;
s1.nextNode = s2;
s1.prevNode = s3;

// Live Stream - NFL
s2.rightNode = s5;
s2.leftNode = p4;
s2.nextNode = s3;
s2.prevNode = s1;

// Girls.mp4
s3.rightNode = s7;
s3.leftNode = k6;
s3.nextNode = s1;
s3.prevNode = s2;

// HLS2
s4.rightNode = k0;
s4.leftNode = s1;
s4.nextNode = s5;
s4.prevNode = s7;

// Sintel Trailer 
s5.nextNode = s7;
s5.prevNode = s4;
s5.rightNode = k4;
s5.leftNode = s2;

// Back to live TV!
s7.nextNode = s4;
s7.prevNode = s5;
s7.rightNode = k4;
s7.leftNode = s3;

// load()
k0.nextNode = k4;
k0.prevNode = k4;
k0.rightNode = k1;
k0.leftNode = s4;

// play()
k1.nextNode = k5;
k1.prevNode = k5;
k1.rightNode = k2;
k1.leftNode = k0;

// pause()
k2.nextNode = k6;
k2.prevNode = k6;
k2.rightNode = k3;
k2.leftNode = k1;

// stop()
k3.rightNode = s1;
k3.leftNode = k2;

// currentTime += 10
k4.nextNode = k0;
k4.prevNode = k0;
k4.rightNode = k5;
k4.leftNode = s5;

// currentTime -= 10
k5.nextNode = k1;
k5.prevNode = k1;
k5.rightNode = k6;
k5.leftNode = k4;

// currentTime = 15 
k6.nextNode = k2;
k6.prevNode = k2;
k6.rightNode = s7;
k6.leftNode = k5;

// linksSet1
p1.nextNode = p2;
p1.prevNode = p4;
p1.leftNode = k3;
p1.rightNode = p5;

// linksSet2
p2.nextNode = p3;
p2.prevNode = p1;
p2.leftNode = k3;
p2.rightNode = p6;

// linksSet3
p3.nextNode = p4;
p3.prevNode = p2;
p3.leftNode = k3;
p3.rightNode = p7;

// linksSet4
p4.nextNode = p1;
p4.prevNode = p3;
p4.leftNode = k3;
p4.rightNode = s1;

// linksSet5
p5.nextNode = p6;
p5.prevNode = p7;
p5.leftNode = p1;
p5.rightNode = s1;

// linksSet6
p6.nextNode = p7;
p6.prevNode = p5;
p6.leftNode = p2;
p6.rightNode = s1;

// linksSet7
p7.nextNode = p5;
p7.prevNode = p6;
p7.leftNode = p3;
p7.rightNode = s2;

/**/
playPauseVideo = function() {
  if (videoPlaying == true) {
    document._video.pause();
    videoPlaying = false;
  }
  else {
    document._video.play();
    videoPlaying = true;
  }
};

/**/
var handleKeys = function(event){
 console.log("enk got key "+event.keyCode); 

  switch(event.keyCode){
    
    case 38: // UP
      if(!!Controller.focus.prevNode)
        Controller.setFocus(Controller.focus.prevNode);
    break;
  
    case 37: // Left
      if(!!Controller.focus.leftNode)
        Controller.setFocus(Controller.focus.leftNode);
    break;

    case 39: // Right
      if(!!Controller.focus.rightNode)
        Controller.setFocus(Controller.focus.rightNode);
    break;

    case 40: // Down
      if(!!Controller.focus.nextNode)
        Controller.setFocus(Controller.focus.nextNode);
    break;

    case 13: // Enter
      Controller.load(Controller.focus);
      liveTV = true;
      var id = Controller.focus.domId;
      console.log("mailog id = " + id );
      console.log("mailog document._video.type = " + document._video.type);
      if (id != "s7"){
        liveTV = false;
        if (document._video.type == "application/vnd.apple.mpegurl" || document._video.type == "video/mp4"){
          videoPlaying = true;
  //        liveTV = false;
	    }
//	    if (document._video.type == "vod") // || document._audio.type == "audio/mpeg3")
//	      liveTV = false;
      }
      console.log("mailog liveTV = " + liveTV);

    break;

    case 72: // RED
        navigator.showTrickPlayBar();
        document.getElementById("stats").innerHTML += "Show trickplay bar called<br>";
    break;
    case 74: // GREEN
      navigator.playBonk();
      document.getElementById("stats").innerHTML += "Play BONK called<br>";
    break;
    case 79: // INFO
      navigator.showChannelBanner();
    document.getElementById("stats").innerHTML += "Show channel banner called<br>";
    break;
case 75: //YELLOW
      if (liveTV == true) {
         return true;
      }
      else {
//         ProgramInfo.setProgramInfo(progTitle, progDuration, progDescription);
ProgramInfo.setProgramInfo("", "", "");         
         document.getElementById("stats").innerHTML += "setProgramInfo(" + progTitle + ", " + progDuration + ", " +progDescription;
         break;
      }
    case 33: // channel up
    case 34: // channel down
    //case 79: // INFO
//    case 72: // RED key
//    case 74: // GREEN key
//    case 75: // YELLOW key
    case 76: // BLUE key
    case 0:  // PREV key
    case 80: // PLAY
    case 83: // STOP
//    case 82: // RECORD
    case 85: // PAUSE
    case 9:  // FW
    case 67: // STEP FW
    case 87: // RW
    case 46: // STEP RW
    break;
    
    default:
      // push back to UI to handle
      return true; 
  }
  
  return false;
};

Controller.Video = {};
Controller.Video.status = true;

Controller.load = function(node){
  document._video = document.getElementById("VideoM");
  document._audio = document.getElementById("AudioM");


  if (isClient) {
    var macAddr = navigator.getMacAddress();
    var client = macAddr.replace(/:/g,'');
  }

  // MP4 VIDEOS
  if (node.domId == "s1") {
     console.log("enk Selected "+title1); //Basic HLS - BUNNY");
     /*if (document._audio.type == "audio/mpeg3") {
        document._audio.src = source1;
        document._audio.type = type1;
        document._audio.load();
     } else {*/
     srcAttr = source1;
        progTitle = progTitle1;
        progDuration = progDuration1;
        progDescription = progDescription1;
        document._video.setAttribute("src", source1);
        document._video.setAttribute("type", type1);
        document._video.load();
     //}
     isOverFlown(); 
     document.getElementById("stats").innerHTML += "<br>Selected "+title1+"<br>";
     count++;
  } else if (node.domId == "s2") {
     console.log("enk Selected "+title2); //Live Stream - NFL");
     //try {
     srcAttr = source2;
	progTitle = progTitle2;
        progDuration = progDuration2;
        progDescription = progDescription2;
        document._video.setAttribute("src", source2); 
        document._video.setAttribute("type", type2); 
        document._video.load();
     /*}catch(e) {
        console.log("enk EXCEPTION thrown!");
        videoError(e);
     }*/
     isOverFlown(); 
     document.getElementById("stats").innerHTML += "<br>Selected "+title2+"<br>";
     count++;
  } else if (node.domId == "s3") {
     console.log("enk Selected "+title3); //Girls.mp4");
     //try {
     srcAttr = source3;
	progTitle = progTitle3;
        progDuration = progDuration3;
        progDescription = progDescription3;
        document._video.setAttribute("src", source3); 
        document._video.setAttribute("type", type3); 
        document._video.load();
     isOverFlown();
     document.getElementById("stats").innerHTML += "<br>Selected "+title3+"<br>";
     count++;
  } else if (node.domId == "s4") {
     console.log("enk Selected "+title4);
     //try {
     srcAttr = source4;
	progTitle = progTitle4;
        progDuration = progDuration4;
        progDescription = progDescription4;
        document._video.setAttribute("src", source4);
        document._video.setAttribute("type", type4); 
        document._video.load();
     isOverFlown();
     document.getElementById("stats").innerHTML += "<br>Selected "+title4+"<br>";
     count++;
  } else if (node.domId == "s5") {
     console.log("enk Selected "+title5);
     //try {
     srcAttr = source5;
	progTitle = progTitle5;
        progDuration = progDuration5;
        progDescription = progDescription5;
        document._video.setAttribute("src", source5); 
        document._video.setAttribute("type", type5); 
        document._video.load();
     isOverFlown();
     document.getElementById("stats").innerHTML += "<br>Selected "+title5+"<br>";
     count++;

  // Back to Live TV
  } else if (node.domId == "s7") {
     document._video = document.getElementById("VideoM");
     console.log("enk Tuning back to live TV! doc.vid.type => "+document._video.type);
     if (document._video.type = "application/vnd.apple.mpegurl" || document._video.type == "video/mp4") {
	    console.log("enk stopping hls/mp4");
        document._video.stopMedia();
        //srcAttr = "";
     }
     //currCh.tune(); 072115
     resetHUDValues();
     document.getElementById("stats").innerHTML += "Tuning back to live TV<br>";
     VideoSource.setInputOutputWindow(0,0,1920,1080, 575,120,1230,640);

  } else if (node.domId == "key-0") {
    console.log("enk load() "+document._video.getAttribute(srcAttr));
    document._video.load();
    document.getElementById("stats").innerHTML += "load() -> ";

  } else if (node.domId == "key-1") {
    console.log("enk play()");
    document._video.play();
    document.getElementById("stats").innerHTML += "play() -> ";

  } else if (node.domId == "key-2") {
    console.log("enk pause()");
    document._video.pause();
    document.getElementById("stats").innerHTML += "pause() ->";

  } else if (node.domId == "key-3") {
    console.log("enk stop()"); 
    document._video.stopMedia();
    document.getElementById("stats").innerHTML += "stop()<br>";
    srcAttr = "";
    videoPlaying = false;
    liveTV = true;
    resetHUDValues();
    console.log("enk Tuning back to live TV");
    document.getElementById("stats").innerHTML += "Tuning back to live TV<br>";
    VideoSource.setInputOutputWindow(0,0,1920,1080, 575,120,1220,640);

  } else if (node.domId == "key-4") {
    document._video.currentTime+=10;
    console.log("enk currentTime += 10, curTime = "+Math.round(document._video.currentTime));
    document.getElementById("stats").innerHTML += "currentTime += 10<br>";

  } else if (node.domId == "key-5") {
    document._video.currentTime-=10;
    console.log("enk currentTime -= 10, curTime = "+Math.round(document._video.currentTime));
    document.getElementById("stats").innerHTML += "currentTime -= 10<br>";

  } else if (node.domId == "key-6") {
    document._video.currentTime=100;
    console.log("enk currentTime = 100, curTime = "+Math.round(document._video.currentTime));
    document.getElementById("stats").innerHTML += "currentTime = 100<br>";
    //thanh test here
    //var xhReq = new XMLHttpRequest();
    //xhReq.open("GET", "http://192.168.1.201:8008/test");
    //xhReq.send();
	//Thanh test done

  } else if (node.domId == "p1") {
    console.log("enk Selected 'HLS Videos #1' Page");
    document.getElementById("stats").innerHTML += "Selected 'HLS Videos #1' Page<br>";
    currentPage = linksSet1;
    checkNodeName();

  } else if (node.domId == "p2") {
    console.log("enk Selected 'HLS Videos #2' Page");
    document.getElementById("stats").innerHTML += "Selected 'HLS Videos #2' Page<br>";
    currentPage = linksSet2;
    checkNodeName();

  } else if (node.domId == "p3") {
    console.log("enk Selected 'ESPN Streams' Page");
    document.getElementById("stats").innerHTML += "'ESPN Streams' Page currently disabled<br>";
    //currentPage = linksSet3;
    //checkNodeName();

  } else if (node.domId == "p4") {
    console.log("enk Selected 'MP4 Videos' Page");
    document.getElementById("stats").innerHTML += "Selected 'MP4 Video' Page<br>";
    currentPage = linksSet4;
    checkNodeName();

  } else if (node.domId == "p5") {
    console.log("enk Selected 'Corrupted Cases' Page");
    document.getElementById("stats").innerHTML += "'Corrupted Cases' Page currently disabled<br>";
    //currentPage = linksSet5;
    //checkNodeName();

  } else if (node.domId == "p6") {
    console.log("enk Selected 'Unsupported Cases' Page");
    document.getElementById("stats").innerHTML += "'Unsupported Cases' Page currently disabled<br>";
    //currentPage = linksSet6;
    //checkNodeName();

  } else if (node.domId == "p7") {
    console.log("enk Selected 'Error Case #3' Page");
    document.getElementById("stats").innerHTML += "'Error Case #3' Page curently disabled<br>";
    //currentPage = linksSet7;
    //checkNodeName();

  } else {
     Controller.Video.status = false;
     document.getElementById("VideoM").pause();
     console.log("enk UH-OH!"); 
     document.getElementById("stats").innerHTML += "UH OH!  Error--<br>";
  }
};


/**
 * @param {String} node 
 */ 
Controller.setFocus = function(node){
  if(!!node.domId && !!Controller.focus){
    document.getElementById(Controller.focus.domId).classList.remove("selected");
    document.getElementById(node.domId).classList.add("selected");
  }else{
    document.getElementById(node.domId).classList.add("selected");
  }
  Controller.focus = node;   
};

mediaplayer.error = function(param1, param2, param3) {
    var err = param1;
    console.log("enk - encountered an error - videoStatus = "+document._video.getVideoStatus()+"<br>");
    document.getElementById("stats").innerHTML += "Encountered an error!!! videoStatus = "+document._video.getVideoStatus()+"<br>";
    for (var key in err) {
        var val = err[key];
        //document.getElementById("stats").innerHTML += "encountered an error: "+key+"="+val+"<br>";
        console.log("encountered an error: "+key+"="+val);
    }
    console.log("param1 = "+param1);
    console.log("param2 = "+param2);
    console.log("param3 = "+param3);
    if (document._video.type == "video/mp4") {
        currCh.tune();
    } else {
        document._video.stopMedia();
    }
    resetHUDValues();
    document.getElementById("stats").innerHTML += "Tuning back to channel "+currCh.getMajorNumber()+"<br>";
    return true; // lets error go to STB
}


Controller.list = null;

Controller.run = function (){
    window.console.log("Event ", event);
    document.getElementById("stats").innerHTML += "Controller.run<br>";
    document.onkeydown = handleKeys;
    Controller.setFocus(s1);
    mediaplayer.initplaylist();
    document.getElementById("stats").innerHTML += "Loaded 'HLS Videos #1' Page<br>";
};

mediaplayer.initplaylist = function() {
    _video = document.getElementById("VideoM");
    _video.addEventListener('loadeddata', mediaplayer.loadeddata, false);
    _video.addEventListener('loadstart', mediaplayer.loadstart, false);
    _video.addEventListener('loadedmetadata', mediaplayer.loadmd, false);
    _video.addEventListener('playing', mediaplayer.playing, false);
    _video.addEventListener('seeked', mediaplayer.seeked, false);
    _video.addEventListener('pause', mediaplayer.pause, false);
    _video.addEventListener('ended', mediaplayer.eof, false);
    _video.addEventListener('error', mediaplayer.error, false);
    _video.addEventListener('canplay', mediaplayer.canplay, false);
    _video.addEventListener('canplaythrough', mediaplayer.canplaythrough, false);
    _video.addEventListener('play', mediaplayer.play, false);
    _video.addEventListener('timeupdate', mediaplayer.timeupdate, false);
    _video.addEventListener('stalled', mediaplayer.stalled, false);
    _video.addEventListener('progress', mediaplayer.progress, false);
    _video.addEventListener('waiting', mediaplayer.waiting, false);
    _video.addEventListener('emptied', mediaplayer.emptied, false);
//    _video.addEventListener('notifyosddisplay', mediaplayer.notifyosddisplay, false);
}


mediaplayer.loadstart = function () {
    console.log("enk mediaplayer.loadstart() - Looking for media..");
    document.getElementById("stats").innerHTML += "Looking for media..<br>";
    resetHUDValues();
}

mediaplayer.loadeddata = function () {
    console.log("enk mediaplayer.loadeddata() - Media data is loaded");
    document.getElementById("stats").innerHTML += "Media data is loaded<br>";
}

mediaplayer.loadmd = function () {
    console.log("enk mediaplayer.loadmd() - Loaded metadata");
    document.getElementById("stats").innerHTML += "Loaded metadata<br>";
    getDuration();
    getBufferPosition();
}


mediaplayer.playing = function () {
    console.log("enk mediaplayer.playing() - File PLAYING");
    document.getElementById("stats").innerHTML += "File PLAYING<br>";
    getDuration();
    getBufferPosition();
}

mediaplayer.canplay = function () {
    console.log("enk mediaplayer.canplay() - File is ready to start playing..");
    document.getElementById("stats").innerHTML += "File is ready to start playing..<br>";
    getDuration();
    getBufferPosition();
}

mediaplayer.canplaythrough = function () {
    console.log("enk mediaplayer.canplaythrough() - File has completed download..");
    document.getElementById("stats").innerHTML += "File has completed download..<br>";
}

mediaplayer.play = function () {
    console.log("enk mediaplayer.play() - Media is ready to start playing..");
    document.getElementById("stats").innerHTML += "Media is ready to start playing..<br>";
}

mediaplayer.seeked = function () {
    console.log("enk mediaplayer.seeked()");
    if (duration == 0) {
        getDuration();
    }
    if (buffPos == 0) {
        getBufferPosition();
    }
    setTimeout(function(){getCurrentTime()}, 1500);
}

mediaplayer.pause= function () {
    console.log("enk mediaplayer.pause() - PAUSED"); 
    document.getElementById("stats").innerHTML += "PAUSED<br>";
}

mediaplayer.eof = function () {
    console.log("enk mediaplayer.eof() - EOF"); 
    document.getElementById("stats").innerHTML += "EOF<br>";
}

mediaplayer.waiting= function () {
    console.log("enk mediaplayer.waiting() - Waiting for next frame to buffer"); 
    document.getElementById("stats").innerHTML += "Waiting for next frame to buffer<br>";
}

mediaplayer.timeupdate = function () {
    if (duration == 0) {
        getDuration();
    }
    if (buffPos == 0) {
        getBufferPosition();
    }
    
    getCurrentTime();
}

mediaplayer.stalled = function () {
    console.log("enk mediaplayer.stalled() - Waiting to fetch metadata..");
    document.getElementById("stats").innerHTML += "Waiting to fetch medtadata..<br>";
    //document._video.stopMedia();
    //ch.tune();
    //console.log("enk Tuning back to channel "+currCh.getMajorNumber());
    //document.getElementById("stats").innerHTML += "Tuning back to channel "+currCh.getMajorNumber()+"<br>";
    VideoSource.setInputOutputWindow(0,0,1920,1080, 575,200,1220,540);
}

mediaplayer.progress = function () {
    console.log("enk mediaplayer.progress() - Getting media data..");
    document.getElementById("stats").innerHTML += "Getting media data..<br>";
}

mediaplayer.emptied= function () {
    console.log("enk mediaplayer.emptied() - something bad happened and the file is suddenly unavailable..");
    //document.getElementById("stats").innerHTML += "Uh OH!  File unavailable.<br>";
}

/*window.onnotifyosddisplay= function (param1) {
    console.log("enk mediaplayer.notifyosddisplay()"); 
}*/

function resetHUDValues() {
    curTime=0;
    buffPos=0;
    duration=0;

    displayDuration();
    displayCurrentTime();
    displayBufferPos();
}

function displayDuration() {
    document.getElementById('duration').value="DURATION = " + duration;
}

function displayCurrentTime() {
    document.getElementById('currentTime').value="CURRENT TIME = " + curTime;
}

function displayBufferPos() {
    document.getElementById('buffer').value="BUFFER POSITION = " + buffPos;
}

function getDuration() {
    var tempDuration = Math.round(document._video.duration);
    if (isNaN(tempDuration))    setTimeout(function() {getDuration()}, 1000);
    else {
        duration = tempDuration;
        displayDuration();
    }
    console.log("enk getDuration() duration = "+duration);
}

function getBufferPosition() {
    var timeRanges = document._video.seekable;
    var dur = document._video.duration;
    if (timeRanges.length > 0) {
        buffPos = Math.round(timeRanges.end(0));
        displayBufferPos();
    }
    if (buffPos < Math.round(dur))  setTimeout(function() {getBufferPosition()}, 1000);
    console.log("enk getBufferPosition() buffPos = "+buffPos);
}

function getCurrentTime() {
    curTime = Math.round(document._video.currentTime);
    if (curTime > duration) {
        console.log("enk WARNING:  curTime= "+curTime+" > duration="+duration);
        //curTime = duration;
    }
    displayCurrentTime();
    console.log("enk getCurrentTime() curTime = "+curTime);
}

document.addEventListener("DOMContentLoaded", Controller.run, false);

isOverFlown = function () {
    if (count == 2) {
        document.getElementById("stats").innerHTML = "";
        count = 0;
    }
}
