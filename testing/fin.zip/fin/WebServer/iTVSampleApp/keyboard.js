var keyboard = {};

keyboard.keys = [
	{
		name: 'load()',
		action: function() {
			console.log("enk load");
			document._video.load();
		}
	},
	{
		name: 'play()',
		action: function() {
            console.log("enk play");
			document._video.play();
		}
	},
	{
		name: 'pause()',
		action: function() {
            console.log("enk pause");
			document._video.pause();
		}
	},
	{
		 name: 'stop()',
		 action: function() {
		 	console.log("enk stop");
		 	document._video.stopMedia();
		}
	},				 	
	{
		name: 'currentTime += 10',
		action: function() {
			document._video.currentTime+=10;
			window.console.log('enk video.currentTime: '+document._video.currentTime);
		}
	},
	{
		name: 'currentTime -= 10',
		action: function() {
			document._video.currentTime-=10;
			window.console.log('enk video.currentTime: '+document._video.currentTime);
		}
	},
	{
		name: 'currentTime = 15',
		action: function() {
			document._video.currentTime=15;
			window.console.log('enk video.currentTime: '+document._video.currentTime);
		}
	},
/*	{
		name: 'speed ++',
		action: function() {
			document._video.playbackRate++;
			window.console.log('video.playbackRate: '+document._video.playbackRate);
		}
	},
	{
		name: 'speed --',
		action: function() {
			if (document._video.playbackRate>1)
				document._video.playbackRate--;
			window.console.log('video.playbackRate: '+document._video.playbackRate);
		}
	},
	{
		name: 'normal speed',
		action: function() {
			document._video.playbackRate=1;
			window.console.log('video.playbackRate: '+document._video.playbackRate);
		}
	}
	{
		name: 'volume += 0.1',
		action: function() {
			if (document._video.volume < 0.9)
				document._video.volume+=0.1;
			else if (document._video.volume > 0.9 && document._video.volume < 1)
				document._video.volume = 1;
			window.console.log('video.volume: '+document._video.volume);
		}
	},
	{
		name: 'volume -= 0.1',
		action: function() {
			if (document._video.volume > 0.1)
				document._video.volume-=0.1;
			else if (document._video.volume<0.1 && document._video.volume >0)
				document._video.volume=0;
			window.console.log('video.volume: '+document._video.volume);
		}
	},
	{
		name: 'mute/unmute',
		action: function() {
			if (document._video.muted===true)
				document._video.muted = false;
			else
				document._video.muted = true;
			window.console.log('video.muted: '+document._video.muted);
		}
	},
	{
		name: 'resize++',
		action: function() {
			document._video.setAttribute('width', document._video.offsetWidth*=1.1);
			window.console.log('video.size: '+document._video.offsetWidth+'x'+document._video.offsetHeight);
		}
	},
	{
		name: 'resize--',
		action: function() {
			document._video.setAttribute('width', document._video.offsetWidth*=0.9);
			window.console.log('video.size: '+document._video.offsetWidth+'x'+document._video.offsetHeight);
		}
	},
	{
		name: 'default size',
		action: function() {
			document._video.setAttribute('width', 498);
			window.console.log('video.size: '+document._video.offsetWidth+'x'+document._video.offsetHeight);
		}
	},
	{
		name: 'move left',
		action: function() {
			var step = 10;
			var minOffsetLeft = 10;
			var currentOffsetLeft = document._video.offsetLeft;
			var newOffsetLeft = ""+(currentOffsetLeft-(step+minOffsetLeft))+"px";
			if (currentOffsetLeft >= (minOffsetLeft+step))
				document._video.style.marginLeft = newOffsetLeft;
			window.console.log('Top: '+document._video.offsetTop + ' Left: '+document._video.offsetLeft);

		}
	},
	{
		name: 'move right',
		action: function() {
			var step = 10;
			var minOffsetLeft = 10;
			var maxOffsetLeft = 300;
			var currentOffsetLeft = document._video.offsetLeft;
			var newOffsetLeft = ""+currentOffsetLeft-minOffsetLeft+step+"px";
			if (currentOffsetLeft <= (maxOffsetLeft-step))
				document._video.style.marginLeft = newOffsetLeft;
			window.console.log('Top: '+document._video.offsetTop + ' Left: '+document._video.offsetLeft);

		}
	},
	{
		name: 'default position',
		action: function() {
			document._video.style.marginTop="10px";
			document._video.style.marginLeft="0px";
			window.console.log('Top: '+document._video.offsetTop + ' Left: '+document._video.offsetLeft);

		}
	},
	{
		name: 'move up',
		action: function() {
			var step = 10;
			var minOffsetTop = 40;
			var currentOffsetTop = document._video.offsetTop;
			var newOffsetTop = ""+(currentOffsetTop-(step+minOffsetTop))+"px";
			if (currentOffsetTop >= (minOffsetTop+step))
				document._video.style.marginTop = newOffsetTop;
			window.console.log('Top: '+document._video.offsetTop + ' Left: '+document._video.offsetLeft);

		}
	},
	{
		name: 'move down',
		action: function() {
			var step = 10;
			var minOffsetTop = 40;
			var maxOffsetTop = 300;
			var currentOffsetTop = document._video.offsetTop;
			var newOffsetTop = ""+(currentOffsetTop-minOffsetTop+step)+"px";
			if (currentOffsetTop <= (maxOffsetTop))
				document._video.style.marginTop = newOffsetTop;
			window.console.log('Top: '+document._video.offsetTop + ' Left: '+document._video.offsetLeft);

		}
	}
    */
];

keyboard.currentSelected = 0;

keyboard.currentActive = 0;

keyboard.init = function() {

	keyboard.draw();

/*	keyboard.activate(keyboard.currentActive);*/

};

/*keyboard.showhide = function() {
	document.getElementById('keyboard').classList.toggle('hidden');
	console.log('enk keyboard show / hide');
}*/

keyboard.playpausevideo = function() {
	if (document._video.paused) {
		document._video.play();
		console.log('enk play video');
	} else {
		document._video.pause();
		console.log('enk pause video');
	}
};

keyboard.draw = function(erase) {
	var kb = document.getElementById('keyboard');
	var keys = keyboard.keys;
	var key;
	var i;

	// erase current
	if(erase) kb.innerHtml = '';

	for(i=0; i<keys.length; i++) {
		key = document.createElement("div");
		key.id = 'key-'+i;
		key.appendChild(document.createTextNode(keys[i]["name"]));
		key.classList.add("button");
		keys[i]["id"] = key.id;
		kb.appendChild(key);

	}

};

/*keyboard.select = function(key) {
    console.log("enk Select: key: " + key);
	// unselect currently selected
	document.getElementById(keyboard.keys[keyboard.currentSelected]["id"]).classList.remove("selected");

	// select new
	keyboard.currentSelected = key;
	document.getElementById(keyboard.keys[keyboard.currentSelected]["id"]).classList.add("selected");
	keyboard.keys[keyboard.currentSelected].action();


};

keyboard.activate = function(order) {

	var current=keyboard.currentActive;

	if (order=='next' && current<keyboard.keys.length-1) {
		keyboard.currentActive++;
	} else if (order=='prev' && current>0) {
		keyboard.currentActive--;
	}

	// deactivate current
	document.getElementById(keyboard.keys[current]["id"]).classList.remove("active");

	// activate new
	document.getElementById(keyboard.keys[keyboard.currentActive]["id"]).classList.add("active");

};

keyboard.toggleFullscreen = function() {
	console.log('enk keyboard.toggleFullscreen()');
	videoplayer.toggleFullscreen();
}

keyboard.keyhandler = function(remoteKey) {

	var remote = {left: 37, right: 39, select: 13, playpause: 80, showhide: 83, fullscreen: 70};
    var handled = true;

	switch(remoteKey) {
		case remote.left:
			keyboard.activate('prev');
			break;

		case remote.right:
			keyboard.activate('next');
			break;

		case remote.select:
			keyboard.select(keyboard.currentActive);
			break;

		case remote.showhide:
			keyboard.showhide();
			break;

		case remote.playpause:
			keyboard.playpausevideo();
			break;

		case remote.fullscreen:
			keyboard.toggleFullscreen();
			break;

		default:
            handled = false;
			break;
	}

    return handled;

};*/

document.onkeydown = function(e) {
	e = e || window.event;
	keyboard.keyhandler(e.keyCode);
    return false;
}
